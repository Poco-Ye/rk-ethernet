1、头文件路径
include/linux/motorcomm_phy.h


2、Makefile 修改：
diff --git a/drivers/net/phy/Kconfig b/drivers/net/phy/Kconfig
index 2386871..75c1afe 100644
--- a/drivers/net/phy/Kconfig
+++ b/drivers/net/phy/Kconfig
@@ -437,6 +437,11 @@ config XILINX_GMII2RGMII
          the Reduced Gigabit Media Independent Interface(RGMII) between
          Ethernet physical media devices and the Gigabit Ethernet controller.

+config MOTORCOMM_PHY
+    tristate "Motorcomm PHYs"
+    ---help---
+      Supports the YT8010, YT8510, YT8511, YT8512 PHYs.
+
 endif # PHYLIB

 config MICREL_KS8995MA
diff --git a/drivers/net/phy/Makefile b/drivers/net/phy/Makefile
index f21cda9..92fe6d1 100644
--- a/drivers/net/phy/Makefile
+++ b/drivers/net/phy/Makefile
@@ -85,3 +85,4 @@ obj-$(CONFIG_STE10XP)         += ste10Xp.o
 obj-$(CONFIG_TERANETICS_PHY)   += teranetics.o
 obj-$(CONFIG_VITESSE_PHY)      += vitesse.o
 obj-$(CONFIG_XILINX_GMII2RGMII) += xilinx_gmii2rgmii.o
+obj-$(CONFIG_MOTORCOMM_PHY) += motorcomm.o


3、原厂补丁，先不删除
diff --git a/drivers/net/phy/phy_device.c b/drivers/net/phy/phy_device.c
index f4d7738..e7fe10c 100644
--- a/drivers/net/phy/phy_device.c
+++ b/drivers/net/phy/phy_device.c
@@ -674,6 +674,10 @@ static int get_phy_id(struct mii_bus *bus, int addr, u32 *phy_id,
        return 0;
 }

+/* yzhang added for YT8511 phy 125m clock out */
+extern int yt8511_config_out_125m(struct mii_bus *bus, int phy_id);
+extern int yt8511_config_dis_txdelay(struct mii_bus *bus, int phy_id);
+
 /**
  * get_phy_device - reads the specified PHY device and returns its @phy_device
  *                 struct
@@ -697,6 +701,28 @@ struct phy_device *get_phy_device(struct mii_bus *bus, int addr, bool is_c45)
        /* If the phy_id is mostly Fs, there is no device there */
        if ((phy_id & 0x1fffffff) == 0x1fffffff)
                return ERR_PTR(-ENODEV);
+       printk (KERN_INFO "yzhang..read phyaddr=%d, phyid=%08x\n",addr, phy_id);
+       if(0x11a == phy_id)
+       {
+#if 0
+               r = yt8511_config_dis_txdelay(bus, addr);
+               printk (KERN_INFO "yzhang..8511 dis txdelay, reg=%#04x\n",bus->read(bus,addr,0x1f)/*double check as delay*/);
+               if (r<0)
+               {
+                       printk (KERN_INFO "yzhang..failed to dis txdelay, ret=%d\n",r);
+               }
+#endif
+
+#if 1
+               printk (KERN_INFO "yzhang..get YT8511, abt to set 125m clk out, phyaddr=%d, phyid=%08x\n",addr, phy_id);
+               r = yt8511_config_out_125m(bus, addr);
+               printk (KERN_INFO "yzhang..8511 set 125m clk out, reg=%#04x\n",bus->read(bus,addr,0x1f)/*double check as delay*/);
+               if (r<0)
+               {
+                       printk (KERN_INFO "yzhang..failed to set 125m clk out, ret=%d\n",r);
+               }
+#endif
+       }

        return phy_device_create(bus, addr, phy_id, is_c45, &c45_ids);
 }



4、补丁说明：
只有在phy提供mac_clk情况下需要打上0001_YT_PHY_loopback_test.patch，主要是配制phy输出125M mac_clk.
如果dts配制为output,就不需要加motorcomm.c驱动，不需要打回环补丁。


echo 0x27 > /sys/devices/platform/fe010000.ethernet/yt_ext_reg
cat /sys/devices/platform/fe010000.ethernet/yt_ext_reg

echo 0xa012 > /sys/devices/platform/fe010000.ethernet/yt_ext_reg
cat /sys/devices/platform/fe010000.ethernet/yt_ext_reg



