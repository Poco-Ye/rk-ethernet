
c:\adb>adb shell
rk3399_Android10:/ $ su
su
rk3399_Android10:/ # logcat
logcat
--------- beginning of main
08-17 06:45:26.618   149   149 W auditd  : type=2000 audit(0.0:1): state=initialized audit_enabled=0 res=1
08-17 06:45:29.061   149   149 W auditd  : type=1403 audit(0.0:2): auid=4294967295 ses=4294967295 lsm=selinux res=1
08-17 06:45:29.062   149   149 W auditd  : type=1404 audit(0.0:3): enforcing=1 old_enforcing=0 auid=4294967295 ses=4294967295 enabled=1 old-enabled=1 lsm=selinux res=1
08-17 06:45:29.772   136   136 W init    : type=1400 audit(0.0:4): avc: denied { setattr } for name="system_status" dev="sysfs" ino=25612 scontext=u:r:vendor_init:s0 tcontext=u:object_r:sysfs:s0 tclas
s=lnk_file permissive=0
08-17 06:45:29.772   136   136 W init    : type=1400 audit(0.0:5): avc: denied { setattr } for name="system_status" dev="sysfs" ino=25612 scontext=u:r:vendor_init:s0 tcontext=u:object_r:sysfs:s0 tclas
s=lnk_file permissive=0
08-17 06:45:29.783   150   150 I SELinux : SELinux: Loaded service_contexts from:
08-17 06:45:29.785   150   150 I SELinux :     /system/etc/selinux/plat_service_contexts
08-17 06:45:29.808   153   153 I SELinux : SELinux: Loaded service_contexts from:
08-17 06:45:29.808   153   153 I SELinux :     /vendor/etc/selinux/vndservice_contexts
--------- beginning of system
08-17 06:45:29.857   156   156 I vold    : Vold 3.0 (the awakening) firing up
08-17 06:45:29.858   156   156 D vold    : Detected support for: ext4 f2fs vfat
08-17 06:45:29.860   156   156 D vold    : Found unmanaged dm device named product
08-17 06:45:29.860   156   156 D vold    : Found unmanaged dm device named vendor
08-17 06:45:29.860   156   156 D vold    : Found unmanaged dm device named system
08-17 06:45:29.860   156   156 D vold    : Found unmanaged dm device named odm
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop10: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop15: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop1: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop5: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop12: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop9: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop0: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop6: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop13: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop3: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop8: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop14: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop2: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop11: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop7: No such device or address
08-17 06:45:29.861   156   156 W vold    : Failed to LOOP_GET_STATUS64 /dev/block/loop4: No such device or address
08-17 06:45:29.863   156   156 D vold    : VoldNativeService::start() completed OK
08-17 06:45:29.904   151   151 I hwservicemanager: hwservicemanager is ready now.
08-17 06:45:29.969   172   172 I tee_client: boot_mode is unknown/emmc
08-17 06:45:29.969   172   172 I tee_client:
08-17 06:45:29.970   172   172 I tee_client: get_rkss_version version=2
08-17 06:45:29.970   172   172 I tee_client:
08-17 06:45:29.975   156   156 I Checkpoint: Validating checkpoint on /dev/block/by-name/userdata
08-17 06:45:29.975   176   176 I vdc     : vdc V 08-17 06:45:29   177   177 vdc.cpp:50] Waited 0ms for vold
08-17 06:45:29.977   156   156 E Checkpoint: No magic
08-17 06:45:29.978   176   176 I vdc     : vdc E 08-17 06:45:29   177   177 vdc.cpp:60] Failed: Status(22, 22): 'No magic'
08-17 06:45:29.978   176   176 I vdc     : vdc terminated by exit(25)
08-17 06:45:29.986   172   172 I tee_client: rk secure storage is available. We prefer to use it.
08-17 06:45:29.986   172   172 I tee_client: tee-supplicant running on /dev/opteearmtz00
08-17 06:45:29.986   172   172 I tee_client: ro.build.version.sdk=29
08-17 06:45:29.994   176   176 I vdc     : vdc V 08-17 06:45:29   178   178 vdc.cpp:50] Waited 0ms for vold
08-17 06:45:30.013   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.boot@1.0::IBootControl/default in either framework or device manifest.
08-17 06:45:30.052   173   173 I android.hardware.keymaster@3.0-impl: Fetching keymaster device name default
08-17 06:45:30.084   173   173 E RockchipKeymaster: ---------rk_km_open--------(rk_km_open)
08-17 06:45:30.084   173   173 I RockchipKeymaster: Creating test device
08-17 06:45:30.084   173   173 D RockchipKeymaster: Device address: 0x7b27a37000
08-17 06:45:30.084   173   173 E rockchip_keymaster_ca: .ro.vendor.storagemedia= 0
08-17 06:45:30.254   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.0::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:30.257   174   174 I SurfaceFlinger: Using HWComposer service: 'default'
08-17 06:45:30.257   174   174 I SurfaceFlinger: SurfaceFlinger is starting
08-17 06:45:30.258   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.1::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:30.258   174   174 I SurfaceFlinger: Treble testing override: 'false'
08-17 06:45:30.259   174   174 I SurfaceFlinger: SurfaceFlinger's main thread ready to run. Initializing graphics H/W...
08-17 06:45:30.259   174   174 I SurfaceFlinger: Phase offset NS: 1000000
08-17 06:45:30.260   174   187 W SurfaceFlinger: Ignoring VSYNC request while display is disconnected
08-17 06:45:30.260   174   187 W SurfaceFlinger: Ignoring VSYNC request while display is disconnected
08-17 06:45:30.260   174   188 W SurfaceFlinger: Ignoring VSYNC request while display is disconnected
08-17 06:45:30.260   174   188 W SurfaceFlinger: Ignoring VSYNC request while display is disconnected
08-17 06:45:30.260   174   174 D RenderEngine: RenderEngine GLES Backend
08-17 06:45:30.508   174   174 D libEGL  : loaded /vendor/lib64/egl/libGLES_mali.so
08-17 06:45:30.536   174   174 I mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 876; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:30.536   174   174 I mali_so : arm_release_ver of this mali_so is 'r18p0-01rel0', rk_so_ver is '17@0'.
08-17 06:45:30.536   174   174 I mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 901; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:30.536   174   174 I mali_so : arm_release_vers are match. to set the full mali_ver 'r18p0-01rel0-x-17@0' as value of 'sys.gmali.version'.
08-17 06:45:30.601   173   173 I ServiceManagement: Registered android.hardware.keymaster@3.0::IKeymasterDevice/default (start delay of 657ms)
08-17 06:45:30.601   173   173 I ServiceManagement: Removing namespace from process name android.hardware.keymaster@3.0-service to keymaster@3.0-service.
08-17 06:45:30.602   173   173 I android.hardware.keymaster@3.0-service: Registration complete for android.hardware.keymaster@3.0::IKeymasterDevice/default.
08-17 06:45:30.603   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.0::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:30.604   174   174 I RenderEngine: EGL information:
08-17 06:45:30.604   174   174 I RenderEngine: vendor    : Android
08-17 06:45:30.604   174   174 I RenderEngine: version   : 1.4 Android META-EGL
08-17 06:45:30.604   174   174 I RenderEngine: extensions: EGL_KHR_get_all_proc_addresses EGL_ANDROID_presentation_time EGL_KHR_swap_buffers_with_damage EGL_ANDROID_get_native_client_buffer EGL_ANDROI
D_front_buffer_auto_refresh EGL_ANDROID_get_frame_timestamps EGL_EXT_surface_SMPTE2086_metadata EGL_EXT_surface_CTA861_3_metadata EGL_KHR_image EGL_KHR_image_base EGL_KHR_gl_colorspace EGL_KHR_gl_text
ure_2D_image EGL_KHR_gl_texture_cubemap_image EGL_KHR_gl_renderbuffer_image EGL_KHR_fence_sync EGL_KHR_create_context EGL_KHR_config_attribs EGL_KHR_surfaceless_context EGL_EXT_create_context_robustne
ss EGL_ANDROID_image_native_buffer EGL_KHR_wait_sync EGL_ANDROID_recordable EGL_KHR_partial_update EGL_KHR_mutable_render_buffer EGL_IMG_context_priority
08-17 06:45:30.604   174   174 I RenderEngine: Client API: OpenGL_ES
08-17 06:45:30.604   174   174 I RenderEngine: EGLSurface: 8-8-8-8, config=0x7486557008
08-17 06:45:30.610   156   156 I Checkpoint: cp_prepareCheckpoint called
08-17 06:45:30.616   174   174 I RenderEngine: OpenGL ES informations:
08-17 06:45:30.616   174   174 I RenderEngine: vendor    : ARM
08-17 06:45:30.616   174   174 I RenderEngine: renderer  : Mali-T860
08-17 06:45:30.616   174   174 I RenderEngine: version   : OpenGL ES 3.2 v1.r18p0-01rel0.b70e2ec8e3003f2af61a65edf9bc1a26
08-17 06:45:30.616   174   174 I RenderEngine: extensions: GL_EXT_debug_marker GL_ARM_rgba8 GL_ARM_mali_shader_binary GL_OES_depth24 GL_OES_depth_texture GL_OES_depth_texture_cube_map GL_OES_packed_de
pth_stencil GL_OES_rgb8_rgba8 GL_EXT_read_format_bgra GL_OES_compressed_paletted_texture GL_OES_compressed_ETC1_RGB8_texture GL_OES_standard_derivatives GL_OES_EGL_image GL_OES_EGL_image_external GL_O
ES_EGL_image_external_essl3 GL_OES_EGL_sync GL_OES_texture_npot GL_OES_vertex_half_float GL_OES_required_internalformat GL_OES_vertex_array_object GL_OES_mapbuffer GL_EXT_texture_format_BGRA8888 GL_EX
T_texture_rg GL_EXT_texture_type_2_10_10_10_REV GL_OES_fbo_render_mipmap GL_OES_element_index_uint GL_EXT_shadow_samplers GL_OES_texture_compression_astc GL_KHR_texture_compression_astc_ldr GL_KHR_tex
ture_compression_astc_hdr GL_KHR_texture_compression_astc_sliced_3d GL_KHR_debug GL_EXT_occlusion_query_boolean GL_EXT_disjoint_timer_query GL_EXT_blend_minmax GL_EXT_discard_framebuffer GL_OES_get_pr
ogram_binary GL_OES_texture_3D GL_EXT_texture_storage GL_EXT_multisamp
08-17 06:45:30.616   174   174 I RenderEngine: GL_MAX_TEXTURE_SIZE = 8192
08-17 06:45:30.616   174   174 I RenderEngine: GL_MAX_VIEWPORT_DIMS = 8192
08-17 06:45:30.619   174   174 I ServiceManagement: getService: Trying again for android.hardware.graphics.composer@2.1::IComposer/default...
08-17 06:45:30.634   156   156 I vold    : fscrypt_initialize_systemwide_keys
08-17 06:45:30.634   156   156 D vold    : Key exists, using: /data/unencrypted/key
08-17 06:45:30.640   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.keymaster@4.0::IKeymasterDevice/default in either framework or device manifest.
08-17 06:45:30.641   156   156 I vold    : List of Keymaster HALs found:
08-17 06:45:30.641   156   156 I vold    : Keymaster HAL #1: SoftwareWrappedKeymaster2Device from Google SecurityLevel: TRUSTED_ENVIRONMENT HAL: android.hardware.keymaster@3.0::IKeymasterDevice/defaul
t
08-17 06:45:30.641   156   156 I vold    : Using SoftwareWrappedKeymaster2Device from Google for encryption.  Security level: TRUSTED_ENVIRONMENT, HAL: android.hardware.keymaster@3.0::IKeymasterDevice
/default
08-17 06:45:30.645   156   156 D RefBase : RefBase: Explicit destruction, weak count = 0 (in 0x6fe9e3c170)
08-17 06:45:30.645   156   156 W RefBase : CallStack::getCurrentInternal not linked, returning null
08-17 06:45:30.645   156   156 W RefBase : CallStack::logStackInternal not linked
08-17 06:45:30.646   156   156 D vold    : Added key 718272515 (ext4:bbfa7a22ab1d3f0e) to keyring 270648699 in process 156
08-17 06:45:30.646   156   156 D vold    : Added key 496435259 (f2fs:bbfa7a22ab1d3f0e) to keyring 270648699 in process 156
08-17 06:45:30.646   156   156 D vold    : Added key 551825507 (fscrypt:bbfa7a22ab1d3f0e) to keyring 270648699 in process 156
08-17 06:45:30.652   156   156 I vold    : Wrote system DE key reference to:/data/unencrypted/ref
08-17 06:45:30.652   156   156 D vold    : Added key 832251034 (ext4:bbf1f5ef81813bbf) to keyring 270648699 in process 156
08-17 06:45:30.652   156   156 D vold    : Added key 135646674 (f2fs:bbf1f5ef81813bbf) to keyring 270648699 in process 156
08-17 06:45:30.652   156   156 D vold    : Added key 381856240 (fscrypt:bbf1f5ef81813bbf) to keyring 270648699 in process 156
08-17 06:45:30.655   156   156 I vold    : Wrote per boot key reference to:/data/unencrypted/per_boot_ref
08-17 06:45:30.688   219   219 E fsverity_init: Failed to load /product/etc/security/fsverity/*.der
08-17 06:45:30.702   220   220 E /system/bin/mini-keyctl: Cannot find keyring id
08-17 06:45:30.715   221   221 E fsverity_init: Failed to restrict .fs-verity keyring
08-17 06:45:30.735   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:30.750   222   222 I apexd   : Marking APEXd as starting
08-17 06:45:30.751   222   222 I apexd   : Scanning /system/apex for embedded keys
08-17 06:45:30.752   222   222 I apexd   : Scanning /product/apex for embedded keys
08-17 06:45:30.752   222   222 I apexd   : ... does not exist. Skipping
08-17 06:45:30.753   222   222 I apexd   : Populating APEX database from mounts...
08-17 06:45:30.753   222   222 E apexd   : Failed to walk /product/apex : Can't open /product/apex for reading : No such file or directory
08-17 06:45:30.753   222   222 I apexd   : Found "/apex/com.android.tzdata@290000000"
08-17 06:45:30.753   222   222 I apexd   : Found "/apex/com.android.runtime@1"
08-17 06:45:30.753   222   222 I apexd   : 2 packages restored.
08-17 06:45:30.753   222   222 I apexd   : Scanning /data/apex/sessions looking for sessions to be activated.
08-17 06:45:30.754   222   222 I apexd   : Scanning /data/apex/active looking for APEX packages.
08-17 06:45:30.754   222   222 I apexd   : Activated 0 packages. Skipped: 0
08-17 06:45:30.754   222   222 I apexd   : Scanning /system/apex looking for APEX packages.
08-17 06:45:30.755   222   222 I apexd   : Found /system/apex/com.android.tzdata
08-17 06:45:30.755   222   222 I apexd   : Skipping activation of /system/apex/com.android.tzdata same package with higher version 290000000 is already active
08-17 06:45:30.755   222   222 I apexd   : Found /system/apex/com.android.runtime.debug
08-17 06:45:30.755   222   222 I apexd   : Skipping activation of /system/apex/com.android.runtime.debug same package with higher version 1 is already active
08-17 06:45:30.755   222   222 I apexd   : Found /system/apex/com.android.conscrypt
08-17 06:45:30.755   222   222 V apexd   : Creating mount point: /apex/com.android.conscrypt@290000000
08-17 06:45:30.755   222   222 I apexd   : Successfully bind-mounted flattened package /system/apex/com.android.conscrypt on /apex/com.android.conscrypt@290000000
08-17 06:45:30.755   222   222 V apexd   : Creating bind-mount for /apex/com.android.conscrypt for /apex/com.android.conscrypt@290000000
08-17 06:45:30.755   222   222 V apexd   : Creating mountpoint /apex/com.android.conscrypt
08-17 06:45:30.755   222   222 V apexd   : Bind-mounting /apex/com.android.conscrypt@290000000 to /apex/com.android.conscrypt
08-17 06:45:30.755   222   222 D apexd   : Successfully activated /system/apex/com.android.conscrypt package_name: com.android.conscrypt version: 290000000
08-17 06:45:30.755   222   222 I apexd   : Found /system/apex/com.android.resolv
08-17 06:45:30.756   222   222 V apexd   : Creating mount point: /apex/com.android.resolv@290000000
08-17 06:45:30.756   222   222 I apexd   : Successfully bind-mounted flattened package /system/apex/com.android.resolv on /apex/com.android.resolv@290000000
08-17 06:45:30.756   222   222 V apexd   : Creating bind-mount for /apex/com.android.resolv for /apex/com.android.resolv@290000000
08-17 06:45:30.756   222   222 V apexd   : Creating mountpoint /apex/com.android.resolv
08-17 06:45:30.756   222   222 V apexd   : Bind-mounting /apex/com.android.resolv@290000000 to /apex/com.android.resolv
08-17 06:45:30.756   222   222 D apexd   : Successfully activated /system/apex/com.android.resolv package_name: com.android.resolv version: 290000000
08-17 06:45:30.756   222   222 I apexd   : Found /system/apex/com.android.media.swcodec
08-17 06:45:30.756   222   222 V apexd   : Creating mount point: /apex/com.android.media.swcodec@290000000
08-17 06:45:30.756   222   222 I apexd   : Successfully bind-mounted flattened package /system/apex/com.android.media.swcodec on /apex/com.android.media.swcodec@290000000
08-17 06:45:30.756   222   222 V apexd   : Creating bind-mount for /apex/com.android.media.swcodec for /apex/com.android.media.swcodec@290000000
08-17 06:45:30.756   222   222 V apexd   : Creating mountpoint /apex/com.android.media.swcodec
08-17 06:45:30.756   222   222 V apexd   : Bind-mounting /apex/com.android.media.swcodec@290000000 to /apex/com.android.media.swcodec
08-17 06:45:30.756   222   222 D apexd   : Successfully activated /system/apex/com.android.media.swcodec package_name: com.android.media.swcodec version: 290000000
08-17 06:45:30.756   222   222 I apexd   : Found /system/apex/com.android.media
08-17 06:45:30.756   222   222 V apexd   : Creating mount point: /apex/com.android.media@290000000
08-17 06:45:30.756   222   222 I apexd   : Successfully bind-mounted flattened package /system/apex/com.android.media on /apex/com.android.media@290000000
08-17 06:45:30.757   222   222 V apexd   : Creating bind-mount for /apex/com.android.media for /apex/com.android.media@290000000
08-17 06:45:30.757   222   222 V apexd   : Creating mountpoint /apex/com.android.media
08-17 06:45:30.757   222   222 V apexd   : Bind-mounting /apex/com.android.media@290000000 to /apex/com.android.media
08-17 06:45:30.757   222   222 D apexd   : Successfully activated /system/apex/com.android.media package_name: com.android.media version: 290000000
08-17 06:45:30.757   222   222 I apexd   : Activated 4 packages. Skipped: 2
08-17 06:45:30.757   222   222 I apexd   : Scanning /product/apex looking for APEX packages.
08-17 06:45:30.757   222   222 E apexd   : Failed to activate packages from /product/apex : Failed to scan /product/apex : Can't open /product/apex for reading : No such file or directory
08-17 06:45:30.757   222   222 I apexd   : Marking APEXd as ready
08-17 06:45:30.836   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:30.873   156   156 D vold    : fscrypt_init_user0
08-17 06:45:30.873   156   156 D vold    : Preparing: /data/misc/vold/user_keys
08-17 06:45:30.874   156   156 D vold    : Preparing: /data/misc/vold/user_keys/ce
08-17 06:45:30.874   156   156 D vold    : Preparing: /data/misc/vold/user_keys/de
08-17 06:45:30.875   156   156 D vold    : Skipping non-de-key ..
08-17 06:45:30.875   156   156 D vold    : Skipping non-de-key .
08-17 06:45:30.880   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.keymaster@4.0::IKeymasterDevice/default in either framework or device manifest.
08-17 06:45:30.881   156   156 I vold    : List of Keymaster HALs found:
08-17 06:45:30.881   156   156 I vold    : Keymaster HAL #1: SoftwareWrappedKeymaster2Device from Google SecurityLevel: TRUSTED_ENVIRONMENT HAL: android.hardware.keymaster@3.0::IKeymasterDevice/defaul
t
08-17 06:45:30.881   156   156 I vold    : Using SoftwareWrappedKeymaster2Device from Google for encryption.  Security level: TRUSTED_ENVIRONMENT, HAL: android.hardware.keymaster@3.0::IKeymasterDevice
/default
08-17 06:45:30.883   156   156 D RefBase : RefBase: Explicit destruction, weak count = 0 (in 0x6fe9e3c0f0)
08-17 06:45:30.883   156   156 W RefBase : CallStack::getCurrentInternal not linked, returning null
08-17 06:45:30.883   156   156 W RefBase : CallStack::logStackInternal not linked
08-17 06:45:30.883   156   156 D vold    : Added key 277056604 (ext4:74d958d0d66986f8) to keyring 270648699 in process 156
08-17 06:45:30.883   156   156 D vold    : Added key 705453025 (f2fs:74d958d0d66986f8) to keyring 270648699 in process 156
08-17 06:45:30.883   156   156 D vold    : Added key 995503500 (fscrypt:74d958d0d66986f8) to keyring 270648699 in process 156
08-17 06:45:30.883   156   156 D vold    : Installed de key for user 0
08-17 06:45:30.883   156   156 D vold    : fscrypt_prepare_user_storage for volume null, user 0, serial 0, flags 1
08-17 06:45:30.884   156   156 D vold    : Preparing: /data/system/users/0
08-17 06:45:30.884   156   156 D vold    : Preparing: /data/misc/profiles/cur/0
08-17 06:45:30.884   156   156 D vold    : Preparing: /data/system_de/0
08-17 06:45:30.885   156   156 D vold    : Preparing: /data/misc_de/0
08-17 06:45:30.885   156   156 D vold    : Preparing: /data/vendor_de/0
08-17 06:45:30.885   156   156 D vold    : Preparing: /data/user_de/0
08-17 06:45:30.886   156   156 I vold    : Found policy 74d958d0d66986f8 at /data/system_de/0 which matches expected value
08-17 06:45:30.887   156   156 I vold    : Found policy 74d958d0d66986f8 at /data/misc_de/0 which matches expected value
08-17 06:45:30.887   156   156 I vold    : Found policy 74d958d0d66986f8 at /data/vendor_de/0 which matches expected value
08-17 06:45:30.888   156   156 I vold    : Found policy 74d958d0d66986f8 at /data/user_de/0 which matches expected value
08-17 06:45:30.888   156   156 D vold    : /system/bin/vold_prepare_subdirs
08-17 06:45:30.888   156   156 D vold    :     prepare
08-17 06:45:30.888   156   156 D vold    :
08-17 06:45:30.889   156   156 D vold    :     0
08-17 06:45:30.889   156   156 D vold    :     1
08-17 06:45:30.920   231   231 D vold_prepare_subdirs: Setting up mode 700 uid 0 gid 0 context u:object_r:vold_data_file:s0 on path: /data/misc_de/0/vold
08-17 06:45:30.921   231   231 D vold_prepare_subdirs: Setting up mode 700 uid 0 gid 0 context u:object_r:storaged_data_file:s0 on path: /data/misc_de/0/storaged
08-17 06:45:30.922   231   231 D vold_prepare_subdirs: Setting up mode 700 uid 0 gid 0 context u:object_r:rollback_data_file:s0 on path: /data/misc_de/0/rollback
08-17 06:45:30.923   231   231 D vold_prepare_subdirs: Setting up mode 700 uid 1000 gid 1000 context u:object_r:fingerprint_vendor_data_file:s0 on path: /data/vendor_de/0/fpdata
08-17 06:45:30.924   231   231 D vold_prepare_subdirs: Setting up mode 700 uid 1000 gid 1000 context u:object_r:face_vendor_data_file:s0 on path: /data/vendor_de/0/facedata
08-17 06:45:30.936   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:30.947   232   232 I /system/bin/tzdatacheck: timezone distro dir /data/misc/zoneinfo/current does not exist. No action required.
08-17 06:45:30.992   235   235 I art_apex: === ART pre-boot integrity checks ===
08-17 06:45:31.033   237   237 F art_apex: Device is not fsverity-enabled.
08-17 06:45:31.036   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.078   239   239 I /system/bin/recovery-persist: Empty last_install file
08-17 06:45:31.094   241   241 I /system/bin/flags_health_check: ServerConfigurableFlagsReset reset_mode value: 0
08-17 06:45:31.094   241   241 I /system/bin/flags_health_check: ServerConfigurableFlagsReset attempted boot count is under threshold, skipping reset.
08-17 06:45:31.120   136   136 W init    : type=1400 audit(0.0:6): avc: denied { setattr } for name="nfc" dev="mmcblk2p15" ino=210913 scontext=u:r:vendor_init:s0 tcontext=u:object_r:system_data_file:s
0 tclass=dir permissive=0
08-17 06:45:31.121   136   136 W init    : type=1400 audit(0.0:7): avc: denied { setattr } for name="param" dev="mmcblk2p15" ino=210914 scontext=u:r:vendor_init:s0 tcontext=u:object_r:system_data_file
:s0 tclass=dir permissive=0
08-17 06:45:31.122   136   136 W init    : type=1400 audit(0.0:8): avc: denied { setattr } for name="nfc" dev="mmcblk2p15" ino=210913 scontext=u:r:vendor_init:s0 tcontext=u:object_r:system_data_file:s
0 tclass=dir permissive=0
08-17 06:45:31.122   136   136 W init    : type=1400 audit(0.0:9): avc: denied { setattr } for name="param" dev="mmcblk2p15" ino=210914 scontext=u:r:vendor_init:s0 tcontext=u:object_r:system_data_file
:s0 tclass=dir permissive=0
08-17 06:45:31.123   136   136 W init    : type=1400 audit(0.0:10): avc: denied { setattr } for name="nfc" dev="mmcblk2p15" ino=210913 scontext=u:r:vendor_init:s0 tcontext=u:object_r:system_data_file:
s0 tclass=dir permissive=0
08-17 06:45:31.123   136   136 W init    : type=1400 audit(0.0:11): avc: denied { setattr } for name="param" dev="mmcblk2p15" ino=210914 scontext=u:r:vendor_init:s0 tcontext=u:object_r:system_data_fil
e:s0 tclass=dir permissive=0
08-17 06:45:31.137   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.156   245   245 I bootstat: Service started: /system/bin/bootstat --set_system_boot_reason
08-17 06:45:31.201   246   246 I ServiceManagement: Registered android.hidl.allocator@1.0::IAllocator/ashmem (start delay of 36ms)
08-17 06:45:31.203   246   246 I ServiceManagement: Removing namespace from process name android.hidl.allocator@1.0-service to allocator@1.0-service.
08-17 06:45:31.218   242   242 I netdClient: Skipping libnetd_client init since *we* are netd
08-17 06:45:31.224   247   247 I ServiceManagement: Registered android.system.suspend@1.0::ISystemSuspend/default (start delay of 59ms)
08-17 06:45:31.225   242   242 I netd    : netd 1.0 starting
08-17 06:45:31.226   247   247 I ServiceManagement: Removing namespace from process name android.system.suspend@1.0-service to suspend@1.0-service.
08-17 06:45:31.237   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.253   245   245 I bootstat: Canonical boot reason: reboot
08-17 06:45:31.253   245   245 I bootstat: Canonical boot reason: reboot
08-17 06:45:31.286   249   249 I ServiceManagement: Registered android.hardware.bluetooth@1.0::IBluetoothHci/default (start delay of 111ms)
08-17 06:45:31.286   249   249 I ServiceManagement: Removing namespace from process name android.hardware.bluetooth@1.0-service to bluetooth@1.0-service.
08-17 06:45:31.286   249   249 I android.hardware.bluetooth@1.0-service: Registration complete for android.hardware.bluetooth@1.0::IBluetoothHci/default.
08-17 06:45:31.331   242   242 I Netd    : Loaded resolver library from /apex/com.android.resolv/lib64/libnetd_resolv.so
08-17 06:45:31.338   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.340   261   261 I health@2.0/: health@2.0/default: Hal starting main loop...
08-17 06:45:31.341   261   261 I health@2.0/: health@2.0/default Hal is starting up...
08-17 06:45:31.345   273   273 I lowmemorykiller: Using psi monitors for memory pressure detection
08-17 06:45:31.351   261   261 I ServiceManagement: Registered android.hardware.health@2.0::IHealth/default (start delay of 117ms)
08-17 06:45:31.351   261   261 I ServiceManagement: Removing namespace from process name android.hardware.health@2.0-service to health@2.0-service.
08-17 06:45:31.351   261   261 I health@2.0/: health@2.0/default: Hal init done
08-17 06:45:31.375   263   263 D memtrack_rk: memtrack_open: enter; name=memtrack
08-17 06:45:31.376   263   263 D memtrack_rk: memtrack_open: exit 0
08-17 06:45:31.377   251   251 I android.hardware.camera.provider@2.4-service: CameraProvider@2.4 legacy service is starting.
08-17 06:45:31.378   250   250 I android.hardware.camera.provider@2.4-external-service: External camera provider service is starting.
08-17 06:45:31.378   263   263 I ServiceManagement: Registered android.hardware.memtrack@1.0::IMemtrack/default (start delay of 133ms)
08-17 06:45:31.378   263   263 I ServiceManagement: Removing namespace from process name android.hardware.memtrack@1.0-service to memtrack@1.0-service.
08-17 06:45:31.378   263   263 I android.hardware.memtrack@1.0-service: Registration complete for android.hardware.memtrack@1.0::IMemtrack/default.
08-17 06:45:31.390   266   266 I android.hardware.weaver@1.0-service: IWeaver HAL started
08-17 06:45:31.390   262   262 E light   : light_open lights keyboard failed: -38
08-17 06:45:31.390   262   262 E light   : Light passthrough failed to load legacy HAL.
08-17 06:45:31.391   262   262 E light   : light_open lights buttons failed: -38
08-17 06:45:31.391   262   262 E light   : Light passthrough failed to load legacy HAL.
08-17 06:45:31.392   262   262 E light   : light_open lights battery failed: -38
08-17 06:45:31.392   262   262 E light   : Light passthrough failed to load legacy HAL.
08-17 06:45:31.392   262   262 E light   : light_open lights notifications failed: -38
08-17 06:45:31.392   262   262 E light   : Light passthrough failed to load legacy HAL.
08-17 06:45:31.393   262   262 E light   : light_open lights attention failed: -38
08-17 06:45:31.393   262   262 E light   : Light passthrough failed to load legacy HAL.
08-17 06:45:31.397   262   262 E light   : light_open lights bluetooth failed: -38
08-17 06:45:31.397   262   262 E light   : Light passthrough failed to load legacy HAL.
08-17 06:45:31.398   262   262 E light   : light_open lights wifi failed: -38
08-17 06:45:31.398   262   262 E light   : Light passthrough failed to load legacy HAL.
08-17 06:45:31.405   262   262 I ServiceManagement: Registered android.hardware.light@2.0::ILight/default (start delay of 171ms)
08-17 06:45:31.405   262   262 I ServiceManagement: Removing namespace from process name android.hardware.light@2.0-service to light@2.0-service.
08-17 06:45:31.405   266   266 I /vendor/bin/hw/android.hardware.weaver@1.0-service: HIDL_FETCH_IWeaver
08-17 06:45:31.405   262   262 I         : Registration complete for android.hardware.light@2.0::ILight/default.
08-17 06:45:31.406   266   266 I /vendor/bin/hw/android.hardware.weaver@1.0-service: Weaver()
08-17 06:45:31.406   264   264 I ServiceManagement: Registered android.hardware.power@1.0::IPower/default (start delay of 159ms)
08-17 06:45:31.406   264   264 I ServiceManagement: Removing namespace from process name android.hardware.power@1.0-service to power@1.0-service.
08-17 06:45:31.406   264   264 I android.hardware.power@1.0-service: Registration complete for android.hardware.power@1.0::IPower/default.
08-17 06:45:31.408   265   265 D SensorsHal: sensor hal  v1.6 upagrde sensors device api version to SENSORS_DEVICE_API_VERSION_1_3
08-17 06:45:31.408   265   265 E SensorsHal: couldn't find 'lightsensor-level' input device
08-17 06:45:31.408   265   265 D SensorsHal: Couldn't open /dev/lightsensor (No such file or directory)
08-17 06:45:31.408   265   265 E SensorsHal: couldn't find 'proximity' input device
08-17 06:45:31.409   265   265 D SensorsHal: Couldn't open /dev/psensor (No such file or directory)
08-17 06:45:31.409   265   265 E SensorsHal: fail to perform GSENSOR_IOCTL_GET_CALIBRATION, result = -1, error is 'Bad address'
08-17 06:45:31.409   252   252 I ServiceManagement: Registered android.hardware.cas@1.1::IMediaCasService/default (start delay of 214ms)
08-17 06:45:31.410   252   252 I ServiceManagement: Removing namespace from process name android.hardware.cas@1.1-service to cas@1.1-service.
08-17 06:45:31.429   257   257 I ServiceManagement: Registered android.hardware.gatekeeper@1.0::IGatekeeper/default (start delay of 205ms)
08-17 06:45:31.430   257   257 I ServiceManagement: Removing namespace from process name android.hardware.gatekeeper@1.0-service to gatekeeper@1.0-service.
08-17 06:45:31.430   257   257 I android.hardware.gatekeeper@1.0-service: Registration complete for android.hardware.gatekeeper@1.0::IGatekeeper/default.
08-17 06:45:31.437   265   265 E SensorsHal: couldn't find 'compass' input device
08-17 06:45:31.437   265   265 E SensorsHal: fail to perform L3G4200D_IOCTL_GET_CALIBRATION, result = -1, error is 'Bad address'
08-17 06:45:31.437   265   265 E SensorsHal: couldn't find 'pressure' input device
08-17 06:45:31.437   265   265 D SensorsHal: Couldn't open /dev/pressure (No such file or directory)
08-17 06:45:31.437   265   265 E SensorsHal: couldn't find 'temperature' input device
08-17 06:45:31.437   265   265 D SensorsHal: Couldn't open /dev/temperature (No such file or directory)
08-17 06:45:31.438   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.439   260   260 W android.hardwar: type=1400 audit(0.0:12): avc: denied { read } for name="resolution_white.xml" dev="dm-0" ino=3465 scontext=u:r:hal_graphics_composer_default:s0 tconte
xt=u:object_r:system_file:s0 tclass=file permissive=0
08-17 06:45:31.439   260   260 W hwc_rk  : BP: baseparamter file cann't be find.
08-17 06:45:31.441   269   269 W rockchip.hardwa: type=1400 audit(0.0:13): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:vendor-rockit-hal-1-0:s0 tconte
xt=u:object_r:default_prop:s0 tclass=file permissive=0
08-17 06:45:31.441   260   260 W hwc-drm-connector: DrmConnector init id=79,type=eDP
08-17 06:45:31.441   260   260 W hwc-drm-connector: Could not get hdr source metadata property
08-17 06:45:31.441   269   269 E libc    : Access denied finding property "mpp_mem_debug"
08-17 06:45:31.441   260   260 W hwc-drm-connector: Could not get hdr panel metadata property
08-17 06:45:31.441   260   260 W hwc-drm-connector: Could not get hdmi_output_colorimetry property
08-17 06:45:31.441   260   260 W hwc-drm-connector: Could not get hdmi_output_format property
08-17 06:45:31.442   260   260 W hwc-drm-connector: Could not get hdmi_output_depth property
08-17 06:45:31.442   269   269 D RockitHwService: rockit.hardware.rockit.hw@1.0-service starting...
08-17 06:45:31.442   260   260 W hwc-drm-connector: DrmConnector init id=81,type=DP
08-17 06:45:31.442   260   260 W hwc-drm-connector: Could not get hdr source metadata property
08-17 06:45:31.442   260   260 W hwc-drm-connector: Could not get hdr panel metadata property
08-17 06:45:31.442   260   260 W hwc-drm-connector: Could not get hdmi_output_colorimetry property
08-17 06:45:31.443   260   260 W hwc-drm-connector: Could not get hdmi_output_format property
08-17 06:45:31.443   260   260 W hwc-drm-connector: Could not get hdmi_output_depth property
08-17 06:45:31.443   260   260 W hwc-drm-connector: DrmConnector init id=83,type=HDMI-A
08-17 06:45:31.444   260   260 E hwc-drm-resources: is_hdr_panel_support_st2084:line=1393, blob is null
08-17 06:45:31.444   268   268 D rockchip.hardware.outputmanager@1.0-service: ***************defaultPassthroughServiceImplementation IRkOutputManager ******
08-17 06:45:31.444   260   260 E hwc-drm-resources: is_hdr_panel_support_HLG:line=1447, blob is null
08-17 06:45:31.444   260   260 E hwc-drm-resources: is_hdr_panel_support_st2084:line=1393, blob is null
08-17 06:45:31.444   260   260 W hwc_rk  : BP: DEVICE baseparameter is not ready,can't use it !
08-17 06:45:31.444   260   260 W hwc-drm-resources: BP: hwc get baseparameter err
08-17 06:45:31.444   260   260 W hwc_rk  : BP: DEVICE baseparameter is not ready,can't use it !
08-17 06:45:31.445   260   260 E hwc-drm-resources: BP: hwc get baseparameter err
08-17 06:45:31.445   268   268 E rockchip.hardware.outputmanager@1.0-service: Couldn't set SCHED_FIFO: 1
08-17 06:45:31.446   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.446   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.448   269   269 W /vendor/bin/hw/rockchip.hardware.rockit.hw@1.0-service: No seccomp policy defined for this architecture.
08-17 06:45:31.448   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.449   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.450   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.450   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.451   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.451   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.452   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.452   243   243 D AndroidRuntime: >>>>>> START com.android.internal.os.ZygoteInit uid 0 <<<<<<
08-17 06:45:31.453   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.453   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.454   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.454   269   269 D RockitHwService: Instantiating rockit hw service....
08-17 06:45:31.454   269   269 D RockitHwService: RockitHwService
08-17 06:45:31.455   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.456   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.457   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.458   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.460   260   260 I chatty  : uid=1000(system) composer@2.1-se identical 1 line
08-17 06:45:31.461   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.463   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.463   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.463   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.464   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.464   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.465   269   269 I ServiceManagement: Registered rockchip.hardware.rockit.hw@1.0::IRockitHwService/default (start delay of 210ms)
08-17 06:45:31.465   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.465   269   269 I ServiceManagement: Removing namespace from process name rockchip.hardware.rockit.hw@1.0-service to hw@1.0-service.
08-17 06:45:31.466   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.466   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.467   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.468   269   269 I RockitHwService: rockit hw service created
08-17 06:45:31.468   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.468   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.469   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.470   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.470   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.470   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.472   265   265 I ServiceManagement: Registered android.hardware.sensors@1.0::ISensors/default (start delay of 227ms)
08-17 06:45:31.472   260   260 E hwc-drm-plane: Could not get rotation property
08-17 06:45:31.472   260   260 I hwc-drm-plane: Could not get alpha property
08-17 06:45:31.472   265   265 I ServiceManagement: Removing namespace from process name android.hardware.sensors@1.0-service to sensors@1.0-service.
08-17 06:45:31.472   265   265 I android.hardware.sensors@1.0-service: Registration complete for android.hardware.sensors@1.0::ISensors/default.
08-17 06:45:31.472   260   260 E hwc-drm-plane: Could not get AREA_ID property
08-17 06:45:31.474   260   260 E hwc-drm-display-compositor: vop_bw: Error opening /sys/class/devfreq/dmc/vop_bandwidth: No such file or directory
08-17 06:45:31.474   260   260 E hwc-drm-display-compositor: vop_bw: Error opening /sys/class/devfreq/dmc/vop_bandwidth: No such file or directory
08-17 06:45:31.475   266   266 I ServiceManagement: Registered android.hardware.weaver@1.0::IWeaver/default (start delay of 230ms)
08-17 06:45:31.475   266   266 I ServiceManagement: Removing namespace from process name android.hardware.weaver@1.0-service to weaver@1.0-service.
08-17 06:45:31.475   260   260 E hwcomposer-drm: Open hdmi_status_fd fail in hwc_device_open
08-17 06:45:31.475   266   266 I android.hardware.weaver@1.0-service: Registration complete for android.hardware.weaver@1.0::IWeaver/default.
08-17 06:45:31.475   260   260 E hwcomposer-drm: Open hdmi_status_fd fail in hwc_device_open
08-17 06:45:31.479   259   259 D GRALLOC-ROCKCHIP: RK_GRAPHICS_VER=commit-id:344c4dd
08-17 06:45:31.481   259   259 I ServiceManagement: Registered android.hardware.graphics.allocator@2.0::IAllocator/default (start delay of 246ms)
08-17 06:45:31.481   259   259 I ServiceManagement: Removing namespace from process name android.hardware.graphics.allocator@2.0-service to allocator@2.0-service.
08-17 06:45:31.481   259   259 I android.hardware.graphics.allocator@2.0-service: Registration complete for android.hardware.graphics.allocator@2.0::IAllocator/default.
08-17 06:45:31.484   255   255 I ServiceManagement: Registered android.hardware.drm@1.2::IDrmFactory/widevine (start delay of 269ms)
08-17 06:45:31.484   255   255 I ServiceManagement: Removing namespace from process name android.hardware.drm@1.2-service.widevine to drm@1.2-service.widevine.
08-17 06:45:31.485   255   255 I ServiceManagement: Registered android.hardware.drm@1.2::ICryptoFactory/widevine (start delay of 271ms)
08-17 06:45:31.485   255   255 I ServiceManagement: Removing namespace from process name android.hardware.drm@1.2-service.widevine to drm@1.2-service.widevine.
08-17 06:45:31.486   254   254 I ServiceManagement: Registered android.hardware.drm@1.2::IDrmFactory/clearkey (start delay of 272ms)
08-17 06:45:31.486   254   254 I ServiceManagement: Removing namespace from process name android.hardware.drm@1.2-service.clearkey to drm@1.2-service.clearkey.
08-17 06:45:31.487   254   254 I ServiceManagement: Registered android.hardware.drm@1.2::ICryptoFactory/clearkey (start delay of 273ms)
08-17 06:45:31.487   254   254 I ServiceManagement: Removing namespace from process name android.hardware.drm@1.2-service.clearkey to drm@1.2-service.clearkey.
08-17 06:45:31.490   268   268 I ServiceManagement: Registered rockchip.hardware.outputmanager@1.0::IRkOutputManager/default (start delay of 236ms)
08-17 06:45:31.491   268   268 I ServiceManagement: Removing namespace from process name rockchip.hardware.outputmanager@1.0-service to outputmanager@1.0-service.
08-17 06:45:31.491   268   268 I rockchip.hardware.outputmanager@1.0-service: Registration complete for rockchip.hardware.outputmanager@1.0::IRkOutputManager/default.
08-17 06:45:31.503   250   250 I ExtCamUtils@3.4: loadFromCfg: load external camera config succeed!
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: depth output is not enabled
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: no minimum stream size specified
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: no sensor orientation specified
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: external camera cfg loaded: maxJpgBufSize 3145728, num video buffers 4, num still buffers 2, orientation 0
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: fpsLimitList: 640x480@30.000000
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: fpsLimitList: 1280x720@30.000000
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: fpsLimitList: 1920x1080@30.000000
08-17 06:45:31.504   250   250 I ExtCamUtils@3.4: loadFromCfg: minStreamSize: 0x0
08-17 06:45:31.506   250   250 I ServiceManagement: Registered android.hardware.camera.provider@2.4::ICameraProvider/external/0 (start delay of 321ms)
08-17 06:45:31.506   250   250 I ServiceManagement: Removing namespace from process name android.hardware.camera.provider@2.4-external-service to provider@2.4-external-service.
08-17 06:45:31.506   250   250 I android.hardware.camera.provider@2.4-external-service: Registration complete for android.hardware.camera.provider@2.4::ICameraProvider/external/0.
08-17 06:45:31.507   250   302 W CamPrvdr@2.4-external: deviceAdded device /dev/video0 does not support VIDEO_CAPTURE
08-17 06:45:31.508   250   302 W CamPrvdr@2.4-external: deviceAdded device /dev/video3 does not support VIDEO_CAPTURE
08-17 06:45:31.508   250   302 W CamPrvdr@2.4-external: deviceAdded device /dev/video1 does not support VIDEO_CAPTURE
08-17 06:45:31.508   250   302 W CamPrvdr@2.4-external: deviceAdded device /dev/video2 does not support VIDEO_CAPTURE
08-17 06:45:31.508   250   302 W CamPrvdr@2.4-external: deviceAdded device /dev/video4 does not support VIDEO_CAPTURE
08-17 06:45:31.508   250   302 I CamPrvdr@2.4-external: threadLoop start monitoring new V4L2 devices
08-17 06:45:31.521   267   267 I android.hardware.wifi@1.0-service: Wifi Hal is booting up...
08-17 06:45:31.523   267   267 I ServiceManagement: Registered android.hardware.wifi@1.3::IWifi/default (start delay of 268ms)
08-17 06:45:31.523   267   267 I ServiceManagement: Removing namespace from process name android.hardware.wifi@1.0-service to wifi@1.0-service.
08-17 06:45:31.538   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.541   253   253 I ServiceManagement: Registered android.hardware.drm@1.0::IDrmFactory/default (start delay of 336ms)
08-17 06:45:31.541   253   253 I ServiceManagement: Removing namespace from process name android.hardware.drm@1.0-service to drm@1.0-service.
08-17 06:45:31.541   253   253 I         : Registration complete for android.hardware.drm@1.0::IDrmFactory/default.
08-17 06:45:31.543   253   253 I ServiceManagement: Registered android.hardware.drm@1.0::ICryptoFactory/default (start delay of 339ms)
08-17 06:45:31.543   253   253 I ServiceManagement: Removing namespace from process name android.hardware.drm@1.0-service to drm@1.0-service.
08-17 06:45:31.543   253   253 I         : Registration complete for android.hardware.drm@1.0::ICryptoFactory/default.
08-17 06:45:31.585   243   243 I AndroidRuntime: Using default boot image
08-17 06:45:31.585   243   243 I AndroidRuntime: Leaving lock profiling enabled
08-17 06:45:31.602   243   243 I zygote64: option[0]=-Xzygote
08-17 06:45:31.602   243   243 I zygote64: option[1]=exit
08-17 06:45:31.602   243   243 I zygote64: option[2]=vfprintf
08-17 06:45:31.603   243   243 I zygote64: option[3]=sensitiveThread
08-17 06:45:31.603   243   243 I zygote64: option[4]=-verbose:gc
08-17 06:45:31.603   243   243 I zygote64: option[5]=-Xms16m
08-17 06:45:31.603   243   243 I zygote64: option[6]=-Xmx512m
08-17 06:45:31.603   243   243 I zygote64: option[7]=-XX:HeapGrowthLimit=192m
08-17 06:45:31.603   243   243 I zygote64: option[8]=-XX:HeapMinFree=512k
08-17 06:45:31.603   243   243 I zygote64: option[9]=-XX:HeapMaxFree=8m
08-17 06:45:31.603   243   243 I zygote64: option[10]=-XX:HeapTargetUtilization=0.75
08-17 06:45:31.603   243   243 I zygote64: option[11]=-Xusejit:true
08-17 06:45:31.603   243   243 I zygote64: option[12]=-Xjitsaveprofilinginfo
08-17 06:45:31.603   243   243 I zygote64: option[13]=-XjdwpOptions:suspend=n,server=y
08-17 06:45:31.603   243   243 I zygote64: option[14]=-XjdwpProvider:default
08-17 06:45:31.603   243   243 I zygote64: option[15]=-Xlockprofthreshold:500
08-17 06:45:31.603   243   243 I zygote64: option[16]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[17]=--runtime-arg
08-17 06:45:31.603   243   243 I zygote64: option[18]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[19]=-Xms64m
08-17 06:45:31.603   243   243 I zygote64: option[20]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[21]=--runtime-arg
08-17 06:45:31.603   243   243 I zygote64: option[22]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[23]=-Xmx64m
08-17 06:45:31.603   243   243 I zygote64: option[24]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[25]=--profile-file=/system/etc/boot-image.prof
08-17 06:45:31.603   243   243 I zygote64: option[26]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[27]=--compiler-filter=speed-profile
08-17 06:45:31.603   243   243 I zygote64: option[28]=-Xcompiler-option
08-17 06:45:31.603   243   243 I zygote64: option[29]=--runtime-arg
08-17 06:45:31.603   243   243 I zygote64: option[30]=-Xcompiler-option
08-17 06:45:31.603   243   243 I zygote64: option[31]=-Xms64m
08-17 06:45:31.603   243   243 I zygote64: option[32]=-Xcompiler-option
08-17 06:45:31.603   243   243 I zygote64: option[33]=--runtime-arg
08-17 06:45:31.603   243   243 I zygote64: option[34]=-Xcompiler-option
08-17 06:45:31.603   243   243 I zygote64: option[35]=-Xmx512m
08-17 06:45:31.603   243   243 I zygote64: option[36]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[37]=--instruction-set-variant=cortex-a53
08-17 06:45:31.603   243   243 I zygote64: option[38]=-Xcompiler-option
08-17 06:45:31.603   243   243 I zygote64: option[39]=--instruction-set-variant=cortex-a53
08-17 06:45:31.603   243   243 I zygote64: option[40]=-Ximage-compiler-option
08-17 06:45:31.603   243   243 I zygote64: option[41]=--instruction-set-features=default
08-17 06:45:31.604   243   243 I zygote64: option[42]=-Xcompiler-option
08-17 06:45:31.604   243   243 I zygote64: option[43]=--instruction-set-features=default
08-17 06:45:31.604   243   243 I zygote64: option[44]=-Duser.locale=en-US
08-17 06:45:31.604   243   243 I zygote64: option[45]=--cpu-abilist=arm64-v8a
08-17 06:45:31.604   243   243 I zygote64: option[46]=-Xcompiler-option
08-17 06:45:31.604   243   243 I zygote64: option[47]=--generate-mini-debug-info
08-17 06:45:31.604   243   243 I zygote64: option[48]=-Xcore-platform-api-policy:just-warn
08-17 06:45:31.604   243   243 I zygote64: option[49]=-Xfingerprint:rockchip/rk3399_Android10/rk3399_Android10:10/QQ2A.200501.001.B3/eng.sdk_pr.20200813.172933:userdebug/release-keys
08-17 06:45:31.606   260   260 D hwc_rk  : RK_GRAPHICS_VER=commit-id:2d4a166
08-17 06:45:31.606   260   260 I hwcomposer-drm: HWC property : hdr_video_by_gles = False
08-17 06:45:31.606   260   260 I HWC2On1Adapter: Found support for HWC virtual displays
08-17 06:45:31.610   260   260 I ServiceManagement: Registered android.hardware.graphics.composer@2.1::IComposer/default (start delay of 376ms)
08-17 06:45:31.611   260   260 I ServiceManagement: Removing namespace from process name android.hardware.graphics.composer@2.1-service to composer@2.1-service.
08-17 06:45:31.613   260   260 I android.hardware.graphics.composer@2.1-service: Registration complete for android.hardware.graphics.composer@2.1::IComposer/default.
08-17 06:45:31.618   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.mapper@3.0::IMapper/default in either framework or device manifest.
08-17 06:45:31.618   260   260 D ComposerHal: failed to get mapper 3.0 service, falling back to mapper 2.0
08-17 06:45:31.626   248   248 I ServiceManagement: Registered android.hardware.audio@5.0::IDevicesFactory/default (start delay of 451ms)
08-17 06:45:31.627   248   248 I ServiceManagement: Removing namespace from process name android.hardware.audio@2.0-service to audio@2.0-service.
08-17 06:45:31.629   174   174 I HWComposer: Switching to legacy multi-display mode
08-17 06:45:31.629   248   248 I audiohalservice: Registration complete for android.hardware.audio@5.0::IDevicesFactory/default.
08-17 06:45:31.630   174   174 D FramebufferSurface: Creating for display 0
08-17 06:45:31.631   136   136 W init    : type=1400 audit(0.0:14): avc: denied { relabelto } for name="boot" dev="tmpfs" ino=19383 scontext=u:r:vendor_init:s0 tcontext=u:object_r:boot_block_device:s0
 tclass=lnk_file permissive=0
08-17 06:45:31.635   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.mapper@3.0::IMapper/default in either framework or device manifest.
08-17 06:45:31.635   174   174 W Gralloc3: mapper 3.x is not supported
08-17 06:45:31.635   243   243 I zygote64: Core platform API reporting enabled, enforcing=false
08-17 06:45:31.639   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.647   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.allocator@3.0::IAllocator/default in either framework or device manifest.
08-17 06:45:31.648   174   174 W Gralloc3: allocator 3.x is not supported
08-17 06:45:31.650   259   296 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 1802; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:31.650   259   296 I GRALLOC-ROCKCHIP: use_afbc_layer: force to set 'internal_format' to 0x100000001 for buffer_for_fb_target_layer.
08-17 06:45:31.659   248   248 I ServiceManagement: Registered android.hardware.audio.effect@5.0::IEffectsFactory/default (start delay of 485ms)
08-17 06:45:31.660   248   248 I audiohalservice: Registration complete for android.hardware.audio.effect@5.0::IEffectsFactory/default.
08-17 06:45:31.661   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.soundtrigger@2.2::ISoundTriggerHw/default in either framework or device manifest.
08-17 06:45:31.662   248   248 E audiohalservice: Could not get passthrough implementation for android.hardware.soundtrigger@2.2::ISoundTriggerHw/default.
08-17 06:45:31.663   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.soundtrigger@2.1::ISoundTriggerHw/default in either framework or device manifest.
08-17 06:45:31.663   248   248 E audiohalservice: Could not get passthrough implementation for android.hardware.soundtrigger@2.1::ISoundTriggerHw/default.
08-17 06:45:31.668   248   248 E SoundTriggerHalImpl: couldn't load sound trigger module sound_trigger.primary (No such file or directory)
08-17 06:45:31.669   259   296 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:31.669   259   296 I GRALLOC-ROCKCHIP: dmabuf_name : 296_12779520_06:45:31.669
08-17 06:45:31.670   248   248 I ServiceManagement: Registered android.hardware.soundtrigger@2.0::ISoundTriggerHw/default (start delay of 496ms)
08-17 06:45:31.671   248   248 I audiohalservice: Registration complete for android.hardware.soundtrigger@2.0::ISoundTriggerHw/default.
08-17 06:45:31.671   174   174 D GRALLOC-ROCKCHIP: RK_GRAPHICS_VER=commit-id:344c4dd
08-17 06:45:31.671   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.bluetooth.audio@2.0::IBluetoothAudioProvidersFactory/default in either framework or device manifest.

08-17 06:45:31.672   248   248 E audiohalservice: Could not get passthrough implementation for android.hardware.bluetooth.audio@2.0::IBluetoothAudioProvidersFactory/default.
08-17 06:45:31.672   248   248 W audiohalservice: Could not register Bluetooth Audio API 2.0
08-17 06:45:31.672   174   174 W libc    : Unable to set property "vendor.gmali.fbdc_target" to "1": error code: 0x18
08-17 06:45:31.673   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 1802; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:31.673   259   259 I GRALLOC-ROCKCHIP: use_afbc_layer: force to set 'internal_format' to 0x100000001 for buffer_for_fb_target_layer.
08-17 06:45:31.673   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.bluetooth.a2dp@1.0::IBluetoothAudioOffload/default in either framework or device manifest.
08-17 06:45:31.674   248   248 E audiohalservice: Could not get passthrough implementation for android.hardware.bluetooth.a2dp@1.0::IBluetoothAudioOffload/default.
08-17 06:45:31.674   248   248 W audiohalservice: Could not register Bluetooth audio offload 1.0
08-17 06:45:31.690   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:31.690   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12779520_06:45:31.690
08-17 06:45:31.693   174   174 W libc    : Unable to set property "vendor.gmali.fbdc_target" to "1": error code: 0x18
08-17 06:45:31.693   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 1802; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:31.693   259   259 I GRALLOC-ROCKCHIP: use_afbc_layer: force to set 'internal_format' to 0x100000001 for buffer_for_fb_target_layer.
08-17 06:45:31.707   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:31.707   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12779520_06:45:31.707
08-17 06:45:31.710   174   174 W libc    : Unable to set property "vendor.gmali.fbdc_target" to "1": error code: 0x18
08-17 06:45:31.719   251   251 W android.hardwar: type=1400 audit(0.0:15): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:hal_camera_default:s0 tcontext=
u:object_r:default_prop:s0 tclass=file permissive=0
08-17 06:45:31.719   251   251 E libc    : Access denied finding property "mpp_mem_debug"
08-17 06:45:31.731   251   251 I vpu_api : dlopen vpu lib /vendor/lib/librk_vpuapi.so success
08-17 06:45:31.741   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.749   174   174 D         : set stream to NULL
08-17 06:45:31.751   174   174 I chatty  : uid=1000(system) /system/bin/surfaceflinger identical 34 lines
08-17 06:45:31.762   174   174 D         : set stream to NULL
08-17 06:45:31.763   317   317 D LibBpfLoader: Loading ELF object /system/etc/bpf/clatd.o with license Apache 2.0
08-17 06:45:31.764   317   317 D LibBpfLoader: Loaded code section 3 (schedcls_ingress_clat_ether)
08-17 06:45:31.764   317   317 D LibBpfLoader: Loaded relo section 3 (.relschedcls/ingress/clat_ether)
08-17 06:45:31.764   317   317 D LibBpfLoader: Adding section 3 to cs list
08-17 06:45:31.764   317   317 D LibBpfLoader: Loaded code section 5 (schedcls_ingress_clat_rawip)
08-17 06:45:31.764   317   317 D LibBpfLoader: Loaded relo section 5 (.relschedcls/ingress/clat_rawip)
08-17 06:45:31.764   317   317 D LibBpfLoader: Adding section 5 to cs list
08-17 06:45:31.766   317   317 D LibBpfLoader: bpf_create_map name clat_ingress_map, ret: 7
08-17 06:45:31.766   317   317 D LibBpfLoader: map_fd found at 0 is 7 in /system/etc/bpf/clatd.o
08-17 06:45:31.766   174   174 D         : set stream to NULL
08-17 06:45:31.768   174   174 D         : set stream to NULL
08-17 06:45:31.769   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 400,           insn offset 50 , insn 118
08-17 06:45:31.769   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 360,               insn offset 45 , insn 118
08-17 06:45:31.771   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/clatd.o (schedcls_ingress_clat_ether) returned: 8
08-17 06:45:31.772   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/clatd.o (schedcls_ingress_clat_rawip) returned: 9
08-17 06:45:31.772   317   317 I bpfloader: Attempted load object: /system/etc/bpf/clatd.o, ret: Success
08-17 06:45:31.776   174   174 D         : set stream to NULL
08-17 06:45:31.777   174   174 D         : set stream to NULL
08-17 06:45:31.779   317   317 D LibBpfLoader: Loading ELF object /system/etc/bpf/netd.o with license Apache 2.0
08-17 06:45:31.779   317   317 D LibBpfLoader: Loaded code section 3 (cgroupskb_ingress_stats)
08-17 06:45:31.779   317   317 D LibBpfLoader: Loaded relo section 3 (.relcgroupskb/ingress/stats)
08-17 06:45:31.779   174   174 D         : set stream to NULL
08-17 06:45:31.780   317   317 D LibBpfLoader: Adding section 3 to cs list
08-17 06:45:31.780   317   317 D LibBpfLoader: Loaded code section 5 (cgroupskb_egress_stats)
08-17 06:45:31.780   317   317 D LibBpfLoader: Loaded relo section 5 (.relcgroupskb/egress/stats)
08-17 06:45:31.780   317   317 D LibBpfLoader: Adding section 5 to cs list
08-17 06:45:31.780   317   317 D LibBpfLoader: Loaded code section 7 (skfilter_egress_xtbpf)
08-17 06:45:31.780   317   317 D LibBpfLoader: Loaded relo section 7 (.relskfilter/egress/xtbpf)
08-17 06:45:31.780   317   317 D LibBpfLoader: Adding section 7 to cs list
08-17 06:45:31.780   317   317 D LibBpfLoader: Loaded code section 9 (skfilter_ingress_xtbpf)
08-17 06:45:31.780   317   317 D LibBpfLoader: Loaded relo section 9 (.relskfilter/ingress/xtbpf)
08-17 06:45:31.780   317   317 D LibBpfLoader: Adding section 9 to cs list
08-17 06:45:31.781   317   317 D LibBpfLoader: Loaded code section 11 (skfilter_whitelist_xtbpf)
08-17 06:45:31.781   317   317 D LibBpfLoader: Loaded relo section 11 (.relskfilter/whitelist/xtbpf)
08-17 06:45:31.781   317   317 D LibBpfLoader: Adding section 11 to cs list
08-17 06:45:31.781   317   317 D LibBpfLoader: Loaded code section 13 (skfilter_blacklist_xtbpf)
08-17 06:45:31.781   317   317 D LibBpfLoader: Loaded relo section 13 (.relskfilter/blacklist/xtbpf)
08-17 06:45:31.781   317   317 D LibBpfLoader: Adding section 13 to cs list
08-17 06:45:31.781   317   317 D LibBpfLoader: Loaded code section 15 (cgroupsock_inet_create)
08-17 06:45:31.781   317   317 D LibBpfLoader: Loaded relo section 15 (.relcgroupsock/inet/create)
08-17 06:45:31.781   317   317 D LibBpfLoader: Adding section 15 to cs list
08-17 06:45:31.786   174   174 D         : set stream to NULL
08-17 06:45:31.787   317   317 D LibBpfLoader: bpf_create_map name cookie_tag_map, ret: 10
08-17 06:45:31.788   317   317 D LibBpfLoader: bpf_create_map name uid_counterset_map, ret: 11
08-17 06:45:31.788   174   174 D         : set stream to NULL
08-17 06:45:31.790   174   174 D         : set stream to NULL
08-17 06:45:31.792   317   317 D LibBpfLoader: bpf_create_map name app_uid_stats_map, ret: 12
08-17 06:45:31.794   317   317 D LibBpfLoader: bpf_create_map name stats_map_A, ret: 13
08-17 06:45:31.796   174   174 D         : set stream to NULL
08-17 06:45:31.800   174   174 D         : set stream to NULL
08-17 06:45:31.802   317   317 D LibBpfLoader: bpf_create_map name stats_map_B, ret: 14
08-17 06:45:31.802   317   317 D LibBpfLoader: bpf_create_map name iface_stats_map, ret: 15
08-17 06:45:31.804   317   317 D LibBpfLoader: bpf_create_map name configuration_map, ret: 16
08-17 06:45:31.804   317   317 D LibBpfLoader: bpf_create_map name uid_owner_map, ret: 17
08-17 06:45:31.805   317   317 D LibBpfLoader: bpf_create_map name iface_index_name_map, ret: 18
08-17 06:45:31.806   317   317 D LibBpfLoader: bpf_create_map name uid_permission_map, ret: 19
08-17 06:45:31.812   174   174 D         : set stream to NULL
08-17 06:45:31.817   316   332 I adbd    : opening control endpoint /dev/usb-ffs/adb/ep0
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 0 is 10 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 1 is 11 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 2 is 12 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 3 is 13 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 4 is 14 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 5 is 15 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 6 is 16 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 7 is 17 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 8 is 18 in /system/etc/bpf/netd.o
08-17 06:45:31.817   317   317 D LibBpfLoader: map_fd found at 9 is 19 in /system/etc/bpf/netd.o
08-17 06:45:31.818   322   322 I installd: installd firing up
08-17 06:45:31.823   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 616,           insn offset 77 , insn 118
08-17 06:45:31.823   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 688,           insn offset 86 , insn 118
08-17 06:45:31.823   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1040,          insn offset 130 , insn 118
08-17 06:45:31.824   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1184,          insn offset 148 , insn 118
08-17 06:45:31.826   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1264,          insn offset 158 , insn 118
08-17 06:45:31.827   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1368,          insn offset 171 , insn 118
08-17 06:45:31.827   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1472,          insn offset 184 , insn 118
08-17 06:45:31.827   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1512,              insn offset 189 , insn 118
08-17 06:45:31.828   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1576,          insn offset 197 , insn 118
08-17 06:45:31.828   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1680,          insn offset 210 , insn 118
08-17 06:45:31.828   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1720,          insn offset 215 , insn 118
08-17 06:45:31.828   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1848,          insn offset 231 , insn 118
08-17 06:45:31.829   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1952,          insn offset 244 , insn 118
08-17 06:45:31.829   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1992,          insn offset 249 , insn 118
08-17 06:45:31.829   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2056,          insn offset 257 , insn 118
08-17 06:45:31.829   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2160,              insn offset 270 , insn 118
08-17 06:45:31.830   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2200,          insn offset 275 , insn 118
08-17 06:45:31.832   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2288,          insn offset 286 , insn 118
08-17 06:45:31.833   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2392,          insn offset 299 , insn 118
08-17 06:45:31.833   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2432,          insn offset 304 , insn 118
08-17 06:45:31.833   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 608,           insn offset 76 , insn 118
08-17 06:45:31.833   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 680,           insn offset 85 , insn 118
08-17 06:45:31.833   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 904,               insn offset 113 , insn 118
08-17 06:45:31.833   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1048,          insn offset 131 , insn 118
08-17 06:45:31.833   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1128,          insn offset 141 , insn 118
08-17 06:45:31.834   174   174 D         : set stream to NULL
08-17 06:45:31.834   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1232,          insn offset 154 , insn 118
08-17 06:45:31.834   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1336,          insn offset 167 , insn 118
08-17 06:45:31.834   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1376,          insn offset 172 , insn 118
08-17 06:45:31.836   174   174 D         : set stream to NULL
08-17 06:45:31.836   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1440,          insn offset 180 , insn 118
08-17 06:45:31.836   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1544,              insn offset 193 , insn 118
08-17 06:45:31.837   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1584,          insn offset 198 , insn 118
08-17 06:45:31.837   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1712,          insn offset 214 , insn 118
08-17 06:45:31.847   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.852   251   251 D RkCamera: Debug log file is not enabled
08-17 06:45:31.852   251   251 I Camera3HALModule: @initCameraHAL: RockChip Camera Hal3 Release version v2.1.0
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1816,          insn offset 227 , insn 118
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1856,          insn offset 232 , insn 118
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 1920,              insn offset 240 , insn 118
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2024,          insn offset 253 , insn 118
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2064,          insn offset 258 , insn 118
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2152,          insn offset 269 , insn 118
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2256,          insn offset 282 , insn 118
08-17 06:45:31.852   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 2296,          insn offset 287 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 40,            insn offset 5 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 144,           insn offset 18 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 184,               insn offset 23 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 40,            insn offset 5 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 144,           insn offset 18 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 184,           insn offset 23 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 136,           insn offset 17 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 32,            insn offset 4 , insn 118
08-17 06:45:31.853   317   317 D LibBpfLoader: applying relo to instruction at byte offset: 80,            insn offset 10 , insn 118
08-17 06:45:31.855   174   174 D         : set stream to NULL
08-17 06:45:31.859   174   174 D         : set stream to NULL
08-17 06:45:31.866   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/netd.o (cgroupskb_ingress_stats) returned: 20
08-17 06:45:31.869   174   174 D         : set stream to NULL
08-17 06:45:31.871   174   174 D         : set stream to NULL
08-17 06:45:31.873   316   332 I adbd    : UsbFfsConnection constructed
08-17 06:45:31.873   174   174 D         : set stream to NULL
08-17 06:45:31.879   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/netd.o (cgroupskb_egress_stats) returned: 21
08-17 06:45:31.884   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/netd.o (skfilter_egress_xtbpf) returned: 22
08-17 06:45:31.884   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/netd.o (skfilter_ingress_xtbpf) returned: 23
08-17 06:45:31.885   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/netd.o (skfilter_whitelist_xtbpf) returned: 24
08-17 06:45:31.885   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/netd.o (skfilter_blacklist_xtbpf) returned: 25
08-17 06:45:31.886   317   317 D LibBpfLoader: New bpf core prog_load for /system/etc/bpf/netd.o (cgroupsock_inet_create) returned: 26
08-17 06:45:31.886   317   317 I bpfloader: Attempted load object: /system/etc/bpf/netd.o, ret: Success
08-17 06:45:31.886   174   174 D         : set stream to NULL
08-17 06:45:31.891   174   174 D         : set stream to NULL
08-17 06:45:31.911   251   251 E RkCamera: <HAL> PlatformData: ERROR no sensor driver registered in media controller!
08-17 06:45:31.911   251   251 E RkCamera: <HAL> Profiles: No sensor Info available, exit parsing
08-17 06:45:31.911   174   174 D         : set stream to NULL
08-17 06:45:31.911   251   251 E RkCamera: <HAL> ChromeProfiles: CameraProfiles base init error:-2147483648
08-17 06:45:31.911   251   251 E RkCamera: <HAL> PlatformData: Failed to initialize Camera profiles
08-17 06:45:31.911   251   251 E RkCamera: <HAL> PlatformData: @getInstance Failed to create CameraProfiles instance
08-17 06:45:31.911   251   251 E RkCamera: <HAL> Camera3HALModule: No camera device was found!
08-17 06:45:31.912   242   242 D TetherController: Setting IP forward enable = 0
08-17 06:45:31.912   316   343 I adbd    : USB event: FUNCTIONFS_BIND
08-17 06:45:31.914   242   242 D FirewallController: Could not read /proc/self/uid_map, max uid defaulting to 4294967294
08-17 06:45:31.914   174   174 D         : set stream to NULL
08-17 06:45:31.936   174   174 D         : set stream to NULL
08-17 06:45:31.947   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:31.949   174   174 D         : set stream to NULL
08-17 06:45:31.952   174   174 D         : set stream to NULL
08-17 06:45:31.952   341   341 I /system/bin/tombstoned: tombstoned successfully initialized
08-17 06:45:31.953   174   174 D         : set stream to NULL
08-17 06:45:31.957   344   344 W move_widevine_d: type=1400 audit(0.0:16): avc: denied { search } for name="mediadrm" dev="mmcblk2p15" ino=32461 scontext=u:r:move-widevine-data-sh:s0 tcontext=u:object
_r:mediadrm_vendor_data_file:s0 tclass=dir permissive=0
08-17 06:45:31.957   344   344 W move_widevine_d: type=1400 audit(0.0:17): avc: denied { read } for name="mediadrm" dev="mmcblk2p15" ino=194689 scontext=u:r:move-widevine-data-sh:s0 tcontext=u:object_
r:media_data_file:s0 tclass=dir permissive=0
08-17 06:45:31.957   344   344 W move_widevine_d: type=1400 audit(0.0:18): avc: denied { search } for name="mediadrm" dev="mmcblk2p15" ino=194689 scontext=u:r:move-widevine-data-sh:s0 tcontext=u:objec
t_r:media_data_file:s0 tclass=dir permissive=0
08-17 06:45:31.961   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.usb.gadget@1.0::IUsbGadget/default in either framework or device manifest.
08-17 06:45:31.962   251   251 D RkCamera: Debug log file is not enabled
08-17 06:45:31.962   251   251 E RkCamera: <HAL> PlatformData: @getInstance Failed to create CameraProfiles instance
08-17 06:45:31.962   251   251 I CamPrvdr@2.4-legacy: Loaded "Rockchip Camera3HAL Module" camera module
08-17 06:45:31.966   174   174 D         : set stream to NULL
08-17 06:45:31.969   342   342 I usbd    : Usb HAL not found
08-17 06:45:31.971   174   174 D         : set stream to NULL
08-17 06:45:31.985   174   174 D         : set stream to NULL
08-17 06:45:31.986   251   251 D RkCamera: Debug log file is not enabled
08-17 06:45:31.986   251   251 E RkCamera: <HAL> PlatformData: @getInstance Failed to create CameraProfiles instance
08-17 06:45:31.988   251   251 I ServiceManagement: Registered android.hardware.camera.provider@2.4::ICameraProvider/legacy/0 (start delay of 794ms)
08-17 06:45:31.988   251   251 I ServiceManagement: Removing namespace from process name android.hardware.camera.provider@2.4-service to provider@2.4-service.
08-17 06:45:31.989   251   251 I android.hardware.camera.provider@2.4-service: Registration complete for android.hardware.camera.provider@2.4::ICameraProvider/legacy/0.
08-17 06:45:31.989   174   174 D         : set stream to NULL
08-17 06:45:32.007   174   174 D         : set stream to NULL
08-17 06:45:32.008   350   350 W restorecon: type=1400 audit(0.0:19): avc: denied { map } for path="/system/etc/selinux/plat_file_contexts" dev="dm-0" ino=1250 scontext=u:r:move-widevine-data-sh:s0 tc
ontext=u:object_r:file_contexts_file:s0 tclass=file permissive=0
08-17 06:45:32.011   344   344 W move_widevine_d: type=1400 audit(0.0:20): avc: denied { search } for name="mediadrm" dev="mmcblk2p15" ino=32461 scontext=u:r:move-widevine-data-sh:s0 tcontext=u:object
_r:mediadrm_vendor_data_file:s0 tclass=dir permissive=0
08-17 06:45:32.017   174   174 D         : set stream to NULL
08-17 06:45:32.020   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.keymaster@4.0::IKeymasterDevice/default in either framework or device manifest.
08-17 06:45:32.021   174   174 D         : set stream to NULL
08-17 06:45:32.023   174   174 D         : set stream to NULL
08-17 06:45:32.023   323   323 I keystore: found android.hardware.keymaster@3.0::IKeymasterDevice with interface name default and seclevel TRUSTED_ENVIRONMENT
08-17 06:45:32.028   333   333 I AKMD2   : start in akmd
08-17 06:45:32.028   333   333 I AKMD2   : AKMD PG and DOEPlus v20140729 (Library for AK8963: v7.2.0.729.314) started.
08-17 06:45:32.029   333   333 I AKMD2   : Debug: ON
08-17 06:45:32.029   333   333 E AKMD2   : AKD_InitDevice:99 open Error (No such file or directory).
08-17 06:45:32.029   333   333 I AKMD2   : AKMD end (-2).
08-17 06:45:32.031   330   330 I wificond: wificond is starting up...
08-17 06:45:32.035   174   174 D         : set stream to NULL
08-17 06:45:32.039   174   174 D         : set stream to NULL
08-17 06:45:32.042   323   323 I ServiceManagement: Registered android.system.wifi.keystore@1.0::IKeystore/default (start delay of 308ms)
08-17 06:45:32.046   174   174 D         : set stream to NULL
08-17 06:45:32.047   324   324 I mediaserver: ServiceManager: 0xf4349120
08-17 06:45:32.048   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:32.048   174   174 D         : set stream to NULL
08-17 06:45:32.050   174   174 D         : set stream to NULL
08-17 06:45:32.057   336   336 I ServiceManagement: Registered android.hardware.radio@1.1::IRadio/slot1 (start delay of 222ms)
08-17 06:45:32.058   336   336 I ServiceManagement: Registered android.hardware.radio.deprecated@1.0::IOemHook/slot1 (start delay of 224ms)
08-17 06:45:32.058   174   174 D         : set stream to NULL
08-17 06:45:32.061   174   174 D         : set stream to NULL
08-17 06:45:32.074   174   174 D         : set stream to NULL
08-17 06:45:32.076   242   242 I netd    : Creating child chains: 138.4ms
08-17 06:45:32.076   242   242 I netd    : Setting up OEM hooks: 0.3ms
08-17 06:45:32.076   242   242 I netd    : Setting up FirewallController hooks: 0.1ms
08-17 06:45:32.077   174   174 D         : set stream to NULL
08-17 06:45:32.080   242   242 I netd    : Setting up TetherController hooks: 4.1ms
08-17 06:45:32.084   174   174 D         : set stream to NULL
08-17 06:45:32.088   174   174 D         : set stream to NULL
08-17 06:45:32.093   334   334 D DrmService: ----------------running drmservice---------------
08-17 06:45:32.093   242   242 I netd    : Setting up BandwidthController hooks: 12.9ms
08-17 06:45:32.093   334   334 E DrmService: rknand_sys_storage open fail
08-17 06:45:32.093   242   242 I netd    : Setting up IdletimerController hooks: 0.2ms
08-17 06:45:32.093   334   334 D DrmService: Get HID data:
08-17 06:45:32.094   326   326 I mediametrics: ServiceManager: 0x72a955e280
08-17 06:45:32.095   326   326 D MediaAnalyticsService: MediaAnalyticsService created
08-17 06:45:32.096   174   174 D         : set stream to NULL
08-17 06:45:32.100   174   174 D         : set stream to NULL
08-17 06:45:32.101   242   242 I netd    : Setting up StrictController hooks: 7.4ms
08-17 06:45:32.101   242   242 I ClatdController: 4.9+ kernel and device shipped with Q+ - clat ebpf should work.
08-17 06:45:32.101   242   242 I netd    : Initializing ClatdController: 0.4ms
08-17 06:45:32.103   242   242 I netd    : Initializing traffic control: 1.9ms
08-17 06:45:32.105   328   328 I ServiceManagement: Registered android.frameworks.stats@1.0::IStats/default (start delay of 330ms)
08-17 06:45:32.106   328   328 W statsd  : statscompanion service unavailable!
08-17 06:45:32.107   174   174 D         : set stream to NULL
08-17 06:45:32.112   174   174 D         : set stream to NULL
08-17 06:45:32.114   328   328 I statsd  : Statsd starts to listen to socket.
08-17 06:45:32.119   174   174 D         : set stream to NULL
08-17 06:45:32.121   174   174 D         : set stream to NULL
08-17 06:45:32.123   244   244 D AndroidRuntime: >>>>>> START com.android.internal.os.ZygoteInit uid 0 <<<<<<
08-17 06:45:32.123   174   174 D         : set stream to NULL
08-17 06:45:32.124   334   334 E DrmService: Unable to open path (/sys/class/android_usb/android0/iSerial),error is(No such file or directory)
08-17 06:45:32.124   334   334 E DrmService: try /config/usb_gadget/g1/strings/0x409/serialnumber
08-17 06:45:32.132   174   174 D         : set stream to NULL
08-17 06:45:32.132   242   242 I netd    : Enabling bandwidth control: 28.8ms
08-17 06:45:32.134   174   174 D         : set stream to NULL
08-17 06:45:32.137   174   174 D         : set stream to NULL
08-17 06:45:32.139   242   242 E Netd    : cannot find interface dummy0
08-17 06:45:32.140   242   242 I netd    : Initializing RouteController: 7.7ms
08-17 06:45:32.140   242   242 D XfrmController: XfrmController::ipSecAddXfrmInterface, line=1379
08-17 06:45:32.142   242   242 D XfrmController: XfrmController::ipSecRemoveTunnelInterface, line=1592
08-17 06:45:32.142   242   242 D XfrmController: deviceName=ipsec_test
08-17 06:45:32.146   174   174 D         : set stream to NULL
08-17 06:45:32.148   174   174 D         : set stream to NULL
08-17 06:45:32.149   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:32.151   174   174 D         : set stream to NULL
08-17 06:45:32.156   242   242 D XfrmController: Sending Netlink XFRM Message: XFRM_MSG_FLUSHSA
08-17 06:45:32.156   242   242 D XfrmController: Sending Netlink XFRM Message: XFRM_MSG_FLUSHPOLICY
08-17 06:45:32.156   242   242 I netd    : Initializing XfrmController: 16.6ms
08-17 06:45:32.160   242   242 E Netd    : Unable to create netlink socket for family 5: Protocol not supported
08-17 06:45:32.160   242   242 W Netd    : Unable to open qlog quota socket, check if xt_quota2 can send via UeventHandler
08-17 06:45:32.160   174   174 D         : set stream to NULL
08-17 06:45:32.162   174   174 D         : set stream to NULL
08-17 06:45:32.163   242   242 I libnetd_resolv: resolv_init: Initializing resolver
08-17 06:45:32.165   242   242 D MDnsDS  : MDnsSdListener::Hander starting up
08-17 06:45:32.165   174   174 D         : set stream to NULL
08-17 06:45:32.165   242   372 D MDnsDS  : MDnsSdListener starting to monitor
08-17 06:45:32.165   242   372 D MDnsDS  : Going to poll with pollCount 1
08-17 06:45:32.166   242   242 I netd    : Registering NetdNativeService: 0.5ms
08-17 06:45:32.169   242   242 I ServiceManagement: Registered android.system.net.netd@1.1::INetd/default (start delay of 1064ms)
08-17 06:45:32.169   242   242 I netd    : Registering NetdHwService: 3.4ms
08-17 06:45:32.169   242   242 I netd    : Netd started in 944ms
08-17 06:45:32.174   174   174 D         : set stream to NULL
08-17 06:45:32.175   340   340 I gatekeeperd: Starting gatekeeperd...
08-17 06:45:32.176   174   174 D         : set stream to NULL
08-17 06:45:32.179   244   244 I AndroidRuntime: Using default boot image
08-17 06:45:32.179   244   244 I AndroidRuntime: Leaving lock profiling enabled
08-17 06:45:32.179   174   174 D         : set stream to NULL
08-17 06:45:32.192   174   174 D         : set stream to NULL
08-17 06:45:32.197   331   331 I media.codec: mediacodecservice starting
08-17 06:45:32.198   244   244 I zygote  : option[0]=-Xzygote
08-17 06:45:32.198   244   244 I zygote  : option[1]=exit
08-17 06:45:32.198   244   244 I zygote  : option[2]=vfprintf
08-17 06:45:32.198   244   244 I zygote  : option[3]=sensitiveThread
08-17 06:45:32.198   244   244 I zygote  : option[4]=-verbose:gc
08-17 06:45:32.198   244   244 I zygote  : option[5]=-Xms16m
08-17 06:45:32.198   244   244 I zygote  : option[6]=-Xmx512m
08-17 06:45:32.198   244   244 I zygote  : option[7]=-XX:HeapGrowthLimit=192m
08-17 06:45:32.198   244   244 I zygote  : option[8]=-XX:HeapMinFree=512k
08-17 06:45:32.198   244   244 I zygote  : option[9]=-XX:HeapMaxFree=8m
08-17 06:45:32.198   244   244 I zygote  : option[10]=-XX:HeapTargetUtilization=0.75
08-17 06:45:32.198   244   244 I zygote  : option[11]=-Xusejit:true
08-17 06:45:32.198   244   244 I zygote  : option[12]=-Xjitsaveprofilinginfo
08-17 06:45:32.198   244   244 I zygote  : option[13]=-XjdwpOptions:suspend=n,server=y
08-17 06:45:32.199   244   244 I zygote  : option[14]=-XjdwpProvider:default
08-17 06:45:32.199   244   244 I zygote  : option[15]=-Xlockprofthreshold:500
08-17 06:45:32.199   244   244 I zygote  : option[16]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[17]=--runtime-arg
08-17 06:45:32.199   244   244 I zygote  : option[18]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[19]=-Xms64m
08-17 06:45:32.199   244   244 I zygote  : option[20]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[21]=--runtime-arg
08-17 06:45:32.199   244   244 I zygote  : option[22]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[23]=-Xmx64m
08-17 06:45:32.199   244   244 I zygote  : option[24]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[25]=--profile-file=/system/etc/boot-image.prof
08-17 06:45:32.199   244   244 I zygote  : option[26]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[27]=--compiler-filter=speed-profile
08-17 06:45:32.199   244   244 I zygote  : option[28]=-Xcompiler-option
08-17 06:45:32.199   244   244 I zygote  : option[29]=--runtime-arg
08-17 06:45:32.199   244   244 I zygote  : option[30]=-Xcompiler-option
08-17 06:45:32.199   244   244 I zygote  : option[31]=-Xms64m
08-17 06:45:32.199   244   244 I zygote  : option[32]=-Xcompiler-option
08-17 06:45:32.199   244   244 I zygote  : option[33]=--runtime-arg
08-17 06:45:32.199   244   244 I zygote  : option[34]=-Xcompiler-option
08-17 06:45:32.199   244   244 I zygote  : option[35]=-Xmx512m
08-17 06:45:32.199   244   244 I zygote  : option[36]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[37]=--instruction-set-variant=cortex-a15
08-17 06:45:32.199   244   244 I zygote  : option[38]=-Xcompiler-option
08-17 06:45:32.199   244   244 I zygote  : option[39]=--instruction-set-variant=cortex-a15
08-17 06:45:32.199   244   244 I zygote  : option[40]=-Ximage-compiler-option
08-17 06:45:32.199   244   244 I zygote  : option[41]=--instruction-set-features=default
08-17 06:45:32.199   244   244 I zygote  : option[42]=-Xcompiler-option
08-17 06:45:32.199   244   244 I zygote  : option[43]=--instruction-set-features=default
08-17 06:45:32.199   244   244 I zygote  : option[44]=-Duser.locale=en-US
08-17 06:45:32.199   244   244 I zygote  : option[45]=--cpu-abilist=armeabi-v7a,armeabi
08-17 06:45:32.199   244   244 I zygote  : option[46]=-Xcompiler-option
08-17 06:45:32.199   244   244 I zygote  : option[47]=--generate-mini-debug-info
08-17 06:45:32.199   244   244 I zygote  : option[48]=-Xcore-platform-api-policy:just-warn
08-17 06:45:32.199   244   244 I zygote  : option[49]=-Xfingerprint:rockchip/rk3399_Android10/rk3399_Android10:10/QQ2A.200501.001.B3/eng.sdk_pr.20200813.172933:userdebug/release-keys
08-17 06:45:32.201   174   174 D         : set stream to NULL
08-17 06:45:32.206   174   174 D         : set stream to NULL
08-17 06:45:32.208   331   331 W media.codec: libminijail[331]: failed to get path of fd 5: No such file or directory
08-17 06:45:32.208   331   331 W media.codec: libminijail[331]: allowing syscall: clock_gettime
08-17 06:45:32.208   331   331 W media.codec: libminijail[331]: allowing syscall: connect
08-17 06:45:32.208   331   331 W media.codec: libminijail[331]: allowing syscall: fcntl64
08-17 06:45:32.208   331   331 W media.codec: libminijail[331]: allowing syscall: socket
08-17 06:45:32.208   331   331 W media.codec: libminijail[331]: allowing syscall: writev
08-17 06:45:32.210   331   331 W media.codec: libminijail[331]: logging seccomp filter failures
08-17 06:45:32.214   174   174 D         : set stream to NULL
08-17 06:45:32.216   174   174 D         : set stream to NULL
08-17 06:45:32.219   244   244 I zygote  : Core platform API reporting enabled, enforcing=false
08-17 06:45:32.219   174   174 D         : set stream to NULL
08-17 06:45:32.227   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(59): in
08-17 06:45:32.227   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(73): in
08-17 06:45:32.228   174   174 D         : set stream to NULL
08-17 06:45:32.230   174   174 D         : set stream to NULL
08-17 06:45:32.232   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:32.233   174   174 D         : set stream to NULL
08-17 06:45:32.239   331   331 W android.hardwar: type=1400 audit(0.0:21): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object
_r:default_prop:s0 tclass=file permissive=0
08-17 06:45:32.240   331   331 E libc    : Access denied finding property "mpp_mem_debug"
08-17 06:45:32.241   331   331 I vpu_api : dlopen vpu lib /vendor/lib/librk_vpuapi.so success
08-17 06:45:32.241   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(75): in so name: libomxvpu_dec.so
08-17 06:45:32.241   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(81): in num: 11
08-17 06:45:32.242   331   331 E omx_log : Rockchip_OMX_COMPONENT_Library_Register(50): in
08-17 06:45:32.242   271   271 I FastMixerState: sMaxFastTracks = 8
08-17 06:45:32.242   331   331 I chatty  : uid=1046(mediacodec) omx@1.0-service expire 7 lines
08-17 06:45:32.242   331   331 E omx_log : Rockchip_OMX_COMPONENT_Library_Register(50): in
08-17 06:45:32.242   331   331 E omx_log : Rockchip_OMX_COMPONENT_Library_Register(50): in
08-17 06:45:32.242   331   331 E omx_log : Rockchip_OMX_COMPONENT_Library_Register(50): in
08-17 06:45:32.242   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(110): Rockchip_OSAL_dlerror: (null)
08-17 06:45:32.242   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(73): in
08-17 06:45:32.242   174   174 D         : set stream to NULL
08-17 06:45:32.244   271   271 V MediaUtils: physMem: 4026286080
08-17 06:45:32.244   271   271 V MediaUtils: requested limit: 536870912
08-17 06:45:32.244   271   271 I libc    : malloc_limit: Allocation limit enabled, max size 536870912 bytes
08-17 06:45:32.245   174   174 D         : set stream to NULL
08-17 06:45:32.245   271   271 I audioserver: ServiceManager: 0x78d8b54dc0
08-17 06:45:32.245   271   271 W BatteryNotifier: batterystats service unavailable!
08-17 06:45:32.247   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(75): in so name: libomxvpu_enc.so
08-17 06:45:32.247   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(81): in num: 1
08-17 06:45:32.248   174   174 D         : set stream to NULL
08-17 06:45:32.248   331   331 E omx_comp_regs: Rockchip_OMX_Component_Register(110): Rockchip_OSAL_dlerror: (null)
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.avc
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.m4v
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.h263
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.flv1
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.m2v
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.vp8
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.vp9
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.vc1
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.wmv3
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.hevc
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_decoder.mjpeg
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: declares component OMX.rk.video_encoder.avc
08-17 06:45:32.248   331   331 I libstagefrighthw: OMX IL core libOMX_Core.so: contains 12 components
08-17 06:45:32.249   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:32.251   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.audio@5.0::IDevicesFactory/msd in either framework or device manifest.
08-17 06:45:32.256   331   331 I SoftOMXPlugin: createOMXPlugin
08-17 06:45:32.258   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs.xml...
08-17 06:45:32.258   271   271 I AudioFlinger: Using default 3000 mSec as standby time.
08-17 06:45:32.259   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_google_audio.xml...
08-17 06:45:32.261   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:32.261   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:32.261   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 8000-320000
08-17 06:45:32.261   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.261   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.261   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:32.261   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 7350,8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 32000-500000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 48000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 6000-510000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.262   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 6
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 1-655350
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-21000000
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: complexity-default = 5
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: complexity-range = 0-8
08-17 06:45:32.263   174   174 D         : set stream to NULL
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CQ
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: size-range = 96x96-4096x2160
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-489600
08-17 06:45:32.263   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 30-30
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: size-range = 182x144-1920x1088
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: block-size = 16x8
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.264   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.265   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.266   174   174 D         : set stream to NULL
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: size-range = 400x400-4096x2160
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 60-60
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: size-range = 96x96-4096x2160
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-972000
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-300000000
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 60-60
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: alignment = 16x8
08-17 06:45:32.266   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.267   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:32.267   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 4
08-17 06:45:32.267   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 30-30
08-17 06:45:32.267   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_google_video.xml...
08-17 06:45:32.269   174   174 D         : set stream to NULL
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-983040
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.271   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 32
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 32
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-983040
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-176x144
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-128000
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: size-range = 16x16-176x144
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 12-1485
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-64000
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1280x720
08-17 06:45:32.272   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.273   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.273   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:32.273   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1280x720
08-17 06:45:32.273   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.273   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.273   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:32.273   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_performance.xml...
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 165-165
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 149-149
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 73-73
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 18-18
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 306-306
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 54-54
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 58-58
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 619-619
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 619-619
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 55-55
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 35-35
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 28-28
08-17 06:45:32.276   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 32-32
08-17 06:45:32.277   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 44 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.277   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 50 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.277   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 53 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.277   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 56 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.277   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 617-617
08-17 06:45:32.277   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 559-559
08-17 06:45:32.277   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 276-276
08-17 06:45:32.277   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 164-164
08-17 06:45:32.277   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-3840x2160-range = 30-30
08-17 06:45:32.277   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 500-500
08-17 06:45:32.277   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 387-387
08-17 06:45:32.278   271   271 E APM::Serializer: deserialize: Could not parse /odm/etc/audio_policy_configuration.xml document.
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 112-112
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 77-77
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 600-600
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 600-600
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 600-600
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 700-700
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 700-700
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 980-980
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 600-600
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 130-130
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-3840x2160-range = 130-130
08-17 06:45:32.278   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 230-230
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 132-132
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-38
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 51-51
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 253-253
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 128-128
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 104-104
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 91-91
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 48-48
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 24-24
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-42
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 94-94
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 500-500
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 387-387
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 310-318
08-17 06:45:32.279   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 150-200
08-17 06:45:32.280   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 124 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.280   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 130 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.280   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 136 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.280   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 139 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.280   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 142 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.280   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 148 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.280   331   331 D MediaCodecsXmlParser: Cannot find /data/misc/media/media_codecs_profiling_results.xml
08-17 06:45:32.282   174   174 D         : set stream to NULL
08-17 06:45:32.283   331   331 I ServiceManagement: Registered android.hardware.media.omx@1.0::IOmx/default (start delay of 498ms)
08-17 06:45:32.283   331   331 I ServiceManagement: Removing namespace from process name android.hardware.media.omx@1.0-service to omx@1.0-service.
08-17 06:45:32.283   331   331 I media.codec: IOmx HAL service created.
08-17 06:45:32.284   325   325 V MediaUtils: physMem: 4026286080
08-17 06:45:32.285   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs.xml...
08-17 06:45:32.285   174   174 D         : set stream to NULL
08-17 06:45:32.285   325   325 V MediaUtils: requested limit: 805257200
08-17 06:45:32.285   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_google_audio.xml...
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 8000-320000
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:32.285   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 7350,8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:32.286   325   325 I libc    : malloc_limit: Allocation limit enabled, max size 805257200 bytes
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 32000-500000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 48000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 6000-510000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 6
08-17 06:45:32.286   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: sample-rate-ranges = 1-655350
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-21000000
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: complexity-default = 5
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: complexity-range = 0-8
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CQ
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: size-range = 96x96-4096x2160
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-489600
08-17 06:45:32.287   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.288   174   174 D         : set stream to NULL
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 30-30
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: size-range = 182x144-1920x1088
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: block-size = 16x8
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.288   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.289   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.290   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.290   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.290   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:32.290   331   331 I MediaCodecsXmlParser: limit: size-range = 400x400-4096x2160
08-17 06:45:32.290   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.290   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.290   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 60-60
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: size-range = 96x96-4096x2160
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-972000
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-300000000
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:32.291   331   331 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 60-60
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: alignment = 16x8
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 4
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 30-30
08-17 06:45:32.292   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_google_video.xml...
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-983040
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.292   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 32
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: max-concurrent-instances = 32
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-983040
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-176x144
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-128000
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: size-range = 16x16-176x144
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: blocks-per-second-range = 12-1485
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-64000
08-17 06:45:32.293   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1280x720
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: size-range = 176x144-1280x720
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:32.294   331   331 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_performance.xml...
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 165-165
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 149-149
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 73-73
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 18-18
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 306-306
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 54-54
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 58-58
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 619-619
08-17 06:45:32.294   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 619-619
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 55-55
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 35-35
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 28-28
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 32-32
08-17 06:45:32.295   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 44 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.295   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 50 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.295   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 53 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.295   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 56 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 617-617
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 559-559
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 276-276
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 164-164
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-3840x2160-range = 30-30
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 500-500
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 387-387
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 112-112
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 77-77
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 600-600
08-17 06:45:32.295   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 600-600
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 600-600
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 700-700
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 700-700
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 980-980
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 600-600
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 130-130
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-3840x2160-range = 130-130
08-17 06:45:32.296   325   325 W /system/bin/mediaextractor: Could not read additional policy file '/vendor/etc/seccomp_policy/mediaextractor.policy'
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 230-230
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 132-132
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-38
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 51-51
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 253-253
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 128-128
08-17 06:45:32.296   325   325 W /system/bin/mediaextractor: libminijail[325]: failed to get path of fd 5: No such file or directory
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 104-104
08-17 06:45:32.296   325   325 W /system/bin/mediaextractor: libminijail[325]: allowing syscall: connect
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 91-91
08-17 06:45:32.296   325   325 W /system/bin/mediaextractor: libminijail[325]: allowing syscall: fcntl
08-17 06:45:32.296   325   325 W /system/bin/mediaextractor: libminijail[325]: allowing syscall: sendto
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:32.296   325   325 W /system/bin/mediaextractor: libminijail[325]: allowing syscall: socket
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:32.296   325   325 W /system/bin/mediaextractor: libminijail[325]: allowing syscall: writev
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 48-48
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 24-24
08-17 06:45:32.296   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:32.297   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:32.297   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-42
08-17 06:45:32.297   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 94-94
08-17 06:45:32.297   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 500-500
08-17 06:45:32.297   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 387-387
08-17 06:45:32.297   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 310-318
08-17 06:45:32.297   331   331 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 150-200
08-17 06:45:32.297   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 124 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.297   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 130 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.297   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 136 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.297   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 139 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.297   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 142 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.297   331   331 D MediaCodecsXmlParser: MediaCodec: cannot update non-existing codec at line 148 of /vendor/etc/media_codecs_performance.xml
08-17 06:45:32.297   331   331 D MediaCodecsXmlParser: Cannot find /data/misc/media/media_codecs_profiling_results.xml
08-17 06:45:32.298   331   331 E MediaCodecsXmlParser: Cannot find the role for a decoder of type video/flv
08-17 06:45:32.298   331   331 E MediaCodecsXmlParser: Cannot find the role for a decoder of type video/mjpeg
08-17 06:45:32.299   271   271 E APM::AudioPolicyEngine/Config: parse: Could not parse document /vendor/etc/audio_policy_engine_configuration.xml
08-17 06:45:32.299   271   271 W APM::AudioPolicyEngine/Base: loadAudioPolicyEngineConfig: No configuration found, using default matching phone experience.
08-17 06:45:32.299   271   271 E APM::AudioPolicyEngine/Config: parseLegacyVolumeFile: Could not parse document /odm/etc/audio_policy_configuration.xml
08-17 06:45:32.302   331   331 I ServiceManagement: Registered android.hardware.media.omx@1.0::IOmxStore/default (start delay of 518ms)
08-17 06:45:32.302   331   331 I ServiceManagement: Removing namespace from process name android.hardware.media.omx@1.0-service to omx@1.0-service.
08-17 06:45:32.302   174   174 D         : set stream to NULL
08-17 06:45:32.305   325   325 W /system/bin/mediaextractor: libminijail[325]: logging seccomp filter failures
08-17 06:45:32.305   174   174 D         : set stream to NULL
08-17 06:45:32.328   174   174 D         : set stream to NULL
08-17 06:45:32.331   248   248 D AudioHardwareTiny: ALSA Audio Version: V1.1.0
08-17 06:45:32.331   248   248 D AudioHardwareTiny: adev_open_init
08-17 06:45:32.333   248   312 W DeviceHAL: Error from HAL Device in function set_master_volume: Function not implemented
08-17 06:45:32.333   271   271 I AudioFlinger: loadHwModule() Loaded primary audio interface, handle 10
08-17 06:45:32.333   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:32.335   271   271 I AudioFlinger: openOutput() this 0x78d8b5f600, module 10 Device 0x2, SamplingRate 48000, Format 0x000001, Channels 0x3, flags 0x2
08-17 06:45:32.335   248   248 D AudioHardwareTiny: audio hal adev_open_output_stream devices = 0x2, flags = 2, samplerate = 48000,format = 0x1
08-17 06:45:32.335   248   248 D AudioHardwareTiny: out->config.rate = 44100, out->config.channels = 2 out->config.format = 0
08-17 06:45:32.341   271   271 I AudioFlinger: HAL output buffer size 512 frames, normal sink buffer size 1024 frames
08-17 06:45:32.343   174   174 D         : set stream to NULL
08-17 06:45:32.349   174   174 D         : set stream to NULL
08-17 06:45:32.349   338   338 I /apex/com.android.media.swcodec/bin/mediaswcodec: media swcodec service starting
08-17 06:45:32.349   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:32.353   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: Could not read additional policy file '/vendor/etc/seccomp_policy/mediaswcodec.policy'
08-17 06:45:32.354   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: libminijail[338]: failed to get path of fd 5: No such file or directory
08-17 06:45:32.354   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: libminijail[338]: allowing syscall: connect
08-17 06:45:32.354   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: libminijail[338]: allowing syscall: fcntl
08-17 06:45:32.354   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: libminijail[338]: allowing syscall: sendto
08-17 06:45:32.354   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: libminijail[338]: allowing syscall: socket
08-17 06:45:32.354   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: libminijail[338]: allowing syscall: writev
08-17 06:45:32.355   338   338 W /apex/com.android.media.swcodec/bin/mediaswcodec: libminijail[338]: logging seccomp filter failures
08-17 06:45:32.356   338   338 I CodecServiceRegistrant: Creating software Codec2 service...
08-17 06:45:32.362   318   318 I cameraserver: ServiceManager: 0xf6c0e1a0
08-17 06:45:32.362   318   318 I CameraService: CameraService started (pid=318)
08-17 06:45:32.362   318   318 I CameraService: CameraService process starting
08-17 06:45:32.363   318   318 W BatteryNotifier: batterystats service unavailable!
08-17 06:45:32.363   318   318 W BatteryNotifier: batterystats service unavailable!
08-17 06:45:32.365   174   174 D         : set stream to NULL
08-17 06:45:32.365   338   338 I ServiceManagement: Registered android.hardware.media.c2@1.0::IComponentStore/software (start delay of 530ms)
08-17 06:45:32.365   338   338 I CodecServiceRegistrant: Software Codec2 service created.
08-17 06:45:32.367   174   174 D         : set stream to NULL
08-17 06:45:32.371   174   174 D         : set stream to NULL
08-17 06:45:32.371   271   271 I BufferProvider: found effect "Multichannel Downmix To Stereo" from The Android Open Source Project
08-17 06:45:32.374   271   271 I AudioFlinger: Using module 10 as the primary audio interface
08-17 06:45:32.374   248   248 D AudioHardwareTiny: adev_set_mode: set_mode = 0
08-17 06:45:32.375   271   395 I AudioFlinger: AudioFlinger's thread 0x78d8c05d40 tid=395 ready to run
08-17 06:45:32.377   318   318 I CameraProviderManager: Connecting to new camera provider: external/0, isRemote? 1
08-17 06:45:32.377   271   395 W AudioFlinger: no wake lock to update, system not ready yet
08-17 06:45:32.378   248   248 D AudioHardwareTiny: do_out_standby,out = 0xf6fce000,device = 0x2
08-17 06:45:32.378   318   318 I CameraProviderManager: Camera provider external/0 ready with 0 camera devices
08-17 06:45:32.381   318   318 I CameraProviderManager: Connecting to new camera provider: legacy/0, isRemote? 1
08-17 06:45:32.382   318   318 I CameraProviderManager: Camera provider legacy/0 ready with 0 camera devices
08-17 06:45:32.382   318   393 W CameraProviderManager: addProviderLocked: Camera provider HAL with name 'external/0' already registered
08-17 06:45:32.382   318   393 W CameraProviderManager: addProviderLocked: Camera provider HAL with name 'legacy/0' already registered
08-17 06:45:32.382   271   395 W AudioFlinger: no wake lock to update, system not ready yet
08-17 06:45:32.383   271   271 V APM_AudioPolicyManager: checkAndSetVolume cannot set volume group 3 volume with force use = 0 for comm
08-17 06:45:32.383   318   318 I         : Waiting for activity service
08-17 06:45:32.387   174   174 D         : set stream to NULL
08-17 06:45:32.390   174   174 D         : set stream to NULL
08-17 06:45:32.391   271   271 W AudioFlinger: moveEffects() bad srcOutput 0
08-17 06:45:32.392   271   271 V APM_AudioPolicyManager: selectOutputForMusicEffects selected output 13
08-17 06:45:32.392   271   271 V APM_AudioPolicyManager: setOutputDevices device {type:0x2,@:} delayMs 0
08-17 06:45:32.392   271   271 V APM_AudioPolicyManager: setOutputDevices() prevDevice {type:0x2,@:}
08-17 06:45:32.392   271   271 V APM_AudioPolicyManager: setOutputDevices changing device to {type:0x2,@:}
08-17 06:45:32.393   174   174 D         : set stream to NULL
08-17 06:45:32.394   248   248 D AudioHardwareTiny: out_set_parameters: kvpairs = routing=2
08-17 06:45:32.395   271   271 V APM_AudioPolicyManager: setOutputDevices() AF::createAudioPatch returned 0 patchHandle 12 num_sources 1 num_sinks 1
08-17 06:45:32.397   271   271 V APM_AudioPolicyManager: checkAndSetVolume cannot set volume group 3 volume with force use = 0 for comm
08-17 06:45:32.402   248   248 D AudioHardwareTiny: audio hal adev_open_input_stream devices = 0x80000004, flags = 0, config->samplerate = 48000,config->channel_mask = c
08-17 06:45:32.402   248   248 D AudioHardwareTiny: pcm_config->rate:44100,in->requested_rate:48000,in->channel_mask:2
08-17 06:45:32.405   248   248 D AudioHardwareTiny: in->mSpeexFrameSize:1120 in->requested_rate:48000
08-17 06:45:32.409   174   174 D         : set stream to NULL
08-17 06:45:32.412   174   174 D         : set stream to NULL
08-17 06:45:32.414   248   248 D AudioHardwareTiny: in->Device     : 0x4
08-17 06:45:32.414   174   174 D         : set stream to NULL
08-17 06:45:32.414   248   248 D AudioHardwareTiny: in->SampleRate : 44100
08-17 06:45:32.414   248   248 D AudioHardwareTiny: in->Channels   : 2
08-17 06:45:32.414   248   248 D AudioHardwareTiny: in->Formate    : 0
08-17 06:45:32.414   248   248 D AudioHardwareTiny: in->PreiodSize : 1024
08-17 06:45:32.415   271   398 I AudioFlinger: AudioFlinger's thread 0x78d8ce58c0 tid=398 ready to run
08-17 06:45:32.416   271   398 W AudioFlinger: no wake lock to update, system not ready yet
08-17 06:45:32.416   271   398 W AudioFlinger: no wake lock to update, system not ready yet
08-17 06:45:32.419   248   248 D AudioHardwareTiny: adev_close_input_stream
08-17 06:45:32.423   327   327 I mediaserver: ServiceManager: 0xeb8232a0
08-17 06:45:32.424   174   174 D         : set stream to NULL
08-17 06:45:32.428   174   174 D         : set stream to NULL
08-17 06:45:32.434   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:32.437   174   174 D         : set stream to NULL
08-17 06:45:32.450   174   174 D         : set stream to NULL
08-17 06:45:32.450   175   175 I ServiceManager: Waiting for service 'SurfaceFlinger' on '/dev/binder'...
08-17 06:45:32.450   327   327 W BatteryNotifier: batterystats service unavailable!
08-17 06:45:32.451   327   327 W BatteryNotifier: batterystats service unavailable!
08-17 06:45:32.452   174   174 D         : set stream to NULL
08-17 06:45:32.466   174   174 D         : set stream to NULL
08-17 06:45:32.466   271   271 I bt_a2dp_hw: adev_open:  adev_open in A2dp_hw module
08-17 06:45:32.466   271   271 I AudioFlinger: loadHwModule() Loaded a2dp audio interface, handle 18
08-17 06:45:32.466   271   271 E APM_AudioPolicyManager: initialize: Input device list is empty!
08-17 06:45:32.468   174   174 D         : set stream to NULL
08-17 06:45:32.472   248   248 W DeviceHAL: Error from HAL Device in function set_master_volume: Function not implemented
08-17 06:45:32.473   271   271 I AudioFlinger: loadHwModule() Loaded usb audio interface, handle 26
08-17 06:45:32.473   271   271 E APM_AudioPolicyManager: initialize: Input device list is empty!
08-17 06:45:32.479   174   174 D         : set stream to NULL
08-17 06:45:32.479   248   248 I r_submix: adev_open(name=audio_hw_if)
08-17 06:45:32.479   248   248 I r_submix: adev_init_check()
08-17 06:45:32.479   248   248 W DeviceHAL: Error from HAL Device in function set_master_volume: Function not implemented
08-17 06:45:32.479   248   248 W DeviceHAL: Error from HAL Device in function set_master_mute: Function not implemented
08-17 06:45:32.480   271   271 I AudioFlinger: loadHwModule() Loaded r_submix audio interface, handle 34
08-17 06:45:32.480   248   248 D r_submix: adev_open_input_stream(addr=0)
08-17 06:45:32.480   248   248 D r_submix: submix_audio_device_create_pipe_l(addr=0, idx=9)
08-17 06:45:32.480   248   248 D r_submix:   now using address 0 for route 9
08-17 06:45:32.481   174   174 D         : set stream to NULL
08-17 06:45:32.481   271   401 I AudioFlinger: AudioFlinger's thread 0x78d8ce51c0 tid=401 ready to run
08-17 06:45:32.482   248   312 I r_submix: in_standby()
08-17 06:45:32.482   271   401 W AudioFlinger: no wake lock to update, system not ready yet
08-17 06:45:32.482   248   248 I r_submix: in_standby()
08-17 06:45:32.483   271   401 W AudioFlinger: no wake lock to update, system not ready yet
08-17 06:45:32.483   248   248 D r_submix: adev_close_input_stream()
08-17 06:45:32.483   248   248 D r_submix: submix_audio_device_release_pipe_l(idx=9) addr=0
08-17 06:45:32.483   248   248 D r_submix: submix_audio_device_destroy_pipe_l(): pipe destroyed
08-17 06:45:32.484   174   174 D         : set stream to NULL
08-17 06:45:32.485   271   271 I         : Waiting for activity service
08-17 06:45:32.493   174   174 D         : set stream to NULL
08-17 06:45:32.521   174   174 D         : set stream to NULL
08-17 06:45:32.521   174   174 D RenderEngine: shader cache generated - 48 shaders in 809.957214 ms
08-17 06:45:32.524   174   174 I ServiceManagement: Registered android.frameworks.displayservice@1.0::IDisplayService/default (start delay of 2580ms)
08-17 06:45:32.524   174   174 D SurfaceFlinger: Setting power mode 2 on display 0
08-17 06:45:32.530   174   174 D SurfaceFlinger: Finished setting power mode 2 on display 0
08-17 06:45:32.531   243   243 D ICU     : Time zone APEX file found: /apex/com.android.tzdata/etc/icu/icu_tzdata.dat
08-17 06:45:32.534   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:32.548   325   325 E MediaExtractorFactory: couldn't opendir(/system/lib64/extractors)
08-17 06:45:32.551   175   175 D BootAnimation: BootAnimationStartTiming start time: 5987ms
08-17 06:45:32.551   175   175 D BootAnimation: BootAnimationPreloadTiming start time: 5987ms
08-17 06:45:32.551   175   175 D BootAnimation: bootvideo:No boot video animation,EXIT_VIDEO_NAME:false,bootvideo.showtime:-1
08-17 06:45:32.552   175   175 D BootAnimation: BootAnimationPreloadStopTiming start time: 5988ms
08-17 06:45:32.570   175   405 D libEGL  : loaded /vendor/lib64/egl/libGLES_mali.so
08-17 06:45:32.584   175   405 I mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 876; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:32.584   175   405 I mali_so : arm_release_ver of this mali_so is 'r18p0-01rel0', rk_so_ver is '17@0'.
08-17 06:45:32.584   175   405 D mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 881; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:32.584   175   405 D mali_so : current process is NOT sf, to bail out.
08-17 06:45:32.589   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.0::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:32.591   175   405 D mali_winsys: EGLint new_window_surface(egl_winsys_display *, void *, EGLSurface, EGLConfig, egl_winsys_surface **, egl_color_buffer_format *, EGLBoolean) returns 0x300
0
08-17 06:45:32.594   175   405 D BootAnimation: BootAnimationShownTiming start time: 6030ms
08-17 06:45:32.635   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:32.654   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:32.654   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:32.654
08-17 06:45:32.658   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.mapper@3.0::IMapper/default in either framework or device manifest.
08-17 06:45:32.659   175   405 W Gralloc3: mapper 3.x is not supported
08-17 06:45:32.667   175   405 D GRALLOC-ROCKCHIP: RK_GRAPHICS_VER=commit-id:344c4dd
08-17 06:45:32.680   244   244 D ICU     : Time zone APEX file found: /apex/com.android.tzdata/etc/icu/icu_tzdata.dat
08-17 06:45:32.681   174   174 I SurfaceFlinger: Enter boot animation
08-17 06:45:32.683   260   260 D GRALLOC-ROCKCHIP: RK_GRAPHICS_VER=commit-id:344c4dd
08-17 06:45:32.685   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:32.685   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:32.685
08-17 06:45:32.735   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:32.765   260   310 I rockchiprga: Rga built version:version:1.00
08-17 06:45:32.831   243   243 W zygote64: JNI RegisterNativeMethods: attempt to register 0 native methods for android.media.AudioAttributes
08-17 06:45:32.836   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:32.839   244   244 W zygote  : JNI RegisterNativeMethods: attempt to register 0 native methods for android.media.AudioAttributes
08-17 06:45:32.857   243   243 D Zygote  : begin preload
08-17 06:45:32.858   243   243 I Zygote  : Calling ZygoteHooks.beginPreload()
08-17 06:45:32.877   244   244 I zygote  : Explicit concurrent copying GC freed 288(39KB) AllocSpace objects, 0(0B) LOS objects, 98% free, 24KB/1560KB, paused 162us total 11.273ms
08-17 06:45:32.884   244   244 I zygote  : Explicit concurrent copying GC freed 5(32KB) AllocSpace objects, 0(0B) LOS objects, 98% free, 24KB/1560KB, paused 111us total 6.701ms
08-17 06:45:32.885   244   244 D Zygote32Timing: PostZygoteInitGC took to complete: 19ms
08-17 06:45:32.885   244   244 D Zygote32Timing: ZygoteInit took to complete: 19ms
08-17 06:45:32.895   243   243 D Zygote64Timing: BeginPreload took to complete: 39ms
08-17 06:45:32.896   243   243 I Zygote  : Preloading classes...
08-17 06:45:32.899   243   243 W Zygote  : Class not found for preloading: android.app.-$$Lambda$ActivityThread$ZXDWm3IBeFmLnFVblhB-IOZCr9o
08-17 06:45:32.904   244   244 I Zygote  : Accepting command socket connections
08-17 06:45:32.943   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:33.008   243   243 W Zygote  : Class not found for preloading: android.bluetooth.BluetoothA2dp$2
08-17 06:45:33.027   243   243 I PackageBackwardCompatibility: Could not find android.content.pm.AndroidTestBaseUpdater, ignoring
08-17 06:45:33.044   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:33.548   329   380 I chatty  : uid=0(root) /system/bin/storaged identical 9 lines
08-17 06:45:33.649   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:33.716   243   243 E ActivityRecognitionHardware: activity_recognition HAL is deprecated. class_init is effectively a no-op
08-17 06:45:33.749   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:33.798   243   243 I zygote64: Thread[1,tid=243,Native,Thread*=0x73b2ffac00,peer=0x12c021e8,"main"] recursive attempt to load library "libmedia_jni.so"
08-17 06:45:33.798   243   243 D MtpDeviceJNI: register_android_mtp_MtpDevice
08-17 06:45:33.798   243   243 I zygote64: Thread[1,tid=243,Native,Thread*=0x73b2ffac00,peer=0x12c021e8,"main"] recursive attempt to load library "libmedia_jni.so"
08-17 06:45:33.798   243   243 I zygote64: Thread[1,tid=243,Native,Thread*=0x73b2ffac00,peer=0x12c021e8,"main"] recursive attempt to load library "libmedia_jni.so"
08-17 06:45:33.813   243   243 W Zygote  : Class not found for preloading: android.media.audiopolicy.AudioProductStrategies
08-17 06:45:33.813   243   243 W Zygote  : Class not found for preloading: android.media.audiopolicy.AudioVolumeGroups
08-17 06:45:33.850   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:33.948   243   243 W Zygote  : Class not found for preloading: android.view.-$$Lambda$SurfaceView$Cs7TGTdA1lXf9qW8VOJAfEsMjdk
08-17 06:45:33.950   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:33.957   243   243 W Zygote  : Class not found for preloading: android.view.SurfaceView$3
08-17 06:45:33.962   243   243 W Zygote  : Class not found for preloading: android.view.textclassifier.-$$Lambda$TextClassificationManager$JIaezIJbMig_-kVzN6oArzkTsJE
08-17 06:45:33.976   243   243 W Zygote  : Class not found for preloading: com.android.internal.net.NetworkStatsFactory
08-17 06:45:33.986   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$PhoneSubInfoController$8HFbCDJDN1mrLJG980qYH5MGqMk
08-17 06:45:33.986   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$PhoneSubInfoController$U28a_EGx2cvmQhDfRRgonMt5Zrc
08-17 06:45:33.986   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$SubscriptionInfoUpdater$-zZXM9oMRZ3vZz7dJOG19J00Bmw
08-17 06:45:33.986   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$SubscriptionInfoUpdater$D5yF1HbS4cvCyoAj3FESkPtA_0g
08-17 06:45:33.986   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$SubscriptionInfoUpdater$MMx9iQX0JVqqMPLTUZhdBubFSzU
08-17 06:45:34.001   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.PhoneConfigurationModels
08-17 06:45:34.006   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.SubscriptionController$ScLocalLog
08-17 06:45:34.008   243   243 W Zygote  : Class not found for preloading: com.android.internal.telephony.UiccSmsController
08-17 06:45:34.050   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.073   243   243 I Zygote  : ...preloaded 7588 classes in 1178ms.
08-17 06:45:34.073   243   243 I zygote64: VMRuntime.preloadDexCaches starting
08-17 06:45:34.116   243   243 I zygote64: VMRuntime.preloadDexCaches strings total=380611 before=9924 after=9924
08-17 06:45:34.116   243   243 I zygote64: VMRuntime.preloadDexCaches types total=35902 before=7192 after=7460
08-17 06:45:34.116   243   243 I zygote64: VMRuntime.preloadDexCaches fields total=161215 before=8020 after=8221
08-17 06:45:34.116   243   243 I zygote64: VMRuntime.preloadDexCaches methods total=282425 before=10884 after=11316
08-17 06:45:34.116   243   243 I zygote64: VMRuntime.preloadDexCaches finished
08-17 06:45:34.116   243   243 D Zygote64Timing: PreloadClasses took to complete: 1221ms
08-17 06:45:34.120   243   243 I zygote64: The ClassLoaderContext is a special shared library.
08-17 06:45:34.121   243   243 D ApplicationLoaders: Created zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:34.123   243   243 I zygote64: The ClassLoaderContext is a special shared library.
08-17 06:45:34.124   243   243 D ApplicationLoaders: Created zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:34.124   243   243 D Zygote64Timing: CacheNonBootClasspathClassLoaders took to complete: 8ms
08-17 06:45:34.151   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.352   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.439   243   243 I Zygote  : Preloading resources...
08-17 06:45:34.452   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.464   243   243 W Resources: Preloaded drawable resource #0x108027d (android:drawable/dialog_background_material) that varies with configuration!!
08-17 06:45:34.488   243   243 I Zygote  : ...preloaded 64 resources in 48ms.
08-17 06:45:34.493   243   243 I Zygote  : ...preloaded 41 resources in 5ms.
08-17 06:45:34.493   243   243 D Zygote64Timing: PreloadResources took to complete: 369ms
08-17 06:45:34.544   243   243 D libEGL  : loaded /vendor/lib64/egl/libGLES_mali.so
08-17 06:45:34.557   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.567   243   243 I Zygote  : Preloading shared libraries...
08-17 06:45:34.583   243   243 I Zygote  : Called ZygoteHooks.endPreload()
08-17 06:45:34.584   243   243 I Zygote  : Installed AndroidKeyStoreProvider in 1ms.
08-17 06:45:34.595   243   243 I Zygote  : Warmed up JCA providers in 11ms.
08-17 06:45:34.595   243   243 D Zygote  : end preload
08-17 06:45:34.595   243   243 D Zygote64Timing: ZygotePreload took to complete: 1739ms
08-17 06:45:34.629   243   243 I zygote64: Explicit concurrent copying GC freed 62628(3471KB) AllocSpace objects, 16(388KB) LOS objects, 49% free, 2551KB/5102KB, paused 49us total 33.743ms
08-17 06:45:34.656   243   243 I zygote64: Explicit concurrent copying GC freed 6065(208KB) AllocSpace objects, 0(0B) LOS objects, 49% free, 2374KB/4748KB, paused 18us total 20.622ms
08-17 06:45:34.657   243   243 D Zygote64Timing: PostZygoteInitGC took to complete: 61ms
08-17 06:45:34.657   243   243 D Zygote64Timing: ZygoteInit took to complete: 1800ms
08-17 06:45:34.657   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.715   243   243 D Zygote  : Forked child process 429
08-17 06:45:34.715   243   243 I Zygote  : System server process 429 has been created
08-17 06:45:34.717   243   243 I Zygote  : Accepting command socket connections
08-17 06:45:34.734   429   429 I chatty  : uid=1000 system_server expire 121 lines
08-17 06:45:34.758   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.858   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:34.882   429   429 I SystemServer: InitBeforeStartServices
08-17 06:45:34.891   429   429 I SystemServer: Entered the Android system server!
08-17 06:45:35.159   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.218   429   429 D SystemServerTiming: InitBeforeStartServices took to complete: 336ms
08-17 06:45:35.218   429   429 I SystemServer: StartServices
08-17 06:45:35.219   429   429 I SystemServer: StartWatchdog
08-17 06:45:35.254   429   429 D SystemServerTiming: StartWatchdog took to complete: 36ms
08-17 06:45:35.255   429   429 I SystemServer: Reading configuration...
08-17 06:45:35.255   429   429 I SystemServer: ReadingSystemConfig
08-17 06:45:35.256   429   429 D SystemServerTiming: ReadingSystemConfig took to complete: 0ms
08-17 06:45:35.256   429   429 I SystemServer: StartInstaller
08-17 06:45:35.256   429   456 D SystemServerInitThreadPool: Started executing ReadingSystemConfig
08-17 06:45:35.256   429   429 I SystemServiceManager: Starting com.android.server.pm.Installer
08-17 06:45:35.261   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.268   322   335 D installd: Found quota mount /dev/block/by-name/userdata at /data
08-17 06:45:35.269   429   429 D SystemServerTiming: StartInstaller took to complete: 13ms
08-17 06:45:35.269   429   429 I SystemServer: DeviceIdentifiersPolicyService
08-17 06:45:35.270   429   429 I SystemServiceManager: Starting com.android.server.os.DeviceIdentifiersPolicyService
08-17 06:45:35.270   429   429 D SystemServerTiming: DeviceIdentifiersPolicyService took to complete: 1ms
08-17 06:45:35.270   429   429 I SystemServer: UriGrantsManagerService
08-17 06:45:35.271   429   429 I SystemServiceManager: Starting com.android.server.uri.UriGrantsManagerService$Lifecycle
08-17 06:45:35.281   429   429 D SystemServerTiming: UriGrantsManagerService took to complete: 10ms
08-17 06:45:35.281   429   429 I SystemServer: StartActivityManager
08-17 06:45:35.281   429   429 I SystemServiceManager: Starting com.android.server.wm.ActivityTaskManagerService$Lifecycle
08-17 06:45:35.300   429   429 I SystemServiceManager: Starting com.android.server.am.ActivityManagerService$Lifecycle
08-17 06:45:35.327   429   456 W SystemConfig: No directory /product/etc/sysconfig, skipping
08-17 06:45:35.327   429   429 I ActivityManager: Memory class: 192
08-17 06:45:35.339   429   456 W SystemConfig: No directory /product_services/etc/sysconfig, skipping
08-17 06:45:35.339   429   456 W SystemConfig: No directory /product_services/etc/permissions, skipping
08-17 06:45:35.339   429   456 D SystemServerInitThreadPool: Finished executing ReadingSystemConfig
08-17 06:45:35.353   429   429 D BatteryStatsImpl: Reading daily items from /data/system/batterystats-daily.xml
08-17 06:45:35.361   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.365   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.power.stats@1.0::IPowerStats/default in either framework or device manifest.
08-17 06:45:35.368   429   463 I chatty  : uid=1000(system) batterystats-wo expire 3 lines
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker: Error updating external stats:
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker: java.lang.NullPointerException: Attempt to invoke virtual method 'boolean android.content.pm.PackageManager.hasSystemFeature(java.lang.Stri
ng)' on a null object reference
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at com.android.server.am.BatteryExternalStatsWorker.updateExternalStatsLocked(BatteryExternalStatsWorker.java:453)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at com.android.server.am.BatteryExternalStatsWorker.access$900(BatteryExternalStatsWorker.java:63)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at com.android.server.am.BatteryExternalStatsWorker$1.run(BatteryExternalStatsWorker.java:363)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:462)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at java.util.concurrent.FutureTask.run(FutureTask.java:266)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(ScheduledThreadPoolExecutor.java:301)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at com.android.server.am.BatteryExternalStatsWorker.lambda$new$0(BatteryExternalStatsWorker.java:81)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at com.android.server.am.-$$Lambda$BatteryExternalStatsWorker$ddVY5lmqswnSjXppAxPTOHbuzzQ.run(Unknown Source:2)
08-17 06:45:35.375   429   463 E BatteryExternalStatsWorker:    at java.lang.Thread.run(Thread.java:919)
08-17 06:45:35.382   429   463 E AndroidRuntime: Error reporting WTF
08-17 06:45:35.382   429   463 E AndroidRuntime: java.lang.NullPointerException: Attempt to invoke interface method 'boolean android.app.IActivityManager.handleApplicationWtf(android.os.IBinder, java.
lang.String, boolean, android.app.ApplicationErrorReport$ParcelableCrashInfo)' on a null object reference
08-17 06:45:35.382   429   463 E AndroidRuntime:        at com.android.internal.os.RuntimeInit.wtf(RuntimeInit.java:385)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at android.util.Log$1.onTerribleFailure(Log.java:120)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at android.util.Log.wtf(Log.java:314)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at android.util.Slog.wtf(Slog.java:130)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at com.android.server.am.BatteryExternalStatsWorker$1.run(BatteryExternalStatsWorker.java:386)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:462)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at java.util.concurrent.FutureTask.run(FutureTask.java:266)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(ScheduledThreadPoolExecutor.java:301)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at com.android.server.am.BatteryExternalStatsWorker.lambda$new$0(BatteryExternalStatsWorker.java:81)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at com.android.server.am.-$$Lambda$BatteryExternalStatsWorker$ddVY5lmqswnSjXppAxPTOHbuzzQ.run(Unknown Source:2)
08-17 06:45:35.382   429   463 E AndroidRuntime:        at java.lang.Thread.run(Thread.java:919)
08-17 06:45:35.383   429   463 E AndroidRuntime: Original WTF:
08-17 06:45:35.383   429   463 E AndroidRuntime: android.util.Log$TerribleFailure: Error updating external stats:
08-17 06:45:35.383   429   463 E AndroidRuntime:        at android.util.Log.wtf(Log.java:309)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at android.util.Slog.wtf(Slog.java:130)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at com.android.server.am.BatteryExternalStatsWorker$1.run(BatteryExternalStatsWorker.java:386)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:462)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at java.util.concurrent.FutureTask.run(FutureTask.java:266)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(ScheduledThreadPoolExecutor.java:301)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at com.android.server.am.BatteryExternalStatsWorker.lambda$new$0(BatteryExternalStatsWorker.java:81)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at com.android.server.am.-$$Lambda$BatteryExternalStatsWorker$ddVY5lmqswnSjXppAxPTOHbuzzQ.run(Unknown Source:2)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at java.lang.Thread.run(Thread.java:919)
08-17 06:45:35.383   429   463 E AndroidRuntime: Caused by: java.lang.NullPointerException: Attempt to invoke virtual method 'boolean android.content.pm.PackageManager.hasSystemFeature(java.lang.Strin
g)' on a null object reference
08-17 06:45:35.383   429   463 E AndroidRuntime:        at com.android.server.am.BatteryExternalStatsWorker.updateExternalStatsLocked(BatteryExternalStatsWorker.java:453)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at com.android.server.am.BatteryExternalStatsWorker.access$900(BatteryExternalStatsWorker.java:63)
08-17 06:45:35.383   429   463 E AndroidRuntime:        at com.android.server.am.BatteryExternalStatsWorker$1.run(BatteryExternalStatsWorker.java:363)
08-17 06:45:35.383   429   463 E AndroidRuntime:        ... 8 more
08-17 06:45:35.461   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.482   429   429 I IntentFirewall: Read new rules (A:0 B:0 S:0)
08-17 06:45:35.516   429   429 D AppOps  : AppOpsService published
08-17 06:45:35.523   429   429 D SystemServerTiming: StartActivityManager took to complete: 243ms
08-17 06:45:35.523   429   429 I SystemServer: StartPowerManager
08-17 06:45:35.523   429   429 I SystemServiceManager: Starting com.android.server.power.PowerManagerService
08-17 06:45:35.545   429   429 D SystemServerTiming: StartPowerManager took to complete: 21ms
08-17 06:45:35.545   429   429 I SystemServer: StartThermalManager
08-17 06:45:35.545   429   429 I SystemServiceManager: Starting com.android.server.power.ThermalManagerService
08-17 06:45:35.547   429   429 D SystemServerTiming: StartThermalManager took to complete: 2ms
08-17 06:45:35.547   429   429 I SystemServer: InitPowerManagement
08-17 06:45:35.548   429   429 D SystemServerTiming: InitPowerManagement took to complete: 1ms
08-17 06:45:35.548   429   429 I SystemServer: StartRecoverySystemService
08-17 06:45:35.548   429   429 I SystemServiceManager: Starting com.android.server.RecoverySystemService
08-17 06:45:35.553   429   429 D SystemServerTiming: StartRecoverySystemService took to complete: 4ms
08-17 06:45:35.555   429   429 W RescueParty: Noticed 1 events for UID 0 in last 8 sec
08-17 06:45:35.555   429   429 I SystemServer: StartLightsService
08-17 06:45:35.555   429   429 I SystemServiceManager: Starting com.android.server.lights.LightsService
08-17 06:45:35.561   429   429 D SystemServerTiming: StartLightsService took to complete: 6ms
08-17 06:45:35.561   429   429 I SystemServer: StartSidekickService
08-17 06:45:35.561   429   429 D SystemServerTiming: StartSidekickService took to complete: 0ms
08-17 06:45:35.561   429   429 I SystemServer: StartDisplayManager
08-17 06:45:35.561   429   429 I SystemServiceManager: Starting com.android.server.display.DisplayManagerService
08-17 06:45:35.562   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.570   429   429 D SystemServerTiming: StartDisplayManager took to complete: 8ms
08-17 06:45:35.570   429   429 I SystemServer: WaitForDisplay
08-17 06:45:35.570   429   429 I SystemServiceManager: Starting phase 100
08-17 06:45:35.580   429   452 I DisplayManagerService: Display device added: DisplayDeviceInfo{"Built-in Screen": uniqueId="local:0", 1536 x 2048, modeId 1, defaultModeId 1, supportedModes [{id=1, wi
dth=1536, height=2048, fps=60.000004}], colorMode 0, supportedColorModes [0], HdrCapabilities android.view.Display$HdrCapabilities@40f16308, density 280, 320.0 x 320.0 dpi, appVsyncOff 1000000, presDe
adline 16666666, touch INTERNAL, rotation 0, type BUILT_IN, address {port=0}, state UNKNOWN, FLAG_DEFAULT_DISPLAY, FLAG_ROTATES_WITH_CONTENT, FLAG_SECURE, FLAG_SUPPORTS_PROTECTED_BUFFERS}
08-17 06:45:35.580   174   174 D SurfaceFlinger: Setting power mode 2 on display 0
08-17 06:45:35.584   429   429 D SystemServerTiming: WaitForDisplay took to complete: 13ms
08-17 06:45:35.584   429   452 I DisplayManagerService: Display device changed state: "Built-in Screen", ON
08-17 06:45:35.584   429   429 I SystemServer: StartPackageManagerService
08-17 06:45:35.585   429   429 I Watchdog: Pausing HandlerChecker: main thread for reason: packagemanagermain. Pause count: 1
08-17 06:45:35.641   429   429 D SELinuxMMAC: Using policy file /system/etc/selinux/plat_mac_permissions.xml
08-17 06:45:35.644   429   429 D SELinuxMMAC: Using policy file /vendor/etc/selinux/vendor_mac_permissions.xml
08-17 06:45:35.662   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.851   429   429 D PackageManager: Keeping known cache d308749043aa9cc0e4bd9cfee5c323a37bad6127
08-17 06:45:35.851   429   429 W PackageManager: Wiping cache directory because the system partition changed.
08-17 06:45:35.863   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.871   429   429 W PackageManager: Failed to parse /system/framework/arm: Missing base APK in /system/framework/arm
08-17 06:45:35.871   429   429 W PackageManager: Failed to parse /system/framework/oat: Missing base APK in /system/framework/oat
08-17 06:45:35.872   429   429 W PackageManager: Failed to parse /system/framework/arm64: Missing base APK in /system/framework/arm64
08-17 06:45:35.963   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:35.967   429   429 W PackageManager: Skipping provider name androidx.lifecycle.process.lifecycle-process (in package com.android.systemui): name already used by com.android.settings
08-17 06:45:35.982   429   429 I PackageManager: Finished scanning system apps. Time: 132 ms, packageCount: 123 , timePerPackage: 1 , cached: 123
08-17 06:45:35.982   429   429 I PackageManager: Finished scanning non-system apps. Time: 1 ms, packageCount: 0 , timePerPackage: 0 , cached: 0
08-17 06:45:35.986   429   429 I PackageManager: Time to scan packages: 0.137 seconds
08-17 06:45:35.987   429   429 I PackageManager: Un-granting permission android.permission.GLOBAL_SEARCH from package com.android.quicksearchbox (protectionLevel=18 flags=0x3008be45)
08-17 06:45:35.988   429   429 I PackageManager: Un-granting permission android.permission.WRITE_MEDIA_STORAGE from package com.android.soundrecorder (protectionLevel=18 flags=0x3008be45)
08-17 06:45:35.988   429   429 I PackageManager: Un-granting permission android.permission.MOUNT_UNMOUNT_FILESYSTEMS from package com.android.soundrecorder (protectionLevel=18 flags=0x3008be45)
08-17 06:45:35.997   429   429 V PackageManager: reconcileAppsData for null u0 0x1 migrateAppData=true
08-17 06:45:36.001   322   335 I SELinux : SELinux: Loaded file_contexts
08-17 06:45:36.037   429   429 V PackageManager: reconcileAppsData finished 17 packages
08-17 06:45:36.038   429   498 D SystemServerInitThreadPool: Started executing prepareAppData
08-17 06:45:36.064   329   380 I ServiceManager: Waiting for service 'package_native' on '/dev/binder'...
08-17 06:45:36.091   322   497 W installd: Ignoring /data/data/EeWbNEu3DJDACtJo5xtAZcqjN+FlCPozRTh+LB/srZ7zxrIrM5VhWbuaxS8DQocfxodSNN1 with unexpected GID 0 instead of 10084
08-17 06:45:36.105   429   429 D PackageManager: Ephemeral resolver NOT found; no matching intent filters
08-17 06:45:36.106   429   429 D PackageManager: Instant App installer not found with android.intent.action.INSTALL_INSTANT_APP_PACKAGE
08-17 06:45:36.106   429   429 D PackageManager: Clear ephemeral installer activity
08-17 06:45:36.158   429   429 I Watchdog: Resuming HandlerChecker: main thread for reason: packagemanagermain. Pause count: 0
08-17 06:45:36.159   429   429 D SystemServerTiming: StartPackageManagerService took to complete: 575ms
08-17 06:45:36.160   429   429 I SystemServer: StartOtaDexOptService
08-17 06:45:36.160   429   429 I Watchdog: Pausing HandlerChecker: main thread for reason: moveab. Pause count: 1
08-17 06:45:36.162   429   429 D OTADexopt: No upgrade, skipping A/B artifacts check.
08-17 06:45:36.162   429   429 I Watchdog: Resuming HandlerChecker: main thread for reason: moveab. Pause count: 0
08-17 06:45:36.162   429   429 D SystemServerTiming: StartOtaDexOptService took to complete: 1ms
08-17 06:45:36.162   429   429 I SystemServer: StartUserManagerService
08-17 06:45:36.162   429   429 I SystemServiceManager: Starting com.android.server.pm.UserManagerService$LifeCycle
08-17 06:45:36.163   429   429 D SystemServerTiming: StartUserManagerService took to complete: 0ms
08-17 06:45:36.163   429   429 I SystemServer: InitAttributerCache
08-17 06:45:36.163   429   429 D SystemServerTiming: InitAttributerCache took to complete: 0ms
08-17 06:45:36.163   429   429 I SystemServer: SetSystemProcess
08-17 06:45:36.167   329   380 I storaged: storaged: Start
08-17 06:45:36.170   273   273 I lowmemorykiller: lmkd data connection established
08-17 06:45:36.170   429   429 D SystemServerTiming: SetSystemProcess took to complete: 7ms
08-17 06:45:36.170   429   429 I SystemServer: InitWatchdog
08-17 06:45:36.171   429   429 D SystemServerTiming: InitWatchdog took to complete: 1ms
08-17 06:45:36.172   429   429 I SystemServer: StartOverlayManagerService
08-17 06:45:36.191   271   271 I         : Waiting for sensor privacy service
08-17 06:45:36.191   318   318 I         : Waiting for sensor privacy service
08-17 06:45:36.208   429   498 D SystemServerTimingAsync: AppDataFixup took to complete: 171ms
08-17 06:45:36.271   429   429 D SystemServerTiming: StartOverlayManagerService took to complete: 99ms
08-17 06:45:36.271   429   429 I SystemServer: StartSensorPrivacyService
08-17 06:45:36.273   429   429 D SystemServerTiming: StartSensorPrivacyService took to complete: 1ms
08-17 06:45:36.273   429   429 I SystemServer: StartBatteryService
08-17 06:45:36.273   429   429 I SystemServiceManager: Starting com.android.server.BatteryService
08-17 06:45:36.273   429   507 D SystemServerInitThreadPool: Started executing StartSensorService
08-17 06:45:36.274   429   507 I chatty  : uid=1000 system_server expire 2 lines
08-17 06:45:36.275   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.sensors@2.0::ISensors/default in either framework or device manifest.
08-17 06:45:36.278   265   287 I SensorsHal: set active: handle = 0, enable = 0
08-17 06:45:36.279   265   287 I SensorsHal: set active: handle = 1, enable = 0
08-17 06:45:36.279   265   287 I SensorsHal: set active: handle = 5, enable = 0
08-17 06:45:36.279   265   287 I SensorsHal: set active: handle = 4, enable = 0
08-17 06:45:36.282   429   510 I chatty  : uid=1000(system) SensorService expire 1 line
08-17 06:45:36.282   429   508 I chatty  : uid=1000(system) SensorEventAckR expire 1 line
08-17 06:45:36.284   429   507 D SystemServerTimingAsync: StartSensorService took to complete: 11ms
08-17 06:45:36.285   429   507 D SystemServerInitThreadPool: Finished executing StartSensorService
08-17 06:45:36.286   429   467 I chatty  : uid=1000(system) HwBinder:429_1 expire 3 lines
08-17 06:45:36.288   429   463 I KernelCpuUidFreqTimeReader: mPerClusterTimesAvailable=false
08-17 06:45:36.288   429   429 I HealthServiceWrapper: health: HealthServiceWrapper listening to instance default
08-17 06:45:36.289   429   429 I BatteryService: health: Waited 0ms and received the update.
08-17 06:45:36.290   429   429 D SystemServerTiming: StartBatteryService took to complete: 16ms
08-17 06:45:36.290   429   429 I SystemServer: StartUsageService
08-17 06:45:36.290   429   429 I SystemServiceManager: Starting com.android.server.usage.UsageStatsService
08-17 06:45:36.290   429   509 I chatty  : uid=1000(system) HealthServiceRe expire 1 line
08-17 06:45:36.292   429   463 W KernelMemoryBandwidthStats: No kernel memory bandwidth stats available
08-17 06:45:36.295   318   318 I ServiceManagement: Registered android.frameworks.cameraservice.service@2.0::ICameraService/default (start delay of 4571ms)
08-17 06:45:36.296   318   318 I CameraService: CameraService pinged cameraservice proxy
08-17 06:45:36.296   318   318 I cameraserver: ServiceManager: 0xf6c0e1a0 done instantiate
08-17 06:45:36.297   271   271 I SoundTriggerHalHidl: getProperties res implementor
08-17 06:45:36.298   271   271 I SoundTriggerHalHidl: getProperties ret -19
08-17 06:45:36.298   271   271 E SoundTriggerHwService: could not read implementation properties
08-17 06:45:36.314   429   429 I UsageStatsService: User[0] Rollover scheduled @ 2020-08-18 01:05:45(1597712745570)
08-17 06:45:36.314   429   429 D SystemServerTiming: StartUsageService took to complete: 24ms
08-17 06:45:36.314   429   429 I SystemServer: StartWebViewUpdateService
08-17 06:45:36.315   429   429 I SystemServiceManager: Starting com.android.server.webkit.WebViewUpdateService
08-17 06:45:36.322   429   429 D SystemServerTiming: StartWebViewUpdateService took to complete: 8ms
08-17 06:45:36.322   429   429 I SystemServer: StartCachedDeviceStateService
08-17 06:45:36.322   429   429 I SystemServiceManager: Starting com.android.server.CachedDeviceStateService
08-17 06:45:36.322   429   429 D SystemServerTiming: StartCachedDeviceStateService took to complete: 0ms
08-17 06:45:36.322   429   429 I SystemServer: StartBinderCallsStatsService
08-17 06:45:36.322   429   429 I SystemServiceManager: Starting com.android.server.BinderCallsStatsService$LifeCycle
08-17 06:45:36.323   429   429 D SystemServerTiming: StartBinderCallsStatsService took to complete: 1ms
08-17 06:45:36.323   429   429 I SystemServer: StartLooperStatsService
08-17 06:45:36.323   429   429 I SystemServiceManager: Starting com.android.server.LooperStatsService$Lifecycle
08-17 06:45:36.324   429   429 D SystemServerTiming: StartLooperStatsService took to complete: 1ms
08-17 06:45:36.324   429   429 I SystemServer: StartRollbackManagerService
08-17 06:45:36.324   429   429 I SystemServiceManager: Starting com.android.server.rollback.RollbackManagerService
08-17 06:45:36.327   322   322 D installd: Found quota mount /dev/block/by-name/userdata at /data
08-17 06:45:36.332   429   429 D SystemServerTiming: StartRollbackManagerService took to complete: 7ms
08-17 06:45:36.332   429   429 I SystemServer: StartBugreportManagerService
08-17 06:45:36.332   429   429 I SystemServiceManager: Starting com.android.server.os.BugreportManagerService
08-17 06:45:36.332   429   429 D SystemServerTiming: StartBugreportManagerService took to complete: 0ms
08-17 06:45:36.333   429   429 I SystemServer: GpuService
08-17 06:45:36.333   429   429 I SystemServiceManager: Starting com.android.server.gpu.GpuService
08-17 06:45:36.333   429   429 D SystemServerTiming: GpuService took to complete: 0ms
08-17 06:45:36.333   429   429 I SystemServer: StartKeyAttestationApplicationIdProviderService
08-17 06:45:36.334   429   514 D SystemServerInitThreadPool: Started executing SecondaryZygotePreload
08-17 06:45:36.334   429   514 I SystemServer: SecondaryZygotePreload
08-17 06:45:36.334   429   429 D SystemServerTiming: StartKeyAttestationApplicationIdProviderService took to complete: 1ms
08-17 06:45:36.334   429   429 I SystemServer: StartKeyChainSystemService
08-17 06:45:36.334   429   429 I SystemServiceManager: Starting com.android.server.security.KeyChainSystemService
08-17 06:45:36.334   429   429 D SystemServerTiming: StartKeyChainSystemService took to complete: 0ms
08-17 06:45:36.335   429   429 I SystemServer: StartSchedulingPolicyService
08-17 06:45:36.335   429   515 D SystemServerInitThreadPool: Started executing SchedulingPolicyService.<init>
08-17 06:45:36.336   429   429 D SystemServerTiming: StartSchedulingPolicyService took to complete: 2ms
08-17 06:45:36.336   429   429 I SystemServer: StartTelecomLoaderService
08-17 06:45:36.336   429   429 I SystemServiceManager: Starting com.android.server.telecom.TelecomLoaderService
08-17 06:45:36.337   429   429 D SystemServerTiming: StartTelecomLoaderService took to complete: 1ms
08-17 06:45:36.337   429   429 I SystemServer: StartTelephonyRegistry
08-17 06:45:36.339   244   244 I Zygote  : Lazily preloading resources.
08-17 06:45:36.339   244   244 D Zygote  : begin preload
08-17 06:45:36.339   244   244 I Zygote  : Calling ZygoteHooks.beginPreload()
08-17 06:45:36.341   429   515 I chatty  : uid=1000 system_server expire 1 line
08-17 06:45:36.341   429   515 D SystemServerInitThreadPool: Finished executing SchedulingPolicyService.<init>
08-17 06:45:36.343   429   498 D SystemServerTimingAsync: AppDataPrepare took to complete: 135ms
08-17 06:45:36.343   429   498 I PackageManager: Deferred reconcileAppsData finished 106 packages
08-17 06:45:36.343   429   498 D SystemServerInitThreadPool: Finished executing prepareAppData
08-17 06:45:36.344   429   429 D SystemServerTiming: StartTelephonyRegistry took to complete: 7ms
08-17 06:45:36.344   429   429 I SystemServer: StartEntropyMixer
08-17 06:45:36.350   429   429 I EntropyMixer: Added HW RNG output to entropy pool
08-17 06:45:36.350   429   429 I EntropyMixer: Writing entropy...
08-17 06:45:36.354   429   429 D SystemServerTiming: StartEntropyMixer took to complete: 10ms
08-17 06:45:36.354   429   429 I SystemServer: StartAccountManagerService
08-17 06:45:36.354   429   429 I SystemServiceManager: Starting com.android.server.accounts.AccountManagerService$Lifecycle
08-17 06:45:36.357   244   244 D ZygoteInitTiming_lazy: BeginPreload took to complete: 18ms
08-17 06:45:36.357   244   244 I Zygote  : Preloading classes...
08-17 06:45:36.359   429   429 D SystemServerTiming: StartAccountManagerService took to complete: 5ms
08-17 06:45:36.359   429   429 I SystemServer: StartContentService
08-17 06:45:36.359   429   429 I SystemServiceManager: Starting com.android.server.content.ContentService$Lifecycle
08-17 06:45:36.359   244   244 W Zygote  : Class not found for preloading: android.app.-$$Lambda$ActivityThread$ZXDWm3IBeFmLnFVblhB-IOZCr9o
08-17 06:45:36.367   429   429 D SystemServerTiming: StartContentService took to complete: 8ms
08-17 06:45:36.367   429   429 I SystemServer: InstallSystemProviders
08-17 06:45:36.389   429   429 I SettingsState: No settings state /data/system/users/0/settings_config.xml
08-17 06:45:36.391   429   429 I SettingsState: directory info for directory/file /data/system/users/0/settings_config.xml with stacktrace
08-17 06:45:36.391   429   429 I SettingsState: java.lang.Exception
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsState.logSettingsDirectoryInformation(SettingsState.java:753)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsState.readStateSyncLocked(SettingsState.java:852)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsState.<init>(SettingsState.java:277)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.ensureSettingsStateLocked(SettingsProvider.java:2589)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.ensureSettingsForUserLocked(SettingsProvider.java:2554)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.peekSettingsStateLocked(SettingsProvider.java:2867)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.getSettingsNamesLocked(SettingsProvider.java:2519)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.syncSsaidTableOnStart(SettingsProvider.java:2501)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.<init>(SettingsProvider.java:2397)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider.onCreate(SettingsProvider.java:330)
08-17 06:45:36.391   429   429 I SettingsState:         at android.content.ContentProvider.attachInfo(ContentProvider.java:2092)
08-17 06:45:36.391   429   429 I SettingsState:         at android.content.ContentProvider.attachInfo(ContentProvider.java:2066)
08-17 06:45:36.391   429   429 I SettingsState:         at android.app.ActivityThread.installProvider(ActivityThread.java:6983)
08-17 06:45:36.391   429   429 I SettingsState:         at android.app.ActivityThread.installContentProviders(ActivityThread.java:6528)
08-17 06:45:36.391   429   429 I SettingsState:         at android.app.ActivityThread.installSystemProviders(ActivityThread.java:7169)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.server.am.ActivityManagerService.installSystemProviders(ActivityManagerService.java:7668)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.server.SystemServer.startOtherServices(SystemServer.java:984)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.server.SystemServer.run(SystemServer.java:514)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.server.SystemServer.main(SystemServer.java:351)
08-17 06:45:36.391   429   429 I SettingsState:         at java.lang.reflect.Method.invoke(Native Method)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:492)
08-17 06:45:36.391   429   429 I SettingsState:         at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:908)
08-17 06:45:36.392   429   429 I SettingsState: ancestor directory /data/system/users/0 exists
08-17 06:45:36.392   429   429 I SettingsState: ancestor directory /data/system/users/0 permissions: r: true w: true x: true
08-17 06:45:36.392   429   429 I SettingsState: ancestor's parent directory /data/system/users permissions: r: true w: true x: true
08-17 06:45:36.397   429   429 I SettingsState: No settings state /data/system/users/0/settings_ssaid.xml
08-17 06:45:36.397   429   429 I SettingsState: directory info for directory/file /data/system/users/0/settings_ssaid.xml with stacktrace
08-17 06:45:36.397   429   429 I SettingsState: java.lang.Exception
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsState.logSettingsDirectoryInformation(SettingsState.java:753)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsState.readStateSyncLocked(SettingsState.java:852)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsState.<init>(SettingsState.java:277)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.ensureSettingsStateLocked(SettingsProvider.java:2589)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.ensureSettingsForUserLocked(SettingsProvider.java:2577)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.peekSettingsStateLocked(SettingsProvider.java:2867)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.getSettingsNamesLocked(SettingsProvider.java:2519)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.syncSsaidTableOnStart(SettingsProvider.java:2501)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider$SettingsRegistry.<init>(SettingsProvider.java:2397)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.providers.settings.SettingsProvider.onCreate(SettingsProvider.java:330)
08-17 06:45:36.397   429   429 I SettingsState:         at android.content.ContentProvider.attachInfo(ContentProvider.java:2092)
08-17 06:45:36.397   429   429 I SettingsState:         at android.content.ContentProvider.attachInfo(ContentProvider.java:2066)
08-17 06:45:36.397   429   429 I SettingsState:         at android.app.ActivityThread.installProvider(ActivityThread.java:6983)
08-17 06:45:36.397   429   429 I SettingsState:         at android.app.ActivityThread.installContentProviders(ActivityThread.java:6528)
08-17 06:45:36.397   429   429 I SettingsState:         at android.app.ActivityThread.installSystemProviders(ActivityThread.java:7169)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.server.am.ActivityManagerService.installSystemProviders(ActivityManagerService.java:7668)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.server.SystemServer.startOtherServices(SystemServer.java:984)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.server.SystemServer.run(SystemServer.java:514)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.server.SystemServer.main(SystemServer.java:351)
08-17 06:45:36.397   429   429 I SettingsState:         at java.lang.reflect.Method.invoke(Native Method)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:492)
08-17 06:45:36.397   429   429 I SettingsState:         at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:908)
08-17 06:45:36.397   429   429 I SettingsState: ancestor directory /data/system/users/0 exists
08-17 06:45:36.397   429   429 I SettingsState: ancestor directory /data/system/users/0 permissions: r: true w: true x: true
08-17 06:45:36.397   429   429 I SettingsState: ancestor's parent directory /data/system/users permissions: r: true w: true x: true
08-17 06:45:36.414   429   429 D SystemServerTiming: InstallSystemProviders took to complete: 47ms
08-17 06:45:36.414   429   429 I SystemServer: StartDropBoxManager
08-17 06:45:36.414   429   429 I SystemServiceManager: Starting com.android.server.DropBoxManagerService
08-17 06:45:36.415   429   429 D SystemServerTiming: StartDropBoxManager took to complete: 1ms
08-17 06:45:36.415   429   429 I SystemServer: StartVibratorService
08-17 06:45:36.416   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.vibrator@1.0::IVibrator/default in either framework or device manifest.
08-17 06:45:36.417   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.vibrator@1.0::IVibrator/default in either framework or device manifest.
08-17 06:45:36.417   244   244 W Zygote  : Class not found for preloading: android.bluetooth.BluetoothA2dp$2
08-17 06:45:36.418   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.vibrator@1.0::IVibrator/default in either framework or device manifest.
08-17 06:45:36.418   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.vibrator@1.3::IVibrator/default in either framework or device manifest.
08-17 06:45:36.420   429   429 D SystemServerTiming: StartVibratorService took to complete: 5ms
08-17 06:45:36.420   429   429 I SystemServer: StartDynamicSystemService
08-17 06:45:36.421   429   429 D SystemServerTiming: StartDynamicSystemService took to complete: 1ms
08-17 06:45:36.421   429   429 I SystemServer: StartConsumerIrService
08-17 06:45:36.422   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.ir@1.0::IConsumerIr/default in either framework or device manifest.
08-17 06:45:36.423   429   429 D SystemServerTiming: StartConsumerIrService took to complete: 1ms
08-17 06:45:36.423   429   429 I SystemServer: StartAlarmManagerService
08-17 06:45:36.424   244   244 I PackageBackwardCompatibility: Could not find android.content.pm.AndroidTestBaseUpdater, ignoring
08-17 06:45:36.433   429   429 D SystemServerTiming: StartAlarmManagerService took to complete: 10ms
08-17 06:45:36.433   429   429 I SystemServer: StartInputManagerService
08-17 06:45:36.433   429   429 I InputManager: Initializing input manager, mUseDevInputEventForAudioJack=false
08-17 06:45:36.436   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.input.classifier@1.0::IInputClassifier/default in either framework or device manifest.
08-17 06:45:36.436   429   520 I chatty  : uid=1000 system_server expire 1 line
08-17 06:45:36.437   429   521 I chatty  : uid=1000 system_server expire 1 line
08-17 06:45:36.438   429   429 D SystemServerTiming: StartInputManagerService took to complete: 4ms
08-17 06:45:36.438   429   429 I SystemServer: StartWindowManagerService
08-17 06:45:36.443   429   452 I WindowManager: No existing display settings, starting empty
08-17 06:45:36.450   429   452 I chatty  : uid=1000(system) android.display expire 3 lines
08-17 06:45:36.459   429   429 D SystemServerTiming: StartWindowManagerService took to complete: 21ms
08-17 06:45:36.459   429   429 I SystemServer: SetWindowManagerService
08-17 06:45:36.462   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:36.500   429   429 D SystemServerTiming: SetWindowManagerService took to complete: 41ms
08-17 06:45:36.501   429   429 I SystemServer: WindowManagerServiceOnInitReady
08-17 06:45:36.507   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:36.510   429   451 I chatty  : uid=1000(system) android.io identical 1 line
08-17 06:45:36.514   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:36.519   429   429 D SystemServerTiming: WindowManagerServiceOnInitReady took to complete: 18ms
08-17 06:45:36.519   429   429 I SystemServer: StartInputManager
08-17 06:45:36.519   429   429 I InputManager: Starting input manager
08-17 06:45:36.519   429   523 D SystemServerInitThreadPool: Started executing StartHidlServices
08-17 06:45:36.520   429   429 D SystemServerTiming: StartInputManager took to complete: 1ms
08-17 06:45:36.521   429   429 I SystemServer: DisplayManagerWindowManagerAndInputReady
08-17 06:45:36.521   429   429 D SystemServerTiming: DisplayManagerWindowManagerAndInputReady took to complete: 1ms
08-17 06:45:36.521   429   429 I SystemServer: StartBluetoothService
08-17 06:45:36.521   429   429 I SystemServiceManager: Starting com.android.server.BluetoothService
08-17 06:45:36.522   429   429 D BluetoothManagerService: Loading stored name and address
08-17 06:45:36.523   429   429 D BluetoothManagerService: Stored bluetooth Name=rk3399,Address=null
08-17 06:45:36.523   429   429 D BluetoothManagerService: Bluetooth persisted state: 0
08-17 06:45:36.523   429   429 D BluetoothManagerService: Detected SystemUiUid: 10082
08-17 06:45:36.523   429   429 D SystemServerTiming: StartBluetoothService took to complete: 2ms
08-17 06:45:36.523   429   429 I SystemServer: IpConnectivityMetrics
08-17 06:45:36.523   429   429 I SystemServiceManager: Starting com.android.server.connectivity.IpConnectivityMetrics
08-17 06:45:36.525   429   429 D SystemServerTiming: IpConnectivityMetrics took to complete: 1ms
08-17 06:45:36.525   429   429 I SystemServer: NetworkWatchlistService
08-17 06:45:36.525   429   429 I SystemServiceManager: Starting com.android.server.net.watchlist.NetworkWatchlistService$Lifecycle
08-17 06:45:36.525   429   523 I chatty  : uid=1000 system_server expire 2 lines
08-17 06:45:36.526   429   525 I chatty  : uid=1000(system) InputReader expire 23 lines
08-17 06:45:36.527   429   523 D SystemServerTimingAsync: StartHidlServices took to complete: 8ms
08-17 06:45:36.527   429   523 D SystemServerInitThreadPool: Finished executing StartHidlServices
08-17 06:45:36.533   429   429 I WatchlistSettings: Reload watchlist settings done
08-17 06:45:36.533   429   526 I WatchlistLoggingHandler: No need to aggregate record yet.
08-17 06:45:36.533   429   526 I WatchlistLoggingHandler: Milliseconds spent on tryAggregateRecords(): 0
08-17 06:45:36.534   429   429 D SystemServerTiming: NetworkWatchlistService took to complete: 9ms
08-17 06:45:36.534   429   429 I SystemServer: PinnerService
08-17 06:45:36.534   429   429 I SystemServiceManager: Starting com.android.server.PinnerService
08-17 06:45:36.536   429   429 D SystemServerTiming: PinnerService took to complete: 2ms
08-17 06:45:36.536   429   429 I SystemServer: SignedConfigService
08-17 06:45:36.537   429   429 D SystemServerTiming: SignedConfigService took to complete: 0ms
08-17 06:45:36.575   429   429 I SystemServer: StartInputMethodManagerLifecycle
08-17 06:45:36.576   429   429 I SystemServiceManager: Starting com.android.server.inputmethod.InputMethodManagerService$Lifecycle
08-17 06:45:36.582   429   429 D SystemServerTiming: StartInputMethodManagerLifecycle took to complete: 7ms
08-17 06:45:36.582   429   429 I SystemServer: StartAccessibilityManagerService
08-17 06:45:36.582   429   429 I SystemServiceManager: Starting com.android.server.accessibility.AccessibilityManagerService$Lifecycle
08-17 06:45:36.586   429   429 D SystemServerTiming: StartAccessibilityManagerService took to complete: 3ms
08-17 06:45:36.586   429   429 I SystemServer: MakeDisplayReady
08-17 06:45:36.594   429   429 I ActivityTaskManager: Config changes=20005df8 {1.0 ?mcc?mnc [en_US] ldltr sw877dp w877dp h1098dp 280dpi xlrg port ?uimode ?night finger -keyb/v/h -nav/h winConfig={ mBo
unds=Rect(0, 0 - 1536, 2048) mAppBounds=Rect(0, 0 - 1536, 1964) mWindowingMode=fullscreen mDisplayWindowingMode=fullscreen mActivityType=undefined mAlwaysOnTop=undefined mRotation=ROTATION_0} s.2}
08-17 06:45:36.599   244   244 E ActivityRecognitionHardware: activity_recognition HAL is deprecated. class_init is effectively a no-op
08-17 06:45:36.601   429   429 I ActivityTaskManager: Override config changes=60007dfc {1.0 ?mcc?mnc [en_US] ldltr sw877dp w877dp h1098dp 280dpi xlrg port ?uimode ?night finger -keyb/v/h -nav/h winCon
fig={ mBounds=Rect(0, 0 - 1536, 2048) mAppBounds=Rect(0, 0 - 1536, 1964) mWindowingMode=fullscreen mDisplayWindowingMode=fullscreen mActivityType=undefined mAlwaysOnTop=undefined mRotation=ROTATION_0}
 s.2} for displayId=0
08-17 06:45:36.611   429   429 D SystemServerTiming: MakeDisplayReady took to complete: 25ms
08-17 06:45:36.611   429   429 I SystemServer: StartStorageManagerService
08-17 06:45:36.611   429   429 I SystemServiceManager: Starting com.android.server.StorageManagerService$Lifecycle
08-17 06:45:36.619   429   527 D StorageManagerService: Thinking about init, mBootCompleted=false, mDaemonConnected=true
08-17 06:45:36.619   429   429 D SystemServerTiming: StartStorageManagerService took to complete: 9ms
08-17 06:45:36.619   429   429 I SystemServer: StartStorageStatsService
08-17 06:45:36.619   429   527 D StorageManagerService: Thinking about reset, mBootCompleted=false, mDaemonConnected=true
08-17 06:45:36.620   429   429 I SystemServiceManager: Starting com.android.server.usage.StorageStatsService$Lifecycle
08-17 06:45:36.621   322   322 D installd: Found quota mount /dev/block/by-name/userdata at /data
08-17 06:45:36.623   322   322 D installd: Found quota mount /dev/block/by-name/userdata at /data
08-17 06:45:36.624   429   429 D SystemServerTiming: StartStorageStatsService took to complete: 5ms
08-17 06:45:36.624   429   429 I SystemServer: StartUiModeManager
08-17 06:45:36.624   429   429 I SystemServiceManager: Starting com.android.server.UiModeManagerService
08-17 06:45:36.626   429   456 D SystemServerInitThreadPool: Started executing UiModeManager.onStart
08-17 06:45:36.628   429   429 D SystemServerTiming: StartUiModeManager took to complete: 3ms
08-17 06:45:36.628   429   429 I SystemServer: UpdatePackagesIfNeeded
08-17 06:45:36.628   429   429 I Watchdog: Pausing HandlerChecker: main thread for reason: dexopt. Pause count: 1
08-17 06:45:36.628   429   429 I Watchdog: Resuming HandlerChecker: main thread for reason: dexopt. Pause count: 0
08-17 06:45:36.628   429   429 D SystemServerTiming: UpdatePackagesIfNeeded took to complete: 1ms
08-17 06:45:36.628   429   429 I SystemServer: PerformFstrimIfNeeded
08-17 06:45:36.629   429   429 D SystemServerTiming: PerformFstrimIfNeeded took to complete: 0ms
08-17 06:45:36.629   429   429 I SystemServer: StartLockSettingsService
08-17 06:45:36.629   429   429 I SystemServiceManager: Starting com.android.server.locksettings.LockSettingsService$Lifecycle
08-17 06:45:36.629   429   456 I ActivityTaskManager: Config changes=200 {1.0 ?mcc?mnc [en_US] ldltr sw877dp w877dp h1098dp 280dpi xlrg port finger -keyb/v/h -nav/h winConfig={ mBounds=Rect(0, 0 - 153
6, 2048) mAppBounds=Rect(0, 0 - 1536, 1964) mWindowingMode=fullscreen mDisplayWindowingMode=fullscreen mActivityType=undefined mAlwaysOnTop=undefined mRotation=ROTATION_0} s.4}
08-17 06:45:36.637   429   456 I ActivityTaskManager: Override config changes=200 {1.0 ?mcc?mnc [en_US] ldltr sw877dp w877dp h1098dp 280dpi xlrg port finger -keyb/v/h -nav/h winConfig={ mBounds=Rect(0
, 0 - 1536, 2048) mAppBounds=Rect(0, 0 - 1536, 1964) mWindowingMode=fullscreen mDisplayWindowingMode=fullscreen mActivityType=undefined mAlwaysOnTop=undefined mRotation=ROTATION_0} s.4} for displayId=
0
08-17 06:45:36.638   429   456 D SystemServerInitThreadPool: Finished executing UiModeManager.onStart
08-17 06:45:36.656   244   244 I zygote  : Thread[1,tid=244,Native,Thread*=0xefe5ce00,peer=0x12d00260,"main"] recursive attempt to load library "libmedia_jni.so"
08-17 06:45:36.656   429   429 D SystemServerTiming: StartLockSettingsService took to complete: 27ms
08-17 06:45:36.656   244   244 D MtpDeviceJNI: register_android_mtp_MtpDevice
08-17 06:45:36.657   429   429 I SystemServer: StartTestHarnessMode
08-17 06:45:36.657   244   244 I zygote  : Thread[1,tid=244,Native,Thread*=0xefe5ce00,peer=0x12d00260,"main"] recursive attempt to load library "libmedia_jni.so"
08-17 06:45:36.657   429   429 I SystemServiceManager: Starting com.android.server.testharness.TestHarnessModeService
08-17 06:45:36.657   244   244 I zygote  : Thread[1,tid=244,Native,Thread*=0xefe5ce00,peer=0x12d00260,"main"] recursive attempt to load library "libmedia_jni.so"
08-17 06:45:36.657   429   429 D SystemServerTiming: StartTestHarnessMode took to complete: 1ms
08-17 06:45:36.658   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.oemlock@1.0::IOemLock/default in either framework or device manifest.
08-17 06:45:36.659   429   429 I OemLock : OemLock HAL not present on device
08-17 06:45:36.659   429   429 I SystemServer: StartDeviceIdleController
08-17 06:45:36.659   429   429 I SystemServiceManager: Starting com.android.server.DeviceIdleController
08-17 06:45:36.663   429   429 D SystemServerTiming: StartDeviceIdleController took to complete: 4ms
08-17 06:45:36.663   429   429 I SystemServer: StartDevicePolicyManager
08-17 06:45:36.663   429   429 I SystemServiceManager: Starting com.android.server.devicepolicy.DevicePolicyManagerService$Lifecycle
08-17 06:45:36.667   244   244 W Zygote  : Class not found for preloading: android.media.audiopolicy.AudioProductStrategies
08-17 06:45:36.667   244   244 W Zygote  : Class not found for preloading: android.media.audiopolicy.AudioVolumeGroups
08-17 06:45:36.671   429   429 D SystemServerTiming: StartDevicePolicyManager took to complete: 9ms
08-17 06:45:36.671   429   429 I SystemServer: StartStatusBarManagerService
08-17 06:45:36.673   429   429 D SystemServerTiming: StartStatusBarManagerService took to complete: 2ms
08-17 06:45:36.673   429   429 D SystemServer: ContentCaptureService disabled because resource is not overlaid
08-17 06:45:36.673   429   429 D SystemServer: AttentionService is not configured on this device
08-17 06:45:36.674   429   429 D SystemServer: SystemCaptionsManagerService disabled because resource is not overlaid
08-17 06:45:36.674   429   429 D SystemServer: AppPredictionService not defined by OEM
08-17 06:45:36.674   429   429 D SystemServer: ContentSuggestionsService not defined by OEM
08-17 06:45:36.674   429   429 I SystemServer: InitNetworkStackClient
08-17 06:45:36.675   429   429 D SystemServerTiming: InitNetworkStackClient took to complete: 2ms
08-17 06:45:36.675   429   429 I SystemServer: StartNetworkManagementService
08-17 06:45:36.679   242   242 I netd    : registerUnsolicitedEventListener() <0.07ms>
08-17 06:45:36.680   429   429 D SystemServerTiming: StartNetworkManagementService took to complete: 5ms
08-17 06:45:36.680   429   429 I SystemServer: StartIpSecService
08-17 06:45:36.682   429   429 D SystemServerTiming: StartIpSecService took to complete: 2ms
08-17 06:45:36.682   429   429 I SystemServer: StartTextServicesManager
08-17 06:45:36.682   429   429 I SystemServiceManager: Starting com.android.server.textservices.TextServicesManagerService$Lifecycle
08-17 06:45:36.683   429   429 D SystemServerTiming: StartTextServicesManager took to complete: 1ms
08-17 06:45:36.683   429   429 I SystemServer: StartTextClassificationManagerService
08-17 06:45:36.683   429   429 I SystemServiceManager: Starting com.android.server.textclassifier.TextClassificationManagerService$Lifecycle
08-17 06:45:36.685   429   429 D SystemServerTiming: StartTextClassificationManagerService took to complete: 2ms
08-17 06:45:36.685   429   429 I SystemServer: StartNetworkScoreService
08-17 06:45:36.685   429   429 I SystemServiceManager: Starting com.android.server.NetworkScoreService$Lifecycle
08-17 06:45:36.687   429   429 D SystemServerTiming: StartNetworkScoreService took to complete: 1ms
08-17 06:45:36.687   429   429 I SystemServer: StartNetworkStatsService
08-17 06:45:36.689   429   429 D SystemServerTiming: StartNetworkStatsService took to complete: 1ms
08-17 06:45:36.689   429   429 I SystemServer: StartNetworkPolicyManagerService
08-17 06:45:36.692   429   429 D SystemServerTiming: StartNetworkPolicyManagerService took to complete: 3ms
08-17 06:45:36.693   429   429 I SystemServer: StartWifi
08-17 06:45:36.714   429   429 I SystemServiceManager: Starting com.android.server.wifi.WifiService
08-17 06:45:36.754   532   533 I adbd    : opening control endpoint /dev/usb-ffs/adb/ep0
08-17 06:45:36.755   532   533 I adbd    : UsbFfsConnection constructed
08-17 06:45:36.758   532   534 I adbd    : USB event: FUNCTIONFS_BIND
08-17 06:45:36.779   244   244 W Zygote  : Class not found for preloading: android.view.-$$Lambda$SurfaceView$Cs7TGTdA1lXf9qW8VOJAfEsMjdk
08-17 06:45:36.787   244   244 W Zygote  : Class not found for preloading: android.view.SurfaceView$3
08-17 06:45:36.791   244   244 W Zygote  : Class not found for preloading: android.view.textclassifier.-$$Lambda$TextClassificationManager$JIaezIJbMig_-kVzN6oArzkTsJE
08-17 06:45:36.800   244   244 W Zygote  : Class not found for preloading: com.android.internal.net.NetworkStatsFactory
08-17 06:45:36.807   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$PhoneSubInfoController$8HFbCDJDN1mrLJG980qYH5MGqMk
08-17 06:45:36.807   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$PhoneSubInfoController$U28a_EGx2cvmQhDfRRgonMt5Zrc
08-17 06:45:36.807   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$SubscriptionInfoUpdater$-zZXM9oMRZ3vZz7dJOG19J00Bmw
08-17 06:45:36.808   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$SubscriptionInfoUpdater$D5yF1HbS4cvCyoAj3FESkPtA_0g
08-17 06:45:36.808   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.-$$Lambda$SubscriptionInfoUpdater$MMx9iQX0JVqqMPLTUZhdBubFSzU
08-17 06:45:36.812   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.PhoneConfigurationModels
08-17 06:45:36.814   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.SubscriptionController$ScLocalLog
08-17 06:45:36.816   244   244 W Zygote  : Class not found for preloading: com.android.internal.telephony.UiccSmsController
08-17 06:45:36.863   244   244 I Zygote  : ...preloaded 7588 classes in 506ms.
08-17 06:45:36.863   244   244 I zygote  : VMRuntime.preloadDexCaches starting
08-17 06:45:36.873   429   537 I chatty  : uid=1000(system) ClientModeImpl expire 7 lines
08-17 06:45:36.880   429   429 D SystemServerTiming: StartWifi took to complete: 187ms
08-17 06:45:36.880   429   429 I SystemServer: StartWifiScanning
08-17 06:45:36.881   429   429 I SystemServiceManager: Starting com.android.server.wifi.scanner.WifiScanningService
08-17 06:45:36.883   429   429 D SystemServerTiming: StartWifiScanning took to complete: 4ms
08-17 06:45:36.883   429   429 I SystemServer: StartWifiP2P
08-17 06:45:36.884   429   429 I SystemServiceManager: Starting com.android.server.wifi.p2p.WifiP2pService
08-17 06:45:36.891   429   429 D SystemServerTiming: StartWifiP2P took to complete: 8ms
08-17 06:45:36.891   429   429 I SystemServer: StartEthernet
08-17 06:45:36.892   429   429 I SystemServiceManager: Starting com.android.server.ethernet.EthernetService
08-17 06:45:36.893   429   429 D SystemServerTiming: StartEthernet took to complete: 2ms
08-17 06:45:36.893   429   429 I SystemServer: StartConnectivityService
08-17 06:45:36.896   244   244 I zygote  : VMRuntime.preloadDexCaches strings total=380611 before=9924 after=9924
08-17 06:45:36.896   244   244 I zygote  : VMRuntime.preloadDexCaches types total=35902 before=7192 after=7460
08-17 06:45:36.896   244   244 I zygote  : VMRuntime.preloadDexCaches fields total=161215 before=8020 after=8221
08-17 06:45:36.896   244   244 I zygote  : VMRuntime.preloadDexCaches methods total=282425 before=10884 after=11316
08-17 06:45:36.896   244   244 I zygote  : VMRuntime.preloadDexCaches finished
08-17 06:45:36.896   244   244 D ZygoteInitTiming_lazy: PreloadClasses took to complete: 539ms
08-17 06:45:36.897   429   429 D ConnectivityService: ConnectivityService starting up
08-17 06:45:36.899   429   429 D ConnectivityService: wifiOnly=false
08-17 06:45:36.899   244   244 I zygote  : The ClassLoaderContext is a special shared library.
08-17 06:45:36.900   244   244 D ApplicationLoaders: Created zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:36.903   244   244 I zygote  : The ClassLoaderContext is a special shared library.
08-17 06:45:36.904   244   244 D ApplicationLoaders: Created zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:36.904   244   244 D ZygoteInitTiming_lazy: CacheNonBootClasspathClassLoaders took to complete: 7ms
08-17 06:45:36.913   429   429 D SystemServerTiming: StartConnectivityService took to complete: 19ms
08-17 06:45:36.913   429   429 I SystemServer: StartNsdService
08-17 06:45:36.917   429   429 D NsdService: Network service discovery is enabled
08-17 06:45:36.919   429   429 D SystemServerTiming: StartNsdService took to complete: 6ms
08-17 06:45:36.919   429   429 I SystemServer: StartSystemUpdateManagerService
08-17 06:45:36.920   429   429 I SystemUpdateManagerService: No existing info file /data/system/system-update-info.xml
08-17 06:45:36.921   429   429 D SystemServerTiming: StartSystemUpdateManagerService took to complete: 1ms
08-17 06:45:36.921   429   429 I SystemServer: StartUpdateLockService
08-17 06:45:36.922   429   429 D SystemServerTiming: StartUpdateLockService took to complete: 1ms
08-17 06:45:36.932   268   301 D rkdisplay-resources: Frame buffers:
08-17 06:45:36.932   268   301 D rkdisplay-resources: id        size    pitch
08-17 06:45:36.933   268   301 D rkdisplay-resources:  FEATURE:
08-17 06:45:36.933   268   301 D rkdisplay-resources:           flags: immutable bitmask
08-17 06:45:36.933   268   301 D rkdisplay-resources:           values:afbdc=1
08-17 06:45:36.933   268   301 D rkdisplay-resources:           value:1
08-17 06:45:36.933   268   301 D rkdisplay-resources:
08-17 06:45:36.933   268   301 D rkdisplay-resources: current_crtc id : 78  crtid : 67
08-17 06:45:36.933   268   301 D rkdisplay-resources: current_crtc id : 80  crtid : 0
08-17 06:45:36.933   268   301 D rkdisplay-resources: current_crtc id : 82  crtid : 0
08-17 06:45:36.933   268   301 D rkdisplay-resources: Encoders:
08-17 06:45:36.933   268   301 D rkdisplay-resources: id        crtc    type    possible crtcs  possible clones
08-17 06:45:36.933   268   301 D rkdisplay-resources: 4e        43      TMDS    2       0
08-17 06:45:36.933   268   301 D rkdisplay-resources:
08-17 06:45:36.933   268   301 D rkdisplay-resources: 50        0       TMDS    1       0
08-17 06:45:36.933   268   301 D rkdisplay-resources:
08-17 06:45:36.933   268   301 D rkdisplay-resources: 52        0       TMDS    1       0
08-17 06:45:36.933   268   301 D rkdisplay-resources:
08-17 06:45:36.934   268   301 D hwc-drm-connector: crtc_id_property_: name CRTC_ID
08-17 06:45:36.934   268   301 W hwc-drm-connector: Could not get hdmi_output_colorimetry property
08-17 06:45:36.934   268   301 W hwc-drm-connector: Could not get hdmi_output_format property
08-17 06:45:36.934   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_colorimetry property
08-17 06:45:36.934   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_format property
08-17 06:45:36.934   268   301 D hwc-drm-connector: crtc_id_property_: name CRTC_ID
08-17 06:45:36.934   268   301 W hwc-drm-connector: Could not get hdmi_output_colorimetry property
08-17 06:45:36.935   268   301 W hwc-drm-connector: Could not get hdmi_output_format property
08-17 06:45:36.935   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_colorimetry property
08-17 06:45:36.935   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_format property
08-17 06:45:36.935   268   301 D hwc-drm-connector: crtc_id_property_: name CRTC_ID
08-17 06:45:36.936   268   301 D rkdisplay-resources:  hue:
08-17 06:45:36.936   268   301 D rkdisplay-resources:           flags: range
08-17 06:45:36.936   268   301 D rkdisplay-resources:           values:064
08-17 06:45:36.936   268   301 D rkdisplay-resources:           value:32
08-17 06:45:36.936   268   301 D rkdisplay-resources:
08-17 06:45:36.936   268   301 D hw_output: nativeInit:
08-17 06:45:36.936   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_colorimetry property
08-17 06:45:36.936   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_format property
08-17 06:45:36.936   268   301 D hw_output: old_state 1 cur_state 1 conn->get_type() 14
08-17 06:45:36.936   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_colorimetry property
08-17 06:45:36.936   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_format property
08-17 06:45:36.936   268   301 D hw_output: old_state 2 cur_state 2 conn->get_type() 10
08-17 06:45:36.936   268   301 D hw_output: old_state 2 cur_state 2 conn->get_type() 11
08-17 06:45:36.936   268   301 D hw_output: primary: 0x74e0c3e800 extend: 0x0
08-17 06:45:36.941   150   150 E SELinux : avc:  denied  { add } for service=rockchip_audio_setting pid=429 uid=1000 scontext=u:r:system_server:s0 tcontext=u:object_r:default_android_service:s0 tclass
=service_manager permissive=0
08-17 06:45:36.941   150   150 E ServiceManager: add_service('rockchip_audio_setting',68) uid=1000 - PERMISSION DENIED
08-17 06:45:36.944   429   429 E SystemServer: Failure starting RkAudioSettingManager Service
08-17 06:45:36.944   429   429 E SystemServer: java.lang.SecurityException
08-17 06:45:36.944   429   429 E SystemServer:  at android.os.BinderProxy.transactNative(Native Method)
08-17 06:45:36.944   429   429 E SystemServer:  at android.os.BinderProxy.transact(BinderProxy.java:511)
08-17 06:45:36.944   429   429 E SystemServer:  at android.os.ServiceManagerProxy.addService(ServiceManagerNative.java:156)
08-17 06:45:36.944   429   429 E SystemServer:  at android.os.ServiceManager.addService(ServiceManager.java:192)
08-17 06:45:36.944   429   429 E SystemServer:  at android.os.ServiceManager.addService(ServiceManager.java:161)
08-17 06:45:36.944   429   429 E SystemServer:  at com.android.server.SystemServer.startOtherServices(SystemServer.java:1433)
08-17 06:45:36.944   429   429 E SystemServer:  at com.android.server.SystemServer.run(SystemServer.java:514)
08-17 06:45:36.944   429   429 E SystemServer:  at com.android.server.SystemServer.main(SystemServer.java:351)
08-17 06:45:36.944   429   429 E SystemServer:  at java.lang.reflect.Method.invoke(Native Method)
08-17 06:45:36.944   429   429 E SystemServer:  at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:492)
08-17 06:45:36.944   429   429 E SystemServer:  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:908)
08-17 06:45:36.944   429   429 I SystemServer: StartNotificationManager
08-17 06:45:36.944   429   429 I SystemServiceManager: Starting com.android.server.notification.NotificationManagerService
08-17 06:45:36.957   429   429 D ConditionProviders.SCP: new ScheduleConditionProvider()
08-17 06:45:36.970   429   429 I NotificationListeners: Read notification listener permissions from xml
08-17 06:45:36.971   429   429 I NotificationAssistants: Read notification assistant permissions from xml
08-17 06:45:36.971   429   429 I ConditionProviders: Read condition provider permissions from xml
08-17 06:45:36.971   429   429 I ConditionProviders: Read condition provider permissions from xml
08-17 06:45:36.971   429   429 D NotificationAssistants: Approving default notification assistant for user 0
08-17 06:45:36.973   429   429 I ConditionProviders:  Allowing condition provider android.ext.services/android.ext.services.notification.Assistant
08-17 06:45:36.974   429   429 D NotificationService: Set default NAS to be android.ext.services/android.ext.services.notification.Assistant in 0
08-17 06:45:36.985   429   429 D SystemServerTiming: StartNotificationManager took to complete: 40ms
08-17 06:45:36.985   429   429 I SystemServer: StartDeviceMonitor
08-17 06:45:36.985   429   429 I SystemServiceManager: Starting com.android.server.storage.DeviceStorageMonitorService
08-17 06:45:36.986   429   429 D SystemServerTiming: StartDeviceMonitor took to complete: 2ms
08-17 06:45:36.987   429   429 I SystemServer: StartLocationManagerService
08-17 06:45:36.989   429   429 D SystemServerTiming: StartLocationManagerService took to complete: 3ms
08-17 06:45:36.989   429   429 I SystemServer: StartCountryDetectorService
08-17 06:45:36.990   429   429 D SystemServerTiming: StartCountryDetectorService took to complete: 0ms
08-17 06:45:36.990   429   429 I SystemServer: StartTimeDetectorService
08-17 06:45:36.990   429   429 I SystemServiceManager: Starting com.android.server.timedetector.TimeDetectorService$Lifecycle
08-17 06:45:36.991   429   429 D SystemServerTiming: StartTimeDetectorService took to complete: 2ms
08-17 06:45:36.991   429   429 I SystemServer: StartSearchManagerService
08-17 06:45:36.991   429   429 I SystemServiceManager: Starting com.android.server.search.SearchManagerService$Lifecycle
08-17 06:45:36.992   429   429 D SystemServerTiming: StartSearchManagerService took to complete: 1ms
08-17 06:45:36.992   429   429 I SystemServer: StartWallpaperManagerService
08-17 06:45:36.993   429   429 I SystemServiceManager: Starting com.android.server.wallpaper.WallpaperManagerService$Lifecycle
08-17 06:45:36.994   244   244 I Zygote  : Preloading resources...
08-17 06:45:36.995   429   429 D SystemServerTiming: StartWallpaperManagerService took to complete: 3ms
08-17 06:45:36.995   429   429 I SystemServer: StartAudioService
08-17 06:45:36.995   429   429 I SystemServiceManager: Starting com.android.server.audio.AudioService$Lifecycle
08-17 06:45:37.007   244   244 W Resources: Preloaded drawable resource #0x108027d (android:drawable/dialog_background_material) that varies with configuration!!
08-17 06:45:37.010   271   271 D PermissionCache: checking android.permission.MODIFY_AUDIO_ROUTING for uid=1000 => granted (698 us)
08-17 06:45:37.012   271   390 D PermissionCache: checking android.permission.MODIFY_AUDIO_SETTINGS for uid=1000 => granted (193 us)
08-17 06:45:37.013   271   395 W AudioFlinger: no wake lock to update, system not ready yet
08-17 06:45:37.015   248   248 W DeviceHAL: Error from HAL Device in function set_mic_mute: Function not implemented
08-17 06:45:37.015   248   248 W DeviceHAL: Error from HAL Device in function set_mic_mute: Function not implemented
08-17 06:45:37.024   244   244 I Zygote  : ...preloaded 64 resources in 31ms.
08-17 06:45:37.028   244   244 I Zygote  : ...preloaded 41 resources in 4ms.
08-17 06:45:37.028   244   244 D ZygoteInitTiming_lazy: PreloadResources took to complete: 125ms
08-17 06:45:37.041   271   390 D AudioFlinger: isLowRamDevice:false totalMemory:4027035648 mClientSharedHeapSize:16777216
08-17 06:45:37.042   429   429 D SystemServerTiming: StartAudioService took to complete: 46ms
08-17 06:45:37.042   429   429 I SystemServer: StartDockObserver
08-17 06:45:37.042   429   429 I SystemServiceManager: Starting com.android.server.DockObserver
08-17 06:45:37.043   429   429 W DockObserver: This kernel does not have dock station support
08-17 06:45:37.043   429   429 D SystemServerTiming: StartDockObserver took to complete: 1ms
08-17 06:45:37.043   429   429 I SystemServer: StartWiredAccessoryManager
08-17 06:45:37.045   429   429 W WiredAccessoryManager: This kernel does not have wired headset support
08-17 06:45:37.045   429   429 W WiredAccessoryManager: This kernel does not have usb audio support
08-17 06:45:37.045   429   429 W WiredAccessoryManager: This kernel does not have HDMI audio support
08-17 06:45:37.045   429   429 D SystemServerTiming: StartWiredAccessoryManager took to complete: 2ms
08-17 06:45:37.045   429   429 I SystemServer: StartAdbService
08-17 06:45:37.045   429   429 I SystemServiceManager: Starting com.android.server.adb.AdbService$Lifecycle
08-17 06:45:37.047   429   429 D SystemServerTiming: StartAdbService took to complete: 1ms
08-17 06:45:37.047   429   429 I SystemServer: StartUsbService
08-17 06:45:37.047   429   429 I SystemServiceManager: Starting com.android.server.usb.UsbService$Lifecycle
08-17 06:45:37.049   429   429 E UsbDeviceManager: failed to write to /sys/class/android_usb/android0/f_rndis/ethaddr
08-17 06:45:37.050   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.usb.gadget@1.0::IUsbGadget/default in either framework or device manifest.
08-17 06:45:37.054   429   429 I UsbDeviceManager: USB GADGET HAL not present in the device
08-17 06:45:37.054   429   429 I UsbDeviceManager: java.util.NoSuchElementException
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at android.os.HwBinder.getService(Native Method)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at android.hardware.usb.gadget.V1_0.IUsbGadget.getService(IUsbGadget.java:55)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at android.hardware.usb.gadget.V1_0.IUsbGadget.getService(IUsbGadget.java:62)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.usb.UsbDeviceManager.<init>(UsbDeviceManager.java:262)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.usb.UsbService.<init>(UsbService.java:150)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.usb.UsbService$Lifecycle.onStart(UsbService.java:84)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.SystemServiceManager.startService(SystemServiceManager.java:129)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.SystemServiceManager.startService(SystemServiceManager.java:116)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.SystemServiceManager.startService(SystemServiceManager.java:75)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.SystemServer.startOtherServices(SystemServer.java:1559)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.SystemServer.run(SystemServer.java:514)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.server.SystemServer.main(SystemServer.java:351)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at java.lang.reflect.Method.invoke(Native Method)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:492)
08-17 06:45:37.054   429   429 I UsbDeviceManager:      at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:908)
08-17 06:45:37.062   429   429 W StorageManagerService: No primary storage defined yet; hacking together a stub
08-17 06:45:37.066   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.usb@1.0::IUsb/default in either framework or device manifest.
08-17 06:45:37.067   429   429 E UsbPortManager: connectToProxy: usb hal service not found. Did the service fail to start?
08-17 06:45:37.067   429   429 E UsbPortManager: java.util.NoSuchElementException
08-17 06:45:37.067   429   429 E UsbPortManager:        at android.os.HwBinder.getService(Native Method)
08-17 06:45:37.067   429   429 E UsbPortManager:        at android.os.HwBinder.getService(HwBinder.java:83)
08-17 06:45:37.067   429   429 E UsbPortManager:        at android.hardware.usb.V1_0.IUsb.getService(IUsb.java:70)
08-17 06:45:37.067   429   429 E UsbPortManager:        at android.hardware.usb.V1_0.IUsb.getService(IUsb.java:77)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.usb.UsbPortManager.connectToProxy(UsbPortManager.java:780)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.usb.UsbPortManager.<init>(UsbPortManager.java:175)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.usb.UsbService.<init>(UsbService.java:153)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.usb.UsbService$Lifecycle.onStart(UsbService.java:84)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.SystemServiceManager.startService(SystemServiceManager.java:129)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.SystemServiceManager.startService(SystemServiceManager.java:116)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.SystemServiceManager.startService(SystemServiceManager.java:75)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.SystemServer.startOtherServices(SystemServer.java:1559)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.SystemServer.run(SystemServer.java:514)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.server.SystemServer.main(SystemServer.java:351)
08-17 06:45:37.067   429   429 E UsbPortManager:        at java.lang.reflect.Method.invoke(Native Method)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:492)
08-17 06:45:37.067   429   429 E UsbPortManager:        at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:908)
08-17 06:45:37.070   429   429 D SystemServerTiming: StartUsbService took to complete: 22ms
08-17 06:45:37.070   429   429 I SystemServer: StartSerialService
08-17 06:45:37.071   429   429 D SystemServerTiming: StartSerialService took to complete: 0ms
08-17 06:45:37.071   429   429 I SystemServer: StartHardwarePropertiesManagerService
08-17 06:45:37.072   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.thermal@1.0::IThermal/default in either framework or device manifest.
08-17 06:45:37.072   429   429 D SystemServerTiming: StartHardwarePropertiesManagerService took to complete: 2ms
08-17 06:45:37.072   429   429 I SystemServer: StartTwilightService
08-17 06:45:37.072   429   429 I SystemServiceManager: Starting com.android.server.twilight.TwilightService
08-17 06:45:37.073   429   429 D SystemServerTiming: StartTwilightService took to complete: 0ms
08-17 06:45:37.073   429   429 I SystemServer: StartColorDisplay
08-17 06:45:37.073   429   429 I SystemServiceManager: Starting com.android.server.display.color.ColorDisplayService
08-17 06:45:37.075   429   429 D SystemServerTiming: StartColorDisplay took to complete: 3ms
08-17 06:45:37.075   429   429 I SystemServer: StartJobScheduler
08-17 06:45:37.075   429   429 I SystemServiceManager: Starting com.android.server.job.JobSchedulerService
08-17 06:45:37.082   429   429 D JobStore: Start tag: job-info
08-17 06:45:37.084   429   429 I JobStore: Read 2 jobs
08-17 06:45:37.088   429   429 D SystemServerTiming: StartJobScheduler took to complete: 13ms
08-17 06:45:37.089   429   429 I SystemServer: StartSoundTrigger
08-17 06:45:37.089   429   429 I SystemServiceManager: Starting com.android.server.soundtrigger.SoundTriggerService
08-17 06:45:37.090   429   429 D SystemServerTiming: StartSoundTrigger took to complete: 1ms
08-17 06:45:37.090   429   429 I SystemServer: StartTrustManager
08-17 06:45:37.090   429   429 I SystemServiceManager: Starting com.android.server.trust.TrustManagerService
08-17 06:45:37.091   429   429 D SystemServerTiming: StartTrustManager took to complete: 2ms
08-17 06:45:37.091   429   429 I SystemServer: StartBackupManager
08-17 06:45:37.091   429   429 I SystemServiceManager: Starting com.android.server.backup.BackupManagerService$Lifecycle
08-17 06:45:37.094   429   429 D SystemServerTiming: StartBackupManager took to complete: 2ms
08-17 06:45:37.094   429   429 I SystemServer: StartAppWidgetService
08-17 06:45:37.094   429   429 I SystemServiceManager: Starting com.android.server.appwidget.AppWidgetService
08-17 06:45:37.096   429   429 D SystemServerTiming: StartAppWidgetService took to complete: 3ms
08-17 06:45:37.097   429   429 I SystemServer: StartRoleManagerService
08-17 06:45:37.100   429   429 D SystemServerTiming: StartRoleManagerService took to complete: 3ms
08-17 06:45:37.100   429   429 I SystemServer: StartVoiceRecognitionManager
08-17 06:45:37.100   429   429 I SystemServiceManager: Starting com.android.server.voiceinteraction.VoiceInteractionManagerService
08-17 06:45:37.103   429   429 I RoleUserState: Read roles.xml successfully
08-17 06:45:37.104   429   429 D SystemServerTiming: StartVoiceRecognitionManager took to complete: 4ms
08-17 06:45:37.104   429   429 I SystemServer: StartGestureLauncher
08-17 06:45:37.104   429   429 I SystemServiceManager: Starting com.android.server.GestureLauncherService
08-17 06:45:37.104   429   429 D SystemServerTiming: StartGestureLauncher took to complete: 0ms
08-17 06:45:37.104   429   429 I SystemServer: StartSensorNotification
08-17 06:45:37.104   429   429 I SystemServiceManager: Starting com.android.server.SensorNotificationService
08-17 06:45:37.104   429   429 D SystemServerTiming: StartSensorNotification took to complete: 0ms
08-17 06:45:37.104   429   429 I SystemServer: StartContextHubSystemService
08-17 06:45:37.104   429   429 I SystemServiceManager: Starting com.android.server.ContextHubSystemService
08-17 06:45:37.105   429   429 D SystemServerTiming: StartContextHubSystemService took to complete: 0ms
08-17 06:45:37.105   429   429 I SystemServer: StartDiskStatsService
08-17 06:45:37.105   429   507 D SystemServerInitThreadPool: Started executing Init ContextHubSystemService
08-17 06:45:37.106   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.contexthub@1.0::IContexthub/default in either framework or device manifest.
08-17 06:45:37.106   429   507 D SystemServerInitThreadPool: Finished executing Init ContextHubSystemService
08-17 06:45:37.107   429   429 D SystemServerTiming: StartDiskStatsService took to complete: 2ms
08-17 06:45:37.107   429   429 I SystemServer: RuntimeService
08-17 06:45:37.107   429   429 D SystemServerTiming: RuntimeService took to complete: 1ms
08-17 06:45:37.107   429   429 I SystemServer: StartNetworkTimeUpdateService
08-17 06:45:37.108   429   429 D SystemServer: Using networkTimeUpdater class=class com.android.server.NewNetworkTimeUpdateService
08-17 06:45:37.108   429   429 D SystemServerTiming: StartNetworkTimeUpdateService took to complete: 1ms
08-17 06:45:37.108   429   429 I SystemServer: CertBlacklister
08-17 06:45:37.109   429   429 D SystemServerTiming: CertBlacklister took to complete: 1ms
08-17 06:45:37.109   429   429 I SystemServer: StartEmergencyAffordanceService
08-17 06:45:37.110   429   429 I SystemServiceManager: Starting com.android.server.emergency.EmergencyAffordanceService
08-17 06:45:37.110   429   429 D SystemServerTiming: StartEmergencyAffordanceService took to complete: 0ms
08-17 06:45:37.110   429   429 I SystemServer: StartDreamManager
08-17 06:45:37.110   429   429 I SystemServiceManager: Starting com.android.server.dreams.DreamManagerService
08-17 06:45:37.111   429   429 D SystemServerTiming: StartDreamManager took to complete: 1ms
08-17 06:45:37.111   429   429 I SystemServer: AddGraphicsStatsService
08-17 06:45:37.112   429   429 D SystemServerTiming: AddGraphicsStatsService took to complete: 1ms
08-17 06:45:37.114   429   429 I SystemServer: StartPrintManager
08-17 06:45:37.114   429   429 I SystemServiceManager: Starting com.android.server.print.PrintManagerService
08-17 06:45:37.117   429   429 D SystemServerTiming: StartPrintManager took to complete: 2ms
08-17 06:45:37.117   429   429 I SystemServer: StartCompanionDeviceManager
08-17 06:45:37.117   429   429 I SystemServiceManager: Starting com.android.server.companion.CompanionDeviceManagerService
08-17 06:45:37.118   429   429 D SystemServerTiming: StartCompanionDeviceManager took to complete: 2ms
08-17 06:45:37.118   429   429 I SystemServer: StartRestrictionManager
08-17 06:45:37.118   429   429 I SystemServiceManager: Starting com.android.server.restrictions.RestrictionsManagerService
08-17 06:45:37.119   429   429 D SystemServerTiming: StartRestrictionManager took to complete: 1ms
08-17 06:45:37.119   429   429 I SystemServer: StartMediaSessionService
08-17 06:45:37.120   429   429 I SystemServiceManager: Starting com.android.server.media.MediaSessionService
08-17 06:45:37.127   244   244 D libEGL  : loaded /vendor/lib/egl/libGLES_mali.so
08-17 06:45:37.131   429   429 D SystemServerTiming: StartMediaSessionService took to complete: 12ms
08-17 06:45:37.131   429   429 I SystemServer: StartMediaResourceMonitor
08-17 06:45:37.131   429   429 I SystemServiceManager: Starting com.android.server.media.MediaResourceMonitorService
08-17 06:45:37.132   429   429 D SystemServerTiming: StartMediaResourceMonitor took to complete: 0ms
08-17 06:45:37.132   429   429 I SystemServer: StartMediaRouterService
08-17 06:45:37.133   429   429 D SystemServerTiming: StartMediaRouterService took to complete: 2ms
08-17 06:45:37.133   429   429 I SystemServer: StartBackgroundDexOptService
08-17 06:45:37.134   429   429 D SystemServerTiming: StartBackgroundDexOptService took to complete: 1ms
08-17 06:45:37.134   429   429 I SystemServer: StartDynamicCodeLoggingService
08-17 06:45:37.135   429   429 D SystemServerTiming: StartDynamicCodeLoggingService took to complete: 1ms
08-17 06:45:37.135   429   429 I SystemServer: StartPruneInstantAppsJobService
08-17 06:45:37.135   429   429 D SystemServerTiming: StartPruneInstantAppsJobService took to complete: 0ms
08-17 06:45:37.136   429   429 I SystemServer: StartShortcutServiceLifecycle
08-17 06:45:37.136   429   429 I SystemServiceManager: Starting com.android.server.pm.ShortcutService$Lifecycle
08-17 06:45:37.138   429   429 D SystemServerTiming: StartShortcutServiceLifecycle took to complete: 2ms
08-17 06:45:37.138   429   429 I SystemServer: StartLauncherAppsService
08-17 06:45:37.138   429   429 I SystemServiceManager: Starting com.android.server.pm.LauncherAppsService
08-17 06:45:37.139   429   429 D SystemServerTiming: StartLauncherAppsService took to complete: 1ms
08-17 06:45:37.139   429   429 I SystemServer: StartCrossProfileAppsService
08-17 06:45:37.139   429   429 I SystemServiceManager: Starting com.android.server.pm.CrossProfileAppsService
08-17 06:45:37.140   429   429 D SystemServerTiming: StartCrossProfileAppsService took to complete: 0ms
08-17 06:45:37.140   429   429 I SystemServer: StartMediaProjectionManager
08-17 06:45:37.140   429   429 I SystemServiceManager: Starting com.android.server.media.projection.MediaProjectionManagerService
08-17 06:45:37.144   429   429 D SystemServerTiming: StartMediaProjectionManager took to complete: 5ms
08-17 06:45:37.144   429   429 I SystemServer: StartSliceManagerService
08-17 06:45:37.144   429   429 I SystemServiceManager: Starting com.android.server.slice.SliceManagerService$Lifecycle
08-17 06:45:37.146   429   429 D SystemServerTiming: StartSliceManagerService took to complete: 2ms
08-17 06:45:37.147   429   429 I SystemServer: StartCameraServiceProxy
08-17 06:45:37.147   429   429 I SystemServiceManager: Starting com.android.server.camera.CameraServiceProxy
08-17 06:45:37.149   429   429 D SystemServerTiming: StartCameraServiceProxy took to complete: 2ms
08-17 06:45:37.149   429   429 I SystemServer: StartStatsCompanionService
08-17 06:45:37.149   429   429 I SystemServiceManager: Starting com.android.server.stats.StatsCompanionService$Lifecycle
08-17 06:45:37.151   429   429 I StatsCompanionService: register thermal listener successfully
08-17 06:45:37.151   244   244 I Zygote  : Preloading shared libraries...
08-17 06:45:37.154   429   429 D SystemServerTiming: StartStatsCompanionService took to complete: 4ms
08-17 06:45:37.154   429   429 I SystemServer: StartIncidentCompanionService
08-17 06:45:37.154   429   429 I SystemServiceManager: Starting com.android.server.incident.IncidentCompanionService
08-17 06:45:37.155   429   429 D SystemServerTiming: StartIncidentCompanionService took to complete: 1ms
08-17 06:45:37.156   429   429 I SystemServer: StartMmsService
08-17 06:45:37.156   429   429 I SystemServiceManager: Starting com.android.server.MmsServiceBroker
08-17 06:45:37.156   429   429 D SystemServerTiming: StartMmsService took to complete: 1ms
08-17 06:45:37.156   429   429 I SystemServer: StartAutoFillService
08-17 06:45:37.157   429   429 I SystemServiceManager: Starting com.android.server.autofill.AutofillManagerService
08-17 06:45:37.159   429   429 D AutofillManagerService: setLogLevelFromSettings(): level=2, debug=true, verbose=false
08-17 06:45:37.160   429   429 D AutofillManagerService: setMaxPartitionsFromSettings(): 10
08-17 06:45:37.160   429   429 D AutofillManagerService: setMaxVisibleDatasetsFromSettings(): 0
08-17 06:45:37.161   429   429 D AutofillManagerServiceImpl: Reset component for user 0:
08-17 06:45:37.161   429   450 D AutofillUI: destroySaveUiUiThread(): already destroyed
08-17 06:45:37.162   429   429 D SystemServerTiming: StartAutoFillService took to complete: 5ms
08-17 06:45:37.162   429   429 I SystemServer: StartClipboardService
08-17 06:45:37.162   429   429 I SystemServiceManager: Starting com.android.server.clipboard.ClipboardService
08-17 06:45:37.163   429   429 D SystemServerTiming: StartClipboardService took to complete: 1ms
08-17 06:45:37.163   429   429 I SystemServer: AppServiceManager
08-17 06:45:37.163   429   429 I SystemServiceManager: Starting com.android.server.appbinding.AppBindingService$Lifecycle
08-17 06:45:37.164   429   429 D SystemServerTiming: AppServiceManager took to complete: 0ms
08-17 06:45:37.164   429   429 I SystemServer: MakeVibratorServiceReady
08-17 06:45:37.165   429   429 D SystemServerTiming: MakeVibratorServiceReady took to complete: 2ms
08-17 06:45:37.165   429   429 I SystemServer: MakeLockSettingsServiceReady
08-17 06:45:37.167   244   244 I Zygote  : Called ZygoteHooks.endPreload()
08-17 06:45:37.168   244   244 I Zygote  : Installed AndroidKeyStoreProvider in 1ms.
08-17 06:45:37.178   244   244 I Zygote  : Warmed up JCA providers in 10ms.
08-17 06:45:37.178   244   244 D Zygote  : end preload
08-17 06:45:37.178   429   514 D SystemServerTimingAsync: SecondaryZygotePreload took to complete: 845ms
08-17 06:45:37.178   429   514 D SystemServerInitThreadPool: Finished executing SecondaryZygotePreload
08-17 06:45:37.181   266   266 I /vendor/bin/hw/android.hardware.weaver@1.0-service: getConfig: slots:100 keySize:32 valueSize:32
08-17 06:45:37.182   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.authsecret@1.0::IAuthSecret/default in either framework or device manifest.
08-17 06:45:37.182   429   429 I LockSettingsService: Device doesn't implement AuthSecret HAL
08-17 06:45:37.184   429   429 E LockSettingsStorage: Cannot read file java.io.FileNotFoundException: /data/system/gatekeeper.password.key: open failed: ENOENT (No such file or directory)
08-17 06:45:37.184   429   429 E LockSettingsStorage: Cannot read file java.io.FileNotFoundException: /data/system/password.key: open failed: ENOENT (No such file or directory)
08-17 06:45:37.185   429   429 E LockSettingsStorage: Cannot read file java.io.FileNotFoundException: /data/system/gatekeeper.pattern.key: open failed: ENOENT (No such file or directory)
08-17 06:45:37.185   429   429 E LockSettingsStorage: Cannot read file java.io.FileNotFoundException: /data/system/gatekeeper.gesture.key: open failed: ENOENT (No such file or directory)
08-17 06:45:37.185   429   429 E LockSettingsStorage: Cannot read file java.io.FileNotFoundException: /data/system/gesture.key: open failed: ENOENT (No such file or directory)
08-17 06:45:37.185   429   429 D SystemServerTiming: MakeLockSettingsServiceReady took to complete: 20ms
08-17 06:45:37.185   429   429 I SystemServer: StartBootPhaseLockSettingsReady
08-17 06:45:37.185   429   429 I SystemServiceManager: Starting phase 480
08-17 06:45:37.188   429   429 I DevicePolicyManager: Set ro.device_owner property to false
08-17 06:45:37.190   429   515 D SystemServerInitThreadPool: Started executing DevicePolicyManager
08-17 06:45:37.190   429   515 D SystemServerInitThreadPool: Finished executing DevicePolicyManager
08-17 06:45:37.193   429   429 D SystemServerTiming: StartBootPhaseLockSettingsReady took to complete: 8ms
08-17 06:45:37.193   429   429 I SystemServer: StartBootPhaseSystemServicesReady
08-17 06:45:37.193   429   429 I SystemServiceManager: Starting phase 500
08-17 06:45:37.194   429   429 D AppStandbyController: Setting app idle enabled state
08-17 06:45:37.203   429   429 D TestHarnessModeService: Setting up test harness mode
08-17 06:45:37.203   429   429 D TestHarnessModeService: Getting PersistentDataBlockManagerInternal from LocalServices
08-17 06:45:37.203   429   429 E TestHarnessModeService: Failed to start Test Harness Mode; no implementation of PersistentDataBlockManagerInternal was bound!
08-17 06:45:37.207   429   429 I WifiService: WifiService starting up with Wi-Fi disabled
08-17 06:45:37.213   532   534 I adbd    : USB event: FUNCTIONFS_ENABLE
08-17 06:45:37.234   429   540 D ConnectivityService: Got NetworkFactory Messenger for Ethernet
08-17 06:45:37.235   429   567 I chatty  : uid=1000(system) EthernetService expire 20 lines
08-17 06:45:37.237   242   242 I netd    : interfaceGetList() -> {["ip6_vti0","eth1","sit0","ip6tnl0","ip_vti0","lo","eth0"]} <0.17ms>
08-17 06:45:37.238   242   242 I netd    : interfaceGetCfg("eth1") <0.40ms>
08-17 06:45:37.242   271   390 D PermissionCache: checking android.permission.CAPTURE_AUDIO_HOTWORD for uid=1000 => granted (171 us)
08-17 06:45:37.242   429   429 W SoundTriggerHelper: listModules status=0, # of modules=0
08-17 06:45:37.244   429   429 D SystemServerTiming: StartBootPhaseSystemServicesReady took to complete: 51ms
08-17 06:45:37.244   429   429 I SystemServer: MakeWindowManagerServiceReady
08-17 06:45:37.244   242   242 I netd    : interfaceSetCfg() <4.26ms>
08-17 06:45:37.244   429   449 I chatty  : uid=1000(system) android.fg expire 54 lines
08-17 06:45:37.245   242   242 I netd    : interfaceGetCfg("eth1") <0.22ms>
08-17 06:45:37.246   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.0::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:37.247   429   429 W SystemServer: ***********************************************
08-17 06:45:37.247   429   429 E SystemServer: BOOT FAILURE making Window Manager Service ready
08-17 06:45:37.247   429   429 E SystemServer: java.util.NoSuchElementException
08-17 06:45:37.247   429   429 E SystemServer:  at android.os.HwBinder.getService(Native Method)
08-17 06:45:37.247   429   429 E SystemServer:  at android.os.HwBinder.getService(HwBinder.java:83)
08-17 06:45:37.247   429   429 E SystemServer:  at android.hardware.configstore.V1_0.ISurfaceFlingerConfigs.getService(ISurfaceFlingerConfigs.java:70)
08-17 06:45:37.247   429   429 E SystemServer:  at android.hardware.configstore.V1_0.ISurfaceFlingerConfigs.getService(ISurfaceFlingerConfigs.java:77)
08-17 06:45:37.247   429   429 E SystemServer:  at com.android.server.wm.WindowManagerService.queryWideColorGamutSupport(WindowManagerService.java:4570)
08-17 06:45:37.247   429   429 E SystemServer:  at com.android.server.wm.WindowManagerService.systemReady(WindowManagerService.java:4546)
08-17 06:45:37.247   429   429 E SystemServer:  at com.android.server.SystemServer.startOtherServices(SystemServer.java:1969)
08-17 06:45:37.247   429   429 E SystemServer:  at com.android.server.SystemServer.run(SystemServer.java:514)
08-17 06:45:37.247   429   429 E SystemServer:  at com.android.server.SystemServer.main(SystemServer.java:351)
08-17 06:45:37.247   429   429 E SystemServer:  at java.lang.reflect.Method.invoke(Native Method)
08-17 06:45:37.247   429   429 E SystemServer:  at com.android.internal.os.RuntimeInit$MethodAndArgsCaller.run(RuntimeInit.java:492)
08-17 06:45:37.247   429   429 E SystemServer:  at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:908)
08-17 06:45:37.248   429   429 D SystemServerTiming: MakeWindowManagerServiceReady took to complete: 3ms
08-17 06:45:37.248   242   242 I netd    : interfaceGetList() -> {["ip6_vti0","eth1","sit0","ip6tnl0","ip_vti0","lo","eth0"]} <0.08ms>
08-17 06:45:37.248   242   242 I netd    : interfaceGetCfg("eth1") <0.28ms>
08-17 06:45:37.248   429   429 I SystemServer: MakePowerManagerServiceReady
08-17 06:45:37.249   429   458 I DropBoxManagerService: add tag=system_server_wtf isTagEnabled=true flags=0x2
08-17 06:45:37.249   242   242 I netd    : interfaceSetCfg() <0.46ms>
08-17 06:45:37.250   242   242 I netd    : interfaceGetCfg("eth0") <0.28ms>
08-17 06:45:37.253   429   429 E DisplayPowerController: failed to set up display white-balance: java.lang.IllegalStateException: cannot find sensor com.google.sensor.color
08-17 06:45:37.259   429   466 W KeyguardServiceDelegate: onScreenTurningOn(): no keyguard service!
08-17 06:45:37.260   429   466 V DisplayPowerController: Brightness [102] reason changing to: 'override', previous reason: '0'.
08-17 06:45:37.261   429   429 D SystemServerTiming: MakePowerManagerServiceReady took to complete: 13ms
08-17 06:45:37.261   429   429 I SystemServer: StartPermissionPolicyService
08-17 06:45:37.262   429   429 I SystemServiceManager: Starting com.android.server.policy.PermissionPolicyService
08-17 06:45:37.264   429   429 D SystemServerTiming: StartPermissionPolicyService took to complete: 3ms
08-17 06:45:37.264   429   429 I SystemServer: MakePackageManagerServiceReady
08-17 06:45:37.268   429   429 I PackageManager: Un-granting permission android.permission.GLOBAL_SEARCH from package com.android.quicksearchbox (protectionLevel=18 flags=0x3088be45)
08-17 06:45:37.269   429   429 I PackageManager: Un-granting permission android.permission.WRITE_MEDIA_STORAGE from package com.android.soundrecorder (protectionLevel=18 flags=0x3088be45)
08-17 06:45:37.269   429   429 I PackageManager: Un-granting permission android.permission.MOUNT_UNMOUNT_FILESYSTEMS from package com.android.soundrecorder (protectionLevel=18 flags=0x3088be45)
08-17 06:45:37.271   242   242 I netd    : interfaceSetCfg() <19.89ms>
08-17 06:45:37.271   242   375 I netd    : interfaceGetCfg("eth0") <0.35ms>
08-17 06:45:37.273   242   375 I netd    : interfaceGetList() -> {["ip6_vti0","eth1","sit0","ip6tnl0","ip_vti0","lo","eth0"]} <0.12ms>
08-17 06:45:37.274   242   375 I netd    : interfaceGetCfg("eth1") <0.29ms>
08-17 06:45:37.275   242   242 I netd    : interfaceSetCfg() <0.56ms>
08-17 06:45:37.283   429   429 V UserDataPreparer: Found /data/user_de/0 with serial number 0
08-17 06:45:37.283   429   429 V UserDataPreparer: Found /data/user/0 with serial number 0
08-17 06:45:37.283   429   429 V UserDataPreparer: Found /data/system_de/0 with serial number 0
08-17 06:45:37.284   429   429 V UserDataPreparer: Found /data/system_ce/0 with serial number 0
08-17 06:45:37.284   429   429 V UserDataPreparer: Found /data/misc_ce/0 with serial number 0
08-17 06:45:37.289   429   429 D SystemServerTiming: MakePackageManagerServiceReady took to complete: 25ms
08-17 06:45:37.289   429   429 I SystemServer: MakeDisplayManagerServiceReady
08-17 06:45:37.290   429   429 D SystemServerTiming: MakeDisplayManagerServiceReady took to complete: 1ms
08-17 06:45:37.290   429   429 I SystemServer: StartDeviceSpecificServices
08-17 06:45:37.291   429   429 D SystemServerTiming: StartDeviceSpecificServices took to complete: 0ms
08-17 06:45:37.291   429   429 I SystemServer: StartBootPhaseDeviceSpecificServicesReady
08-17 06:45:37.291   429   429 I SystemServiceManager: Starting phase 520
08-17 06:45:37.291   429   429 D SystemServerTiming: StartBootPhaseDeviceSpecificServicesReady took to complete: 1ms
08-17 06:45:37.292   429   429 D ActivityTaskManager: OK, system ready!
08-17 06:45:37.292   429   429 W UsageStatsService: Event reported without a package name, eventType:15
08-17 06:45:37.293   429   429 I AppOps  : Pruning old package system/com.android.server.appop.AppOpsService$UidState@b27faa1: new uid=-1
08-17 06:45:37.295   429   429 I ActivityManager: System now ready
08-17 06:45:37.296   429   538 I chatty  : uid=1000(system) WifiP2pService expire 1 line
08-17 06:45:37.304   429   429 I SystemServer: Making services ready
08-17 06:45:37.304   429   429 I SystemServer: StartActivityManagerReadyPhase
08-17 06:45:37.304   429   429 I SystemServiceManager: Starting phase 550
08-17 06:45:37.305   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.thermal@2.0::IThermal/default in either framework or device manifest.
08-17 06:45:37.305   429   429 E ThermalHalWrapper: Thermal HAL 2.0 service not connected.
08-17 06:45:37.307   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.thermal@1.1::IThermal/default in either framework or device manifest.
08-17 06:45:37.307   429   429 E ThermalHalWrapper: Thermal HAL 1.1 service not connected.
08-17 06:45:37.308   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.thermal@1.0::IThermal/default in either framework or device manifest.
08-17 06:45:37.309   429   429 E ThermalHalWrapper: Thermal HAL 1.0 service not connected.
08-17 06:45:37.311   429   429 W ActivityManager: Too early to start/bind service in system_server: Phase=550 ComponentInfo{com.android.server.telecom/com.android.server.telecom.components.TelecomServ
ice}
08-17 06:45:37.311   429   429 W ActivityManager: Too early to start/bind service in system_server: Phase=550 ComponentInfo{com.android.server.telecom/com.android.server.telecom.components.TelecomServ
ice}
08-17 06:45:37.314   429   429 I SyncManager: No initial accounts
08-17 06:45:37.314   429   429 I SyncManager: No initial status
08-17 06:45:37.314   429   429 I SyncManager: No initial statistics
08-17 06:45:37.317   429   429 D BluetoothManagerService: Bluetooth boot completed
08-17 06:45:37.317   429   429 D BluetoothManagerService: Getting adapter name and address
08-17 06:45:37.317   429   451 D BluetoothManagerService: MESSAGE_GET_NAME_AND_ADDRESS
08-17 06:45:37.318   429   451 D BluetoothManagerService: Binding to service to get name and address
08-17 06:45:37.327   243   243 D Zygote  : Forked child process 573
08-17 06:45:37.331   429   459 I ActivityManager: Start proc 573:com.android.bluetooth/1002 for service {com.android.bluetooth/com.android.bluetooth.btservice.AdapterService}
08-17 06:45:37.354   532   532 I adbd    : UsbFfs: already offline
08-17 06:45:37.369   573   573 I droid.bluetoot: The ClassLoaderContext is a special shared library.
08-17 06:45:37.383   429   429 W SystemServiceManager: Service com.android.server.inputmethod.InputMethodManagerService$Lifecycle took 63 ms in onBootPhase
08-17 06:45:37.385   429   527 D StorageManagerService: Isolated storage local flag 0 and remote flag 0 resolved to true
08-17 06:45:37.388   429   429 I WallpaperManagerService: No static wallpaper imagery; defaults will be shown
08-17 06:45:37.388   429   429 V WallpaperManagerService: bindWallpaperComponentLocked: componentName=ComponentInfo{com.android.systemui/com.android.systemui.ImageWallpaper}
08-17 06:45:37.395   429   429 W WallpaperManagerService: Invalid wallpaper data
08-17 06:45:37.395   429   429 E WallpaperManagerService: Unable to apply new wallpaper
08-17 06:45:37.396   248   248 D AudioHardwareTiny: adev_set_parameters: kvpairs = A2dpSuspended=false
08-17 06:45:37.397   429   429 I AppBindingService: Updating constants with: null
08-17 06:45:37.398   248   248 D AudioHardwareTiny: adev_set_parameters: kvpairs = BT_SCO=off
08-17 06:45:37.399   429   551 D BluetoothManagerService: Trying to bind to profile: 1, while Bluetooth was disabled
08-17 06:45:37.402   243   243 D Zygote  : Forked child process 595
08-17 06:45:37.406   429   444 I chatty  : uid=1000(system) FinalizerDaemon expire 2 lines
08-17 06:45:37.419   429   551 I chatty  : uid=1000(system) AudioService expire 1 line
08-17 06:45:37.419   429   459 I ActivityManager: Start proc 595:com.android.systemui/u0a82 for service {com.android.systemui/com.android.systemui.ImageWallpaper}
08-17 06:45:37.421   429   429 I PackageManager: Un-granting permission android.permission.GLOBAL_SEARCH from package com.android.quicksearchbox (protectionLevel=18 flags=0x3088be45)
08-17 06:45:37.422   429   429 I PackageManager: Un-granting permission android.permission.WRITE_MEDIA_STORAGE from package com.android.soundrecorder (protectionLevel=18 flags=0x3088be45)
08-17 06:45:37.422   429   429 I PackageManager: Un-granting permission android.permission.MOUNT_UNMOUNT_FILESYSTEMS from package com.android.soundrecorder (protectionLevel=18 flags=0x3088be45)
08-17 06:45:37.431   429   429 D SystemServerTiming: StartActivityManagerReadyPhase took to complete: 127ms
08-17 06:45:37.431   429   429 I SystemServer: StartObservingNativeCrashes
08-17 06:45:37.432   429   429 D SystemServerTiming: StartObservingNativeCrashes took to complete: 0ms
08-17 06:45:37.432   429   429 I SystemServer: StartSystemUI
08-17 06:45:37.432   429   498 D SystemServerInitThreadPool: Started executing WebViewFactoryPreparation
08-17 06:45:37.432   429   498 I SystemServer: WebViewFactoryPreparation
08-17 06:45:37.434   271   390 I AudioFlinger: systemReady
08-17 06:45:37.436   429   429 D SystemServerTiming: StartSystemUI took to complete: 4ms
08-17 06:45:37.437   429   429 I SystemServer: MakeNetworkManagementServiceReady
08-17 06:45:37.438   242   242 I netd    : firewallSetFirewallType(1) <0.01ms>
08-17 06:45:37.439   429   498 D SystemServerTimingAsync: WebViewFactoryPreparation took to complete: 7ms
08-17 06:45:37.439   429   498 D SystemServerInitThreadPool: Finished executing WebViewFactoryPreparation
08-17 06:45:37.439   429   429 D SystemServerTiming: MakeNetworkManagementServiceReady took to complete: 3ms
08-17 06:45:37.439   429   429 I SystemServer: MakeIpSecServiceReady
08-17 06:45:37.441   242   242 I netd    : isAlive() -> {"true"} <0.01ms>
08-17 06:45:37.441   429   429 D IpSecService: IpSecService is ready
08-17 06:45:37.441   429   429 D SystemServerTiming: MakeIpSecServiceReady took to complete: 2ms
08-17 06:45:37.441   429   429 I SystemServer: MakeNetworkStatsServiceReady
08-17 06:45:37.449   429   530 W NetworkPolicy: setRestrictBackgroundUL: already false
08-17 06:45:37.452   242   242 I netd    : trafficSwapActiveStatsMap() <6.19ms>
08-17 06:45:37.453   429   594 I chatty  : uid=1000(system) UsbService host expire 7 lines
08-17 06:45:37.454   242   371 I netd    : firewallReplaceUidChain("fw_standby", "false", []) -> {"true"} <0.07ms>
08-17 06:45:37.454   242   375 I netd    : tetherGetStats() <1.46ms>
08-17 06:45:37.455   429   594 D UsbHostManager: USB device attached: vidpid 0bda:8153 mfg/product/ver/serial Realtek/USB 10/100/1000 LAN/31.00/001000001 hasAudio/HID/Storage: false/false/false
08-17 06:45:37.460   429   594 D UsbHostManager: Added device UsbDevice[mName=/dev/bus/usb/001/003,mVendorId=3034,mProductId=33107,mClass=0,mSubclass=0,mProtocol=0,mManufacturerName=Realtek,mProductNa
me=USB 10/100/1000 LAN,mVersion=31.00,mSerialNumberReader=com.android.server.usb.UsbSerialReader@dde2160,mConfigurations=[
08-17 06:45:37.460   429   594 D UsbHostManager: UsbConfiguration[mId=1,mName=null,mAttributes=160,mMaxPower=175,mInterfaces=[
08-17 06:45:37.460   429   594 D UsbHostManager: UsbInterface[mId=0,mAlternateSetting=0,mName=null,mClass=255,mSubclass=255,mProtocol=0,mEndpoints=[
08-17 06:45:37.460   429   594 D UsbHostManager: UsbEndpoint[mAddress=129,mAttributes=2,mMaxPacketSize=512,mInterval=0]
08-17 06:45:37.460   429   594 D UsbHostManager: UsbEndpoint[mAddress=2,mAttributes=2,mMaxPacketSize=512,mInterval=0]
08-17 06:45:37.460   429   594 D UsbHostManager: UsbEndpoint[mAddress=131,mAttributes=3,mMaxPacketSize=2,mInterval=8]]]
08-17 06:45:37.460   429   594 D UsbHostManager: UsbConfiguration[mId=2,mName=null,mAttributes=160,mMaxPower=175,mInterfaces=[
08-17 06:45:37.460   429   594 D UsbHostManager: UsbInterface[mId=0,mAlternateSetting=0,mName=CDC Communications Control,mClass=2,mSubclass=6,mProtocol=0,mEndpoints=[
08-17 06:45:37.460   429   594 D UsbHostManager: UsbEndpoint[mAddress=131,mAttributes=3,mMaxPacketSize=16,mInterval=8]]
08-17 06:45:37.460   429   594 D UsbHostManager: UsbInterface[mId=1,mAlternateSetting=0,mName=null,mClass=10,mSubclass=0,mProtocol=0,mEndpoints=[]
08-17 06:45:37.460   429   594 D UsbHostManager: UsbInterface[mId=1,mAlternateSetting=1,mName=Ethernet Data,mClass=10,mSubclass=0,mProtocol=0,mEndpoints=[
08-17 06:45:37.460   429   594 D UsbHostManager: UsbEndpoint[mAddress=129,mAttributes=2,mMaxPacketSize=512,mInterval=0]
08-17 06:45:37.460   429   594 D UsbHostManager: UsbEndpoint[mAddress=2,mAttributes=2,mMaxPacketSize=512,mInterval=0]]]]
08-17 06:45:37.461   242   375 I netd    : bandwidthSetGlobalAlert(2097152) <1.99ms>
08-17 06:45:37.461   429   429 D SystemServerTiming: MakeNetworkStatsServiceReady took to complete: 20ms
08-17 06:45:37.461   429   429 I SystemServer: MakeConnectivityServiceReady
08-17 06:45:37.462   429   429 D ConnectivityService: requestNetwork for uid/pid:1000/429 NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ]
08-17 06:45:37.474   429   530 I chatty  : uid=1000(system) NetworkPolicy expire 1 line
08-17 06:45:37.474   242   375 I netd    : networkSetPermissionForUser(1, []) <0.01ms>
08-17 06:45:37.474   242   375 I netd    : networkSetPermissionForUser(2, [10082,1027,10083,10051,10053,10085,10086,10087,1000,10088,10089,1001,10090,1002,10091,10092,10093,2000,10040,10041,10073,1007
7,10046]) <0.01ms>
08-17 06:45:37.475   242   375 I netd    : trafficSetNetPermForUids(12, [1001,1002,1013,10040]) <0.07ms>
08-17 06:45:37.475   242   375 I netd    : trafficSetNetPermForUids(4, [1000,1027,2000,10037,10043,10046,10048,10051,10052,10053,10055,10056,10062,10065,10066,10073,10077,10084,10089,10090,10091,10092
,10093]) <0.35ms>
08-17 06:45:37.476   242   375 I netd    : trafficSetNetPermForUids(8, [1041,1047]) <0.04ms>
08-17 06:45:37.478   242   375 I netd    : trafficSetNetPermForUids(0, [1003,1063,1066,1067,1068,1073,10000,10001,10002,10003,10004,10005,10006,10007,10008,10009,10010,10011,10012,10013,10014,10015,10
016,10017,10018,10019,10020,10021,10022,10023,10024,10025,10026,10027,10028,10029,10030,10031,10032,10033,10034,10035,10036,10038,10039,10041,10042,10044,10045,10047,10049,10050,10054,10057,10058,1005
9,10060,10061,10063,10064,10067,10068,10069,10070,10071,10072,10074,10075,10076,10078,10079,10080,10081,10082,10083,10085,10086,10087,10088]) <1.20ms>
08-17 06:45:37.479   429   429 D SystemServerTiming: MakeConnectivityServiceReady took to complete: 17ms
08-17 06:45:37.479   429   429 I SystemServer: MakeNetworkPolicyServiceReady
08-17 06:45:37.479   242   375 I netd    : firewallEnableChildChain(2, "true") <0.05ms>
08-17 06:45:37.482   242   375 I netd    : socketDestroy([]) <1.33ms>
08-17 06:45:37.483   429   429 D SystemServerTiming: MakeNetworkPolicyServiceReady took to complete: 4ms
08-17 06:45:37.483   429   429 I SystemServer: PhaseThirdPartyAppsCanStart
08-17 06:45:37.483   429   429 I SystemServiceManager: Starting phase 600
08-17 06:45:37.484   429   429 I ExplicitHealthCheckController: Explicit health checks enabled.
08-17 06:45:37.484   429   429 I PackageWatchdog: Syncing state, reason: health check state enabled
08-17 06:45:37.484   429   429 I PackageWatchdog: Not pruning observers, elapsed time: 0ms
08-17 06:45:37.484   429   429 I PackageWatchdog: Cancelling state sync, nothing to sync
08-17 06:45:37.484   429   457 I PackageWatchdog: Saving observer state to file
08-17 06:45:37.488   429   429 E LightsService: Light requested not available on this device. 4
08-17 06:45:37.490   429   429 V WallpaperManagerService: bindWallpaperComponentLocked: componentName=ComponentInfo{com.android.systemui/com.android.systemui.ImageWallpaper}
08-17 06:45:37.502   327   400 D MediaCodecList: Allowing all OMX codecs
08-17 06:45:37.502   573   573 V AdapterServiceConfig: Adding A2dpService
08-17 06:45:37.503   429   429 I StatsCompanionService: Told statsd that StatsCompanionService is alive.
08-17 06:45:37.503   573   573 V AdapterServiceConfig: Adding HidHostService
08-17 06:45:37.503   573   573 V AdapterServiceConfig: Adding PanService
08-17 06:45:37.504   573   573 V AdapterServiceConfig: Adding GattService
08-17 06:45:37.504   573   573 V AdapterServiceConfig: Adding AvrcpTargetService
08-17 06:45:37.504   429   429 D SystemServerTiming: PhaseThirdPartyAppsCanStart took to complete: 21ms
08-17 06:45:37.504   573   573 V AdapterServiceConfig: Adding HidDeviceService
08-17 06:45:37.504   429   429 I SystemServer: StartNetworkStack
08-17 06:45:37.504   573   573 V AdapterServiceConfig: Adding BluetoothOppService
08-17 06:45:37.511   429   429 D SystemServerTiming: StartNetworkStack took to complete: 7ms
08-17 06:45:37.511   429   429 I SystemServer: MakeLocationServiceReady
08-17 06:45:37.511   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.512   331   331 I OMXMaster: makeComponentInstance(OMX.google.aac.decoder) in android.hardwar process
08-17 06:45:37.515   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.gnss@2.0::IGnss/default in either framework or device manifest.
08-17 06:45:37.515   429   429 D GnssLocationProvider: gnssHal 2.0 was null, trying 1.1
08-17 06:45:37.515   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.gnss@1.1::IGnss/default in either framework or device manifest.
08-17 06:45:37.516   429   429 D GnssLocationProvider: gnssHal 1.1 was null, trying 1.0
08-17 06:45:37.516   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.gnss@1.0::IGnss/default in either framework or device manifest.
08-17 06:45:37.519   244   244 D Zygote  : Forked child process 627
08-17 06:45:37.521   429   429 W LocationManagerService: no network location provider found
08-17 06:45:37.523   429   429 E LocationManagerService: no geocoder provider found
08-17 06:45:37.523   429   429 D LocationManagerService: Unable to bind FLP Geofence proxy.
08-17 06:45:37.523   429   429 E ActivityRecognitionHardware: activity_recognition HAL is deprecated. is_supported is effectively a no-op
08-17 06:45:37.523   429   429 D LocationManagerService: Hardware Activity-Recognition not supported.
08-17 06:45:37.524   429   429 D LocationManagerService: Unable to bind ActivityRecognitionProxy.
08-17 06:45:37.524   429   459 W ActivityManager: Slow operation: 86ms so far, now at startProcess: returned from zygote!
08-17 06:45:37.524   429   459 W ActivityManager: Slow operation: 86ms so far, now at startProcess: done updating battery stats
08-17 06:45:37.524   429   459 W ActivityManager: Slow operation: 86ms so far, now at startProcess: building log message
08-17 06:45:37.524   429   459 I ActivityManager: Start proc 627:WebViewLoader-armeabi-v7a/1037 [android.webkit.WebViewLibraryLoader$RelroFileCreator] for null
08-17 06:45:37.524   429   459 W ActivityManager: Slow operation: 86ms so far, now at startProcess: starting to update pids map
08-17 06:45:37.525   429   459 W ActivityManager: Slow operation: 86ms so far, now at startProcess: done updating pids map
08-17 06:45:37.525   429   459 W ActivityManager: Slow operation: 86ms so far, now at startProcess: asking zygote to start proc
08-17 06:45:37.527   429   429 D SystemServerTiming: MakeLocationServiceReady took to complete: 16ms
08-17 06:45:37.527   429   429 I SystemServer: MakeCountryDetectionServiceReady
08-17 06:45:37.528   429   429 D SystemServerTiming: MakeCountryDetectionServiceReady took to complete: 0ms
08-17 06:45:37.528   429   429 I SystemServer: MakeNetworkTimeUpdateReady
08-17 06:45:37.530   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.530   331   331 I OMXMaster: makeComponentInstance(OMX.google.amrnb.decoder) in android.hardwar process
08-17 06:45:37.531   429   429 D ConnectivityService: requestNetwork for uid/pid:1000/429 NetworkRequest [ TRACK_DEFAULT id=9, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1000] ]
08-17 06:45:37.533   429   429 D SystemServerTiming: MakeNetworkTimeUpdateReady took to complete: 5ms
08-17 06:45:37.534   429   429 I SystemServer: MakeInputManagerServiceReady
08-17 06:45:37.536   429   429 D SystemServerTiming: MakeInputManagerServiceReady took to complete: 2ms
08-17 06:45:37.536   429   429 I SystemServer: MakeTelephonyRegistryReady
08-17 06:45:37.537   429   429 D SystemServerTiming: MakeTelephonyRegistryReady took to complete: 0ms
08-17 06:45:37.537   429   429 I SystemServer: MakeMediaRouterServiceReady
08-17 06:45:37.537   429   429 D SystemServerTiming: MakeMediaRouterServiceReady took to complete: 0ms
08-17 06:45:37.537   429   429 I SystemServer: MakeMmsServiceReady
08-17 06:45:37.537   429   429 I MmsServiceBroker: Delay connecting to MmsService until an API is called
08-17 06:45:37.537   429   429 D SystemServerTiming: MakeMmsServiceReady took to complete: 0ms
08-17 06:45:37.537   429   429 I SystemServer: IncidentDaemonReady
08-17 06:45:37.539   429   429 D SystemServerTiming: IncidentDaemonReady took to complete: 1ms
08-17 06:45:37.539   429   429 I ActivityManager: Current user:0
08-17 06:45:37.539   243   243 D Zygote  : Forked child process 647
08-17 06:45:37.539   429   429 I SystemServiceManager: Calling onStartUser u0
08-17 06:45:37.543   429   459 W ActivityManager: Slow operation: 105ms so far, now at startProcess: returned from zygote!
08-17 06:45:37.544   429   459 W ActivityManager: Slow operation: 105ms so far, now at startProcess: done updating battery stats
08-17 06:45:37.544   429   459 W ActivityManager: Slow operation: 105ms so far, now at startProcess: building log message
08-17 06:45:37.544   429   459 I ActivityManager: Start proc 647:WebViewLoader-arm64-v8a/1037 [android.webkit.WebViewLibraryLoader$RelroFileCreator] for null
08-17 06:45:37.544   429   459 W ActivityManager: Slow operation: 106ms so far, now at startProcess: starting to update pids map
08-17 06:45:37.544   429   459 W ActivityManager: Slow operation: 106ms so far, now at startProcess: done updating pids map
08-17 06:45:37.544   429   429 W VoiceInteractionManagerService: no available voice interaction services found for user 0
08-17 06:45:37.544   429   429 W VoiceInteractionManagerService: no available voice recognition services found for user 0
08-17 06:45:37.546   429   429 W AppBindingService: [Default SMS app] u0 Target package not found
08-17 06:45:37.546   429   525 I InputReader: Reconfiguring input devices.  changes=0x00000020
08-17 06:45:37.550   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.550   331   331 I OMXMaster: makeComponentInstance(OMX.google.amrwb.decoder) in android.hardwar process
08-17 06:45:37.551   429   429 I ActivityTaskManager: START u0 {act=android.intent.action.MAIN cat=[android.intent.category.HOME] flg=0x10000100 cmp=com.android.settings/.FallbackHome} from uid 0
08-17 06:45:37.553   429   525 I InputReader: Reconfiguring input devices.  changes=0x00000010
08-17 06:45:37.556   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.556   331   331 I OMXMaster: makeComponentInstance(OMX.google.flac.decoder) in android.hardwar process
08-17 06:45:37.564   243   243 D Zygote  : Forked child process 673
08-17 06:45:37.570   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.570   331   388 I OMXMaster: makeComponentInstance(OMX.google.g711.alaw.decoder) in android.hardwar process
08-17 06:45:37.579   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.579   331   388 I OMXMaster: makeComponentInstance(OMX.google.g711.mlaw.decoder) in android.hardwar process
08-17 06:45:37.582   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.583   331   331 I OMXMaster: makeComponentInstance(OMX.google.mp3.decoder) in android.hardwar process
08-17 06:45:37.588   573   573 I         : [0817/064537.588057:INFO:com_android_bluetooth_btservice_AdapterService.cpp(628)] hal_util_load_bt_library loaded HAL: btinterface=0x72c6765440, handle=0x907
c9124e0d0283b
08-17 06:45:37.588   573   573 D BluetoothAdapterService: onCreate()
08-17 06:45:37.593   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.593   331   331 I OMXMaster: makeComponentInstance(OMX.google.opus.decoder) in android.hardwar process
08-17 06:45:37.606   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.606   331   388 I OMXMaster: makeComponentInstance(OMX.google.raw.decoder) in android.hardwar process
08-17 06:45:37.612   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.613   331   388 I OMXMaster: makeComponentInstance(OMX.google.vorbis.decoder) in android.hardwar process
08-17 06:45:37.621   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.621   331   331 I OMXMaster: makeComponentInstance(OMX.google.aac.encoder) in android.hardwar process
08-17 06:45:37.629   595   595 V SystemUIService: SystemUIApplication constructed.
08-17 06:45:37.641   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.641   331   388 I OMXMaster: makeComponentInstance(OMX.google.amrnb.encoder) in android.hardwar process
08-17 06:45:37.647   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.648   331   712 I OMXMaster: makeComponentInstance(OMX.google.amrwb.encoder) in android.hardwar process
08-17 06:45:37.656   429   698 W StorageManagerService: No primary storage defined yet; hacking together a stub
08-17 06:45:37.659   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.659   331   713 I OMXMaster: makeComponentInstance(OMX.google.flac.encoder) in android.hardwar process
08-17 06:45:37.667   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.668   331   713 I OMXMaster: makeComponentInstance(OMX.rk.video_decoder.avc) in android.hardwar process
08-17 06:45:37.671   331   331 W HwBinder:331_3: type=1400 audit(0.0:22): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.671   331   712 E OMXNodeInstance: getExtensionIndex(0xecc5a060:rk._decoder.avc, OMX.google.android.index.configureVideoTunnelMode) ERROR: BadParameter(0x80001005)
08-17 06:45:37.671   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.672   331   331 I chatty  : uid=1046(mediacodec) omx@1.0-service expire 1 line
08-17 06:45:37.672   331   331 W HwBinder:331_3: type=1400 audit(0.0:24): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.672   331   712 E libc    : Access denied finding property "vpu_mem_debug"
08-17 06:45:37.672   331   712 E libc    : Access denied finding property "mpp_buffer_debug"
08-17 06:45:37.672   331   712 I mpp_rt  : found ion allocator
08-17 06:45:37.672   331   712 I mpp_rt  : found drm allocator
08-17 06:45:37.673   331   712 I mpp_rt  : use drm allocator for mpp_service
08-17 06:45:37.673   331   712 E libc    : Access denied finding property "drm_debug"
08-17 06:45:37.673   331   712 W OMXNodeInstance: [0xecc5a060:rk._decoder.avc] component does not support metadata mode; using fallback
08-17 06:45:37.677   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.677   331   712 I OMXMaster: makeComponentInstance(OMX.google.h264.decoder) in android.hardwar process
08-17 06:45:37.686   331   713 E OMXNodeInstance: getExtensionIndex(0xecc5a060:google.h264.decoder, OMX.google.android.index.configureVideoTunnelMode) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.686   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.686   331   713 E OMXNodeInstance: getExtensionIndex(0xecc5a060:google.h264.decoder, OMX.google.android.index.enableAndroidNativeBuffers) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.689   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.689   331   713 I OMXMaster: makeComponentInstance(OMX.rk.video_decoder.h263) in android.hardwar process
08-17 06:45:37.692   331   331 W HwBinder:331_4: type=1400 audit(0.0:25): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.692   331   713 E OMXNodeInstance: getExtensionIndex(0xecc5a060:rk._decoder.h263, OMX.google.android.index.configureVideoTunnelMode) ERROR: BadParameter(0x80001005)
08-17 06:45:37.692   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.693   331   331 I chatty  : uid=1046(mediacodec) omx@1.0-service expire 1 line
08-17 06:45:37.693   331   331 W HwBinder:331_4: type=1400 audit(0.0:27): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.693   331   713 E libc    : Access denied finding property "vpu_mem_debug"
08-17 06:45:37.693   331   713 E libc    : Access denied finding property "mpp_buffer_debug"
08-17 06:45:37.693   331   713 E libc    : Access denied finding property "drm_debug"
08-17 06:45:37.693   331   713 W OMXNodeInstance: [0xecc5a060:rk._decoder.h263] component does not support metadata mode; using fallback
08-17 06:45:37.696   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.696   331   712 I OMXMaster: makeComponentInstance(OMX.rk.video_decoder.hevc) in android.hardwar process
08-17 06:45:37.700   331   331 W HwBinder:331_3: type=1400 audit(0.0:28): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.700   331   331 W HwBinder:331_3: type=1400 audit(0.0:29): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.700   331   331 W HwBinder:331_3: type=1400 audit(0.0:30): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.700   331   712 E OMXNodeInstance: getExtensionIndex(0xecc5a060:rk._decoder.hevc, OMX.google.android.index.configureVideoTunnelMode) ERROR: BadParameter(0x80001005)
08-17 06:45:37.700   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.700   331   712 E libc    : Access denied finding property "vpu_mem_debug"
08-17 06:45:37.700   331   712 E libc    : Access denied finding property "mpp_buffer_debug"
08-17 06:45:37.700   331   712 E libc    : Access denied finding property "drm_debug"
08-17 06:45:37.700   331   712 W OMXNodeInstance: [0xecc5a060:rk._decoder.hevc] component does not support metadata mode; using fallback
08-17 06:45:37.703   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.703   331   712 I OMXMaster: makeComponentInstance(OMX.google.hevc.decoder) in android.hardwar process
08-17 06:45:37.718   331   712 E OMXNodeInstance: getExtensionIndex(0xecc5a060:google.hevc.decoder, OMX.google.android.index.configureVideoTunnelMode) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.718   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.719   331   712 E OMXNodeInstance: getExtensionIndex(0xecc5a060:google.hevc.decoder, OMX.google.android.index.enableAndroidNativeBuffers) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.722   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.722   331   712 I OMXMaster: makeComponentInstance(OMX.rk.video_decoder.m2v) in android.hardwar process
08-17 06:45:37.725   331   331 W HwBinder:331_4: type=1400 audit(0.0:31): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.725   331   331 W HwBinder:331_4: type=1400 audit(0.0:32): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.725   331   331 W HwBinder:331_4: type=1400 audit(0.0:33): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.725   331   713 E OMXNodeInstance: getExtensionIndex(0xecc5a060:rk._decoder.m2v, OMX.google.android.index.configureVideoTunnelMode) ERROR: BadParameter(0x80001005)
08-17 06:45:37.725   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.725   331   713 E libc    : Access denied finding property "vpu_mem_debug"
08-17 06:45:37.725   331   713 E libc    : Access denied finding property "mpp_buffer_debug"
08-17 06:45:37.725   331   713 E libc    : Access denied finding property "drm_debug"
08-17 06:45:37.725   331   713 W OMXNodeInstance: [0xecc5a060:rk._decoder.m2v] component does not support metadata mode; using fallback
08-17 06:45:37.728   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.728   331   713 I OMXMaster: makeComponentInstance(OMX.rk.video_decoder.m4v) in android.hardwar process
08-17 06:45:37.731   331   331 W HwBinder:331_4: type=1400 audit(0.0:34): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.731   331   331 I chatty  : uid=1046(mediacodec) omx@1.0-service identical 1 line
08-17 06:45:37.731   331   331 W HwBinder:331_4: type=1400 audit(0.0:36): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.731   331   713 E OMXNodeInstance: getExtensionIndex(0xecc5a060:rk._decoder.m4v, OMX.google.android.index.configureVideoTunnelMode) ERROR: BadParameter(0x80001005)
08-17 06:45:37.731   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.731   331   713 E libc    : Access denied finding property "vpu_mem_debug"
08-17 06:45:37.731   331   713 E libc    : Access denied finding property "mpp_buffer_debug"
08-17 06:45:37.731   331   713 E libc    : Access denied finding property "drm_debug"
08-17 06:45:37.731   331   713 W OMXNodeInstance: [0xecc5a060:rk._decoder.m4v] component does not support metadata mode; using fallback
08-17 06:45:37.734   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.735   331   713 I OMXMaster: makeComponentInstance(OMX.rk.video_decoder.vp8) in android.hardwar process
08-17 06:45:37.737   331   331 W HwBinder:331_4: type=1400 audit(0.0:37): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.737   331   713 E OMXNodeInstance: getExtensionIndex(0xeeb20260:rk._decoder.vp8, OMX.google.android.index.configureVideoTunnelMode) ERROR: BadParameter(0x80001005)
08-17 06:45:37.738   331   331 W HwBinder:331_4: type=1400 audit(0.0:38): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.738   331   331 W HwBinder:331_4: type=1400 audit(0.0:39): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.738   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.738   331   713 E libc    : Access denied finding property "vpu_mem_debug"
08-17 06:45:37.738   331   713 E libc    : Access denied finding property "mpp_buffer_debug"
08-17 06:45:37.738   331   713 E libc    : Access denied finding property "drm_debug"
08-17 06:45:37.738   331   713 W OMXNodeInstance: [0xeeb20260:rk._decoder.vp8] component does not support metadata mode; using fallback
08-17 06:45:37.738   429   429 I ActivityTaskManager: Loaded persisted task ids for user 0
08-17 06:45:37.741   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.742   331   713 I OMXMaster: makeComponentInstance(OMX.google.vp8.decoder) in android.hardwar process
08-17 06:45:37.744   429   429 I ActivityTaskManager: getPackageFerformanceMode--ComponentInfo{com.android.settings/com.android.settings.FallbackHome}----com.android.settings
08-17 06:45:37.754   331   331 E OMXNodeInstance: getExtensionIndex(0xeeb1fe40:google.vp8.decoder, OMX.google.android.index.configureVideoTunnelMode) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.754   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.754   331   331 E OMXNodeInstance: getExtensionIndex(0xeeb1fe40:google.vp8.decoder, OMX.google.android.index.enableAndroidNativeBuffers) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.756   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.756   331   331 I OMXMaster: makeComponentInstance(OMX.rk.video_decoder.vp9) in android.hardwar process
08-17 06:45:37.758   331   331 W HwBinder:331_3: type=1400 audit(0.0:40): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.759   331   331 W HwBinder:331_3: type=1400 audit(0.0:41): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.759   331   331 W HwBinder:331_3: type=1400 audit(0.0:42): avc: denied { read } for name="u:object_r:default_prop:s0" dev="tmpfs" ino=11605 scontext=u:r:mediacodec:s0 tcontext=u:object_
r:default_prop:s0 tclass=file permissive=0
08-17 06:45:37.759   331   712 E OMXNodeInstance: getExtensionIndex(0xeeb1fe40:rk._decoder.vp9, OMX.google.android.index.configureVideoTunnelMode) ERROR: BadParameter(0x80001005)
08-17 06:45:37.759   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.759   331   712 E libc    : Access denied finding property "vpu_mem_debug"
08-17 06:45:37.759   331   712 E libc    : Access denied finding property "mpp_buffer_debug"
08-17 06:45:37.759   331   712 E libc    : Access denied finding property "drm_debug"
08-17 06:45:37.759   331   712 W OMXNodeInstance: [0xeeb1fe40:rk._decoder.vp9] component does not support metadata mode; using fallback
08-17 06:45:37.762   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.762   331   331 I OMXMaster: makeComponentInstance(OMX.google.vp9.decoder) in android.hardwar process
08-17 06:45:37.764   331   712 E OMXNodeInstance: getExtensionIndex(0xeeb20260:google.vp9.decoder, OMX.google.android.index.configureVideoTunnelMode) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.764   327   400 D MediaCodecInfo: detail feature-tunneled-playback wasn't present to remove
08-17 06:45:37.764   331   712 E OMXNodeInstance: getExtensionIndex(0xeeb20260:google.vp9.decoder, OMX.google.android.index.enableAndroidNativeBuffers) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.766   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.767   331   712 I OMXMaster: makeComponentInstance(OMX.rk.video_encoder.avc) in android.hardwar process
08-17 06:45:37.772   327   400 W ACodec  : [OMX.rk.video_encoder.avc] stopping checking profiles after 32: 8/1
08-17 06:45:37.773   327   400 W OMXUtils: do not know color format 0x7f000789 = 2130708361
08-17 06:45:37.773   331   331 E OMXNodeInstance: getConfig(0xeeb20260:rk._encoder.avc, ConfigAndroidIntraRefresh(0x6f60000a)) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.775   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.776   331   331 I OMXMaster: makeComponentInstance(OMX.google.h264.encoder) in android.hardwar process
08-17 06:45:37.780   327   400 W OMXUtils: do not know color format 0x7f000789 = 2130708361
08-17 06:45:37.783   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.783   331   713 I OMXMaster: makeComponentInstance(OMX.google.h263.encoder) in android.hardwar process
08-17 06:45:37.787   331   713 I SoftMPEG4Encoder: Construct SoftMPEG4Encoder
08-17 06:45:37.789   327   400 W OMXUtils: do not know color format 0x7f000789 = 2130708361
08-17 06:45:37.789   331   712 E OMXNodeInstance: getConfig(0xeeb1fcc0:google.h263.encoder, ConfigAndroidIntraRefresh(0x6f60000a)) ERROR: Undefined(0x80001001)
08-17 06:45:37.790   331   712 E OMXNodeInstance: getParameter(0xeeb1fcc0:google.h263.encoder, ParamVideoIntraRefresh(0x6000006)) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.790   327   400 D MediaCodecInfo: detail feature-frame-parsing wasn't present to remove
08-17 06:45:37.795   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.795   331   331 I OMXMaster: makeComponentInstance(OMX.google.mpeg4.encoder) in android.hardwar process
08-17 06:45:37.796   331   331 I SoftMPEG4Encoder: Construct SoftMPEG4Encoder
08-17 06:45:37.797   327   400 W OMXUtils: do not know color format 0x7f000789 = 2130708361
08-17 06:45:37.797   331   331 E OMXNodeInstance: getConfig(0xecc5a000:google.mpeg4.encoder, ConfigAndroidIntraRefresh(0x6f60000a)) ERROR: Undefined(0x80001001)
08-17 06:45:37.798   331   331 E OMXNodeInstance: getParameter(0xecc5a000:google.mpeg4.encoder, ParamVideoIntraRefresh(0x6000006)) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.798   327   400 D MediaCodecInfo: detail feature-frame-parsing wasn't present to remove
08-17 06:45:37.799   327   400 I OMXClient: IOmx service obtained
08-17 06:45:37.800   331   712 I OMXMaster: makeComponentInstance(OMX.google.vp8.encoder) in android.hardwar process
08-17 06:45:37.803   327   400 W OMXUtils: do not know color format 0x7f000789 = 2130708361
08-17 06:45:37.804   331   331 E OMXNodeInstance: getConfig(0xeeb1fcc0:google.vp8.encoder, ConfigAndroidIntraRefresh(0x6f60000a)) ERROR: Undefined(0x80001001)
08-17 06:45:37.804   331   331 E OMXNodeInstance: getParameter(0xeeb1fcc0:google.vp8.encoder, ParamVideoIntraRefresh(0x6000006)) ERROR: UnsupportedIndex(0x8000101a)
08-17 06:45:37.804   327   400 D MediaCodecInfo: detail feature-frame-parsing wasn't present to remove
08-17 06:45:37.808   327   400 I Codec2Client: Available Codec2 services: "software"
08-17 06:45:37.808   327   400 I Codec2Client: Creating a Codec2 client to service "software"
08-17 06:45:37.809   327   400 I Codec2Client: Client to Codec2 service "software" created
08-17 06:45:37.810   338   392 V C2Store : in init
08-17 06:45:37.811   338   392 V C2Store : loading dll
08-17 06:45:37.821   429   429 I ActivityTaskManager: getPackageFerformanceMode--ComponentInfo{com.android.settings/com.android.settings.FallbackHome}----com.android.settings
08-17 06:45:37.822   429   429 D SystemServerTiming: ActivityManagerStartApps took to complete: 283ms
08-17 06:45:37.822   429   429 D SystemServerTiming: PhaseActivityManagerReady took to complete: 531ms
08-17 06:45:37.822   429   450 W system_server: Long monitor contention with owner main (429) at void com.android.server.am.ActivityManagerService.systemReady(java.lang.Runnable, android.util.TimingsT
raceLog)(ActivityManagerService.java:9163) waiters=0 in void com.android.server.am.ActivityManagerService.dispatchUidsChanged() for 274ms
08-17 06:45:37.822   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.823   338   392 V C2Store : unloading dll
08-17 06:45:37.823   338   392 V C2Store : in init
08-17 06:45:37.823   338   392 V C2Store : loading dll
08-17 06:45:37.824   429   502 W system_server: Long monitor contention with owner main (429) at void com.android.server.am.ActivityManagerService.systemReady(java.lang.Runnable, android.util.TimingsT
raceLog)(ActivityManagerService.java:9163) waiters=1 in void com.android.server.am.ActivityManagerService.attachApplication(android.app.IApplicationThread, long) for 270ms
08-17 06:45:37.824   429   446 W system_server: Long monitor contention with owner main (429) at void com.android.server.am.ActivityManagerService.systemReady(java.lang.Runnable, android.util.TimingsT
raceLog)(ActivityManagerService.java:9163) waiters=2 in void com.android.server.am.ActivityManagerService.attachApplication(android.app.IApplicationThread, long) for 261ms
08-17 06:45:37.824   429   450 W Looper  : Slow dispatch took 276ms android.ui h=com.android.server.am.ActivityManagerService$UiHandler c=null m=53
08-17 06:45:37.824   429   459 W system_server: Long monitor contention with owner main (429) at void com.android.server.am.ActivityManagerService.systemReady(java.lang.Runnable, android.util.TimingsT
raceLog)(ActivityManagerService.java:9163) waiters=3 in void com.android.server.am.ProcessList.lambda$startProcessLocked$0$ProcessList(com.android.server.am.ProcessRecord, java.lang.String, int[], int
, int, java.lang.String, java.lang.String, java.lang.String, long) for 258ms
08-17 06:45:37.825   429   429 D SystemServerInitThreadPool: Shutdown successful
08-17 06:45:37.825   429   429 D SystemServerTiming: StartServices took to complete: 2607ms
08-17 06:45:37.830   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.830   338   392 V C2Store : unloading dll
08-17 06:45:37.830   338   392 V C2Store : in init
08-17 06:45:37.830   338   392 V C2Store : loading dll
08-17 06:45:37.832   429   447 W system_server: Long monitor contention with owner main (429) at void com.android.server.am.ActivityManagerService.systemReady(java.lang.Runnable, android.util.TimingsT
raceLog)(ActivityManagerService.java:9163) waiters=4 in void com.android.server.am.ActivityManagerService.attachApplication(android.app.IApplicationThread, long) for 248ms
08-17 06:45:37.833   429   699 W system_server: Long monitor contention with owner main (429) at void com.android.server.am.ActivityManagerService.systemReady(java.lang.Runnable, android.util.TimingsT
raceLog)(ActivityManagerService.java:9163) waiters=5 in android.content.Intent com.android.server.am.ActivityManagerService.registerReceiver(android.app.IApplicationThread, java.lang.String, android.c
ontent.IIntentReceiver, android.content.IntentFilter, java.lang.String, int, int) for 241ms
08-17 06:45:37.833   429   447 W ActivityManager: Slow operation: 285ms so far, now at startProcess: done updating battery stats
08-17 06:45:37.833   429   447 W ActivityManager: Slow operation: 285ms so far, now at startProcess: building log message
08-17 06:45:37.833   429   447 I ActivityManager: Start proc 673:com.android.phone/1001 for added application com.android.phone
08-17 06:45:37.833   429   447 W ActivityManager: Slow operation: 285ms so far, now at startProcess: starting to update pids map
08-17 06:45:37.833   429   447 W ActivityManager: Slow operation: 285ms so far, now at startProcess: done updating pids map
08-17 06:45:37.834   627   627 V WebViewLibraryLoader: RelroFileCreator (64bit = false), package: com.android.webview library: libwebviewchromium.so
08-17 06:45:37.836   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.837   338   392 V C2Store : unloading dll
08-17 06:45:37.837   338   392 V C2Store : in init
08-17 06:45:37.837   338   392 V C2Store : loading dll
08-17 06:45:37.837   595   595 W AlarmManager: Unrecognized alarm listener com.android.systemui.keyguard.-$$Lambda$KeyguardSliceProvider$IhzByd8TsqFuOrSyuGurVskyPLo@90d9e4e
08-17 06:45:37.843   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.843   338   392 V C2Store : unloading dll
08-17 06:45:37.843   338   392 V C2Store : in init
08-17 06:45:37.843   338   392 V C2Store : loading dll
08-17 06:45:37.847   647   647 V WebViewLibraryLoader: RelroFileCreator (64bit = true), package: com.android.webview library: libwebviewchromium.so
08-17 06:45:37.849   573   573 D AdapterState: make() - Creating AdapterState
08-17 06:45:37.849   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.849   338   392 V C2Store : unloading dll
08-17 06:45:37.849   338   392 V C2Store : in init
08-17 06:45:37.849   338   392 V C2Store : loading dll
08-17 06:45:37.856   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.856   338   392 V C2Store : unloading dll
08-17 06:45:37.856   338   392 V C2Store : in init
08-17 06:45:37.856   338   392 V C2Store : loading dll
08-17 06:45:37.856   429   429 W Looper  : Slow delivery took 1556ms main h=android.app.ActivityThread$H c=null m=156
08-17 06:45:37.857   573   763 I AdapterState: OFF : entered
08-17 06:45:37.859   573   763 D AdapterProperties: Setting state to OFF
08-17 06:45:37.860   429   429 D HdmiReceiver: action =android.intent.action.HDMI_PLUGGED
08-17 06:45:37.860   429   429 D HdmiReceiver: onReceive mTaskVector.size() = 0
08-17 06:45:37.861   627   627 I WebViewLoader-: The ClassLoaderContext is a special shared library.
08-17 06:45:37.862   243   243 D Zygote  : Forked child process 764
08-17 06:45:37.863   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.863   338   392 V C2Store : unloading dll
08-17 06:45:37.863   338   392 V C2Store : in init
08-17 06:45:37.863   338   392 V C2Store : loading dll
08-17 06:45:37.864   673   673 I m.android.phon: The ClassLoaderContext is a special shared library.
08-17 06:45:37.865   429   429 D ConditionProviders.SCP: onConnected
08-17 06:45:37.865   573   573 I bt_btif : init: start restricted = 0 ; niap = 0
08-17 06:45:37.865   429   459 I ActivityManager: Start proc 764:com.android.settings/1000 for activity {com.android.settings/com.android.settings.FallbackHome}
08-17 06:45:37.866   429   429 D ConditionProviders: Subscribing to condition://android/event?userId=-10000&calendar=&reply=1 with ComponentInfo{android/com.android.server.notification.EventConditionP
rovider}
08-17 06:45:37.866   429   429 D ConditionProviders: Subscribing to condition://android/schedule?days=1.2.3.4.5.6.7&start=22.0&end=7.0&exitAtAlarm=true with ComponentInfo{android/com.android.server.no
tification.ScheduleConditionProvider}
08-17 06:45:37.867   573   573 D bt_osi_allocation_tracker: canary initialized
08-17 06:45:37.867   647   647 I WebViewLoader-: The ClassLoaderContext is a special shared library.
08-17 06:45:37.870   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.870   338   392 V C2Store : unloading dll
08-17 06:45:37.870   338   392 V C2Store : in init
08-17 06:45:37.870   338   392 V C2Store : loading dll
08-17 06:45:37.873   573   770 I         : [0817/064537.872973:INFO:message_loop_thread.cc(175)] Run: message loop starting for thread bt_stack_manager_thread
08-17 06:45:37.873   429   429 V SettingsProvider: Notifying for 0: content://settings/secure/location_mode
08-17 06:45:37.874   429   429 V SettingsProvider: Notifying for 0: content://settings/global/location_global_kill_switch
08-17 06:45:37.881   573   770 I bt_stack_manager: event_init_stack is initializing the stack
08-17 06:45:37.881   338   392 I /apex/com.android.media.swcodec/bin/mediaswcodec: missing struct descriptor #Param::CoreIndex(--004) for field values of struct #Param::CoreIndex(F-12004)
08-17 06:45:37.881   573   770 I         : [0817/064537.881470:INFO:btif_config.cc(756)] hash_file: Disabled for multi-user
08-17 06:45:37.881   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.881   338   392 V C2Store : unloading dll
08-17 06:45:37.881   338   392 V C2Store : in init
08-17 06:45:37.881   338   392 V C2Store : loading dll
08-17 06:45:37.882   573   770 I         : [0817/064537.882251:INFO:btif_config.cc(784)] read_checksum_file: Disabled for multi-user
08-17 06:45:37.885   573   770 E bt_btif_config: Config is missing adapter section
08-17 06:45:37.885   573   770 W bt_btif_config: init unable to load config file: /data/misc/bluedroid/bt_config.conf; using backup.
08-17 06:45:37.885   573   770 I         : [0817/064537.885926:INFO:btif_config.cc(756)] hash_file: Disabled for multi-user
08-17 06:45:37.885   573   770 I         : [0817/064537.885983:INFO:btif_config.cc(784)] read_checksum_file: Disabled for multi-user
08-17 06:45:37.888   573   770 E bt_btif_config: Config is missing adapter section
08-17 06:45:37.888   573   770 W bt_btif_config: init unable to load backup; attempting to transcode legacy file.
08-17 06:45:37.888   573   770 E bt_btif_config_transcode: btif_config_transcode unable to load XML file '/data/misc/bluedroid/bt_config.xml': 3
08-17 06:45:37.888   573   770 E bt_btif_config: init unable to transcode legacy file; creating empty config.
08-17 06:45:37.888   573   770 W         : [0817/064537.888714:WARNING:btif_config.cc(164)] read_or_set_metrics_salt: Failed to read metrics salt from config
08-17 06:45:37.888   573   770 I         : [0817/064537.888771:INFO:btif_config.cc(175)] read_or_set_metrics_salt: Metrics salt is not invalid, creating new one
08-17 06:45:37.891   573   785 I bt_osi_thread: run_thread: thread id 785, thread name alarm_default_ca started
08-17 06:45:37.892   573   788 I bt_osi_thread: run_thread: thread id 788, thread name alarm_dispatcher started
08-17 06:45:37.893   573   770 I bt_btif_core: btif_init_bluetooth entered
08-17 06:45:37.894   573   770 I bt_stack_config: init attempt to load stack conf from /etc/bluetooth/bt_stack.conf
08-17 06:45:37.913   573   791 I         : [0817/064537.913711:INFO:message_loop_thread.cc(175)] Run: message loop starting for thread bt_jni_thread
08-17 06:45:37.914   573   770 I bt_btif_core: btif_init_bluetooth finished
08-17 06:45:37.914   573   770 I bt_stack_manager: event_init_stack finished
08-17 06:45:37.914   573   573 I bt_osi_wakelock: wakelock_set_os_callouts set to non-native
08-17 06:45:37.914   573   573 I bt_btif : get_profile_interface: id = socket
08-17 06:45:37.915   573   791 E bt_btif_storage: btif_storage_get_adapter_property: Controller not ready! Unable to return Bluetooth Address
08-17 06:45:37.915   573   791 E BluetoothServiceJni: adapter_properties_callback: Status 1 is incorrect
08-17 06:45:37.915   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.915   338   392 V C2Store : unloading dll
08-17 06:45:37.916   338   392 V C2Store : in init
08-17 06:45:37.916   338   392 V C2Store : loading dll
08-17 06:45:37.917   573   791 D AdapterProperties: Name is: rk3399
08-17 06:45:37.917   573   791 D AdapterProperties: BT Class:1a0110
08-17 06:45:37.920   764   764 I ndroid.setting: The ClassLoaderContext is a special shared library.
08-17 06:45:37.921   429   429 I system_server: The ClassLoaderContext is a special shared library.
08-17 06:45:37.940   573   573 I bt_btif : get_profile_interface: id = sdp
08-17 06:45:37.943   573   573 I BluetoothAdapterService: Phone policy enabled
08-17 06:45:37.945   573   573 D BluetoothActiveDeviceManager: start()
08-17 06:45:37.951   573   792 D BluetoothActiveDeviceManager: onAudioDevicesAdded
08-17 06:45:37.951   573   792 D BluetoothActiveDeviceManager: Audio device added: rk3399-Android10 type: 2
08-17 06:45:37.951   573   792 D BluetoothActiveDeviceManager: Audio device added: rk3399-Android10 type: 15
08-17 06:45:37.951   573   792 D BluetoothActiveDeviceManager: Audio device added: rk3399-Android10 type: 9
08-17 06:45:37.960   429   545 D RkNativeDisplayManager: nativeInit failed to get IRkOutputManager
08-17 06:45:37.962   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.962   338   392 V C2Store : unloading dll
08-17 06:45:37.962   338   392 V C2Store : in init
08-17 06:45:37.962   338   392 V C2Store : loading dll
08-17 06:45:37.963   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_colorimetry property
08-17 06:45:37.963   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_format property
08-17 06:45:37.964   268   301 D hw_output: old_state 1 cur_state 1 conn->get_type() 14
08-17 06:45:37.964   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_colorimetry property
08-17 06:45:37.964   268   301 W hwc-drm-connector: UpdateModes Could not get hdmi_output_format property
08-17 06:45:37.964   268   301 D hw_output: old_state 2 cur_state 2 conn->get_type() 10
08-17 06:45:37.964   268   301 D hw_output: old_state 2 cur_state 2 conn->get_type() 11
08-17 06:45:37.976   573   573 D BluetoothDatabase: start()
08-17 06:45:37.978   573   573 D BluetoothDatabase: Load Database
08-17 06:45:37.980   573   573 D BluetoothAdapterService: setAdapterService() - trying to set service to com.android.bluetooth.btservice.AdapterService@ba9515a
08-17 06:45:37.982   338   392 V C2Store : in ~ComponentModule
08-17 06:45:37.982   338   392 V C2Store : unloading dll
08-17 06:45:37.983   338   392 V C2Store : in init
08-17 06:45:37.983   338   392 V C2Store : loading dll
08-17 06:45:37.994   573   573 D BluetoothAdapterService: onBind()
08-17 06:45:38.002   595   595 V SystemUIService: SystemUIApplication created.
08-17 06:45:38.011   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.011   338   392 V C2Store : unloading dll
08-17 06:45:38.011   338   392 V C2Store : in init
08-17 06:45:38.011   338   392 V C2Store : loading dll
08-17 06:45:38.031   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.031   338   392 V C2Store : unloading dll
08-17 06:45:38.031   338   392 V C2Store : in init
08-17 06:45:38.031   338   392 V C2Store : loading dll
08-17 06:45:38.031   573   795 I BluetoothDatabase: cacheMetadata
08-17 06:45:38.042   627   627 I WebViewLoader-: System.exit called, status: 0
08-17 06:45:38.042   627   627 I AndroidRuntime: VM exiting with result code 0, cleanup skipped.
08-17 06:45:38.055   429   699 I ActivityManager: Process WebViewLoader-armeabi-v7a (pid 627) has died: psvc PER
08-17 06:45:38.055   244   244 I Zygote  : Process 627 exited cleanly (0)
08-17 06:45:38.056   429   460 I libprocessgroup: Successfully killed process cgroup uid 1037 pid 627 in 0ms
08-17 06:45:38.059   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.059   338   392 V C2Store : unloading dll
08-17 06:45:38.059   338   392 V C2Store : in init
08-17 06:45:38.059   338   392 V C2Store : loading dll
08-17 06:45:38.079   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.079   338   392 V C2Store : unloading dll
08-17 06:45:38.079   338   392 V C2Store : in init
08-17 06:45:38.079   338   392 V C2Store : loading dll
08-17 06:45:38.090   429   429 W Looper  : Slow dispatch took 215ms main h=android.app.ActivityThread$H c=null m=114
08-17 06:45:38.091   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.091   338   392 V C2Store : unloading dll
08-17 06:45:38.091   338   392 V C2Store : in init
08-17 06:45:38.091   338   392 V C2Store : loading dll
08-17 06:45:38.092   595   595 D SystemUIBootTiming: DependencyInjection took to complete: 90ms
08-17 06:45:38.103   595   595 V SystemUIService: Starting SystemUI services for user 0.
08-17 06:45:38.107   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.util.NotificationChannels took to complete: 4ms
08-17 06:45:38.108   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.statusbar.CommandQueue$CommandQueueStart took to complete: 0ms
08-17 06:45:38.136   338   392 D C2SoftHevcEnc: Given level 6000 does not cover current configuration: adjusting to 6001
08-17 06:45:38.137   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.137   338   392 V C2Store : unloading dll
08-17 06:45:38.137   338   392 V C2Store : in init
08-17 06:45:38.137   338   392 V C2Store : loading dll
08-17 06:45:38.147   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.147   338   392 V C2Store : unloading dll
08-17 06:45:38.147   338   392 V C2Store : in init
08-17 06:45:38.147   338   392 V C2Store : loading dll
08-17 06:45:38.156   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.156   338   392 V C2Store : unloading dll
08-17 06:45:38.156   338   392 V C2Store : in init
08-17 06:45:38.156   338   392 V C2Store : loading dll
08-17 06:45:38.172   429   429 D BluetoothManagerService: Trying to bind to profile: 1, while Bluetooth was disabled
08-17 06:45:38.173   429   805 I Telecom : BluetoothRouteManager: getBluetoothAudioConnectedDevice: no service available.
08-17 06:45:38.176   429   429 I Telecom : SystemStateHelper: Registering car mode receiver: android.content.IntentFilter@2a49a6f: TS.init@AAA
08-17 06:45:38.180   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.180   338   392 V C2Store : unloading dll
08-17 06:45:38.180   338   392 V C2Store : in init
08-17 06:45:38.180   338   392 V C2Store : loading dll
08-17 06:45:38.188   647   647 I WebViewLoader-: System.exit called, status: 0
08-17 06:45:38.188   647   647 I AndroidRuntime: VM exiting with result code 0, cleanup skipped.
08-17 06:45:38.190   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.190   338   392 V C2Store : unloading dll
08-17 06:45:38.191   338   392 V C2Store : in init
08-17 06:45:38.191   338   392 V C2Store : loading dll
08-17 06:45:38.193   244   244 D Zygote  : Forked child process 810
08-17 06:45:38.199   429   620 W ZygoteProcess: Got error connecting to zygote, retrying. msg= Connection refused
08-17 06:45:38.205   595   595 V MediaRouter: Selecting route: RouteInfo{ name=Tablet, description=null, status=null, category=RouteCategory{ name=System types=ROUTE_TYPE_LIVE_AUDIO ROUTE_TYPE_LIVE_VI
DEO  groupable=false }, supportedTypes=ROUTE_TYPE_LIVE_AUDIO ROUTE_TYPE_LIVE_VIDEO , presentationDisplay=null }
08-17 06:45:38.206   429   698 I ActivityManager: Process WebViewLoader-arm64-v8a (pid 647) has died: psvc PER
08-17 06:45:38.209   243   243 I Zygote  : Process 647 exited cleanly (0)
08-17 06:45:38.210   673   673 D CarrierProvider: onCreate
08-17 06:45:38.210   429   812 I Telecom : Logging.Events: Non-call EVENT: AUDIO_ROUTE, Entering state QuiescentSpeakerRoute
08-17 06:45:38.211   429   812 I Telecom : BluetoothRouteManager: getBluetoothAudioConnectedDevice: no service available.
08-17 06:45:38.214   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.214   338   392 V C2Store : unloading dll
08-17 06:45:38.214   338   392 V C2Store : in init
08-17 06:45:38.214   338   392 V C2Store : loading dll
08-17 06:45:38.215   810   810 I WebViewZygoteInit: Starting WebViewZygoteInit
08-17 06:45:38.217   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.217   338   392 V C2Store : unloading dll
08-17 06:45:38.217   338   392 V C2Store : in init
08-17 06:45:38.217   338   392 V C2Store : loading dll
08-17 06:45:38.221   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.221   338   392 V C2Store : unloading dll
08-17 06:45:38.221   338   392 V C2Store : in init
08-17 06:45:38.221   338   392 V C2Store : loading dll
08-17 06:45:38.227   673   673 D CarrierIdProvider: onCreate
08-17 06:45:38.227   429   826 I Telecom : CallAudioModeStateMachine: Message received: null.: TS.init->CAMSM.pM_1@AAA
08-17 06:45:38.227   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.227   338   392 V C2Store : unloading dll
08-17 06:45:38.227   338   392 V C2Store : in init
08-17 06:45:38.227   338   392 V C2Store : loading dll
08-17 06:45:38.228   673   673 D CarrierIdDatabaseHelper: CarrierIdDatabaseHelper: 5
08-17 06:45:38.233   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.233   338   392 V C2Store : unloading dll
08-17 06:45:38.233   338   392 V C2Store : in init
08-17 06:45:38.233   338   392 V C2Store : loading dll
08-17 06:45:38.233   429   429 I Telecom : MissedCallNotifierImpl: reloadFromDatabase: Boot not yet complete -- call log db may not be available. Deferring loading until boot complete for user 0: TS.i
nit@AAA
08-17 06:45:38.236   338   392 I C2SoftVp8Enc: setting temporal layering 0 + 0
08-17 06:45:38.236   429   429 D BluetoothManagerService: Trying to bind to profile: 1, while Bluetooth was disabled
08-17 06:45:38.237   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.237   338   392 V C2Store : unloading dll
08-17 06:45:38.238   338   392 V C2Store : in init
08-17 06:45:38.238   338   392 V C2Store : loading dll
08-17 06:45:38.238   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.keyguard.KeyguardViewMediator took to complete: 130ms
08-17 06:45:38.242   429   429 I Telecom : Class: TelecomSystem.INSTANCE being set
08-17 06:45:38.245   429   429 W ContextImpl: Calling a method in the system process without a qualified user: android.app.ContextImpl.startService:1570 android.content.ContextWrapper.startService:669
 com.android.server.telecom.components.TelecomService.initializeTelecomSystem:196 com.android.server.telecom.components.TelecomService.onBind:71 android.app.ActivityThread.handleBindService:3980
08-17 06:45:38.247   429   429 W Looper  : Slow dispatch took 156ms main h=android.app.ActivityThread$H c=null m=121
08-17 06:45:38.248   429   429 D PackageWatchdog: Getting all observed packages pending health checks
08-17 06:45:38.248   429   429 I PackageWatchdog: Syncing health check requests for packages: {}
08-17 06:45:38.248   429   429 I ExplicitHealthCheckController: Service not ready to get health check supported packages. Binding...
08-17 06:45:38.249   673   673 D CarrierIdProvider: update database from pb file
08-17 06:45:38.249   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.250   338   392 V C2Store : unloading dll
08-17 06:45:38.250   338   392 V C2Store : in init
08-17 06:45:38.250   338   392 V C2Store : loading dll
08-17 06:45:38.251   429   460 I libprocessgroup: Successfully killed process cgroup uid 1037 pid 647 in 44ms
08-17 06:45:38.252   429   429 I ExplicitHealthCheckController: Explicit health check service is bound
08-17 06:45:38.253   338   392 I C2SoftVp9Enc: setting temporal layering 0 + 0
08-17 06:45:38.254   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.254   338   392 V C2Store : unloading dll
08-17 06:45:38.255   327   400 D MediaCodecsXmlParser: parsing /apex/com.android.media.swcodec/etc/media_codecs.xml...
08-17 06:45:38.255   429   429 V SettingsProvider: Notifying for 0: content://settings/global/boot_count
08-17 06:45:38.255   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.recents.Recents took to complete: 17ms
08-17 06:45:38.256   429   429 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:38.256   429   429 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:38.256   429   429 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:38.256   595   595 I vol.Events: writeEvent collection_started
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 8000-320000
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 7350,8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:38.257   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-48000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-48000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 32000-500000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 48000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 6000-510000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.258   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 1-655350
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-21000000
08-17 06:45:38.259   327   400 D MediaCodecsXmlParser: disabling c2.android.gsm.decoder
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 13000
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-352x288
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 12-11880
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-384000
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-352x288
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.259   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-384000
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-4080x4080
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-32768
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-1966080
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-48000000
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-2048x2048
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-16384
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-491520
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: block-size = 8x8
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-4096x4096
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-196608
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-2000000
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-2048x2048
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-65536
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-491520
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-5000000
08-17 06:45:38.260   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-2048x2048
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-16384
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-1000000
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-8192
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-1000000
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-2048x2048
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-16384
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-500000
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x1280
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-3600
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-108000
08-17 06:45:38.261   243   243 D Zygote  : Forked child process 838
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-5000000
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.261   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1920x1080
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-16384
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-2073600
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-120000000
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.262   327   400 D MediaCodecsXmlParser: disabling c2.android.mpeg2.decoder
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: size-range = 16x16-1920x1088
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-20000000
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 6
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:38.262   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 1-655350
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-21000000
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: complexity-default = 5
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: complexity-range = 0-8
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CQ
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,12000,16000,24000,48000
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 500-512000
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: complexity-default = 5
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: complexity-range = 0-10
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-176x144
08-17 06:45:38.263   429   459 I ActivityManager: Start proc 838:com.android.launcher3/u0a78 for service {com.android.launcher3/com.android.quickstep.TouchInteractionService}
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-128000
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: size-range = 16x16-176x144
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.263   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 12-1485
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-64000
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: size-range = 16x16-2048x2048
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-8192
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-245760
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-12000000
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: size-range = 16x16-1808x1808
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-1620
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-40500
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-2000000
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: feature-intra-refresh = 0
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-2048x2048
08-17 06:45:38.264   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-16384
08-17 06:45:38.265   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.265   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x1280
08-17 06:45:38.265   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-3600
08-17 06:45:38.265   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-20000000
08-17 06:45:38.265   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:38.266   673   673 E CarrierIdProvider: read carrier list from ota pb failure: java.io.FileNotFoundException: /data/misc/carrierid/carrier_list.pb: open failed: ENOENT (No such file or dir
ectory)
08-17 06:45:38.266   673   673 D CarrierIdProvider: latest version: 16777232 need update: false
08-17 06:45:38.267   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-512x512
08-17 06:45:38.267   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.267   327   400 I MediaCodecsXmlParser: limit: block-size = 8x8
08-17 06:45:38.267   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-4096
08-17 06:45:38.268   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-122880
08-17 06:45:38.268   327   400 I MediaCodecsXmlParser: limit: frame-rate-range = 1-120
08-17 06:45:38.268   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.268   327   400 I MediaCodecsXmlParser: limit: complexity-default = 0
08-17 06:45:38.268   327   400 I MediaCodecsXmlParser: limit: complexity-range = 0-10
08-17 06:45:38.270   327   400 I MediaCodecsXmlParser: limit: quality-scale = linear
08-17 06:45:38.270   327   400 I MediaCodecsXmlParser: limit: quality-default = 80
08-17 06:45:38.270   327   400 I MediaCodecsXmlParser: limit: quality-range = 0-100
08-17 06:45:38.270   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR,CQ
08-17 06:45:38.271   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-2048x2048
08-17 06:45:38.271   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.271   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.271   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-3600
08-17 06:45:38.271   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.271   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:38.271   327   400 D MediaCodecsXmlParser: Cannot find
08-17 06:45:38.271   327   400 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_c2.xml...
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: Setting: updating existing setting at line 20 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: Setting: updating existing setting at line 21 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 24 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 30 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 36 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 42 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 48 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 54 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.273   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 60 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.274   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 66 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.274   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 72 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.274   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 78 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.274   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 84 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.274   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 90 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.274   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 100 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-3600
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-108000
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.274   327   400 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-65536
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-5000000
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-8192
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-3600
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-108000
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-5000000
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1920x1080
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-16384
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-2073600
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-120000000
08-17 06:45:38.275   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 160 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 172 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 179 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 186 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 193 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 201 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 208 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.276   327   400 D MediaCodecsXmlParser: MediaCodec: cannot add existing codec at line 215 of /vendor/etc/media_codecs_c2.xml
08-17 06:45:38.277   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.277   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.277   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1280x720
08-17 06:45:38.280   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-1620
08-17 06:45:38.280   429   429 I system_server: Waiting for a blocking GC ClassLinker
08-17 06:45:38.280   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-40500
08-17 06:45:38.280   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-2000000
08-17 06:45:38.280   327   400 I MediaCodecsXmlParser: limit: feature-intra-refresh = 0
08-17 06:45:38.280   327   400 D MediaCodecsXmlParser: disabling c2.android.vp8.encoder
08-17 06:45:38.280   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.280   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-3600
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-4000000
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:38.281   327   400 D MediaCodecsXmlParser: disabling c2.android.hevc.encoder
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-512x512
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: block-size = 8x8
08-17 06:45:38.281   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-4096
08-17 06:45:38.281   243   243 D Zygote  : Forked child process 849
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-122880
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: frame-rate-range = 1-120
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: complexity-default = 0
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: complexity-range = 0-10
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: quality-scale = linear
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: quality-default = 80
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: quality-range = 0-100
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR,CQ
08-17 06:45:38.283   327   400 D MediaCodecsXmlParser: disabling c2.android.vp9.encoder
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-2048x2048
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: block-count-range = 1-3600
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.283   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:38.284   327   400 D MediaCodecsXmlParser: Cannot find
08-17 06:45:38.284   327   400 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs.xml...
08-17 06:45:38.284   327   400 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_google_audio.xml...
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:38.285   429   459 I ActivityManager: Start proc 849:android.ext.services/u0a34 for service {android.ext.services/android.ext.services.watchdog.ExplicitHealthCheckServiceImpl}
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 8000-320000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 7350,8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:38.285   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 64000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 32000-500000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 48000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 6000-510000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 8
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000-96000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.288   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 6
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000,11025,12000,16000,22050,24000,32000,44100,48000
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 8000-960000
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 8000
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 4750-12200
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 1
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 16000
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 6600-23850
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CBR
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: max-channel-count = 2
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: sample-rate-ranges = 1-655350
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-21000000
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: complexity-default = 5
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: complexity-range = 0-8
08-17 06:45:38.289   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = CQ
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: size-range = 96x96-4096x2160
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-489600
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 30-30
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: size-range = 182x144-1920x1088
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: block-size = 16x8
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.290   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.291   764   820 I mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 876; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:38.291   764   820 I mali_so : arm_release_ver of this mali_so is 'r18p0-01rel0', rk_so_ver is '17@0'.
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.291   764   820 D mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 881; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:38.291   764   820 D mali_so : current process is NOT sf, to bail out.
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.291   327   400 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 60-60
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: size-range = 400x400-4096x2160
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 60-60
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: size-range = 96x96-4096x2160
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-972000
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-300000000
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 6
08-17 06:45:38.292   327   400 I MediaCodecsXmlParser: limit: performance-point-3840x2160-range = 60-60
08-17 06:45:38.293   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1920x1088
08-17 06:45:38.293   327   400 I MediaCodecsXmlParser: limit: alignment = 16x8
08-17 06:45:38.293   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.293   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:38.293   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 4
08-17 06:45:38.293   327   400 I MediaCodecsXmlParser: limit: performance-point-1920x1088-range = 30-30
08-17 06:45:38.293   327   400 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_google_video.xml...
08-17 06:45:38.294   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:38.294   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.294   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.294   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-983040
08-17 06:45:38.294   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.294   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.294   327   400 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 32
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: size-range = 64x64-1280x720
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-244800
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-10000000
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: max-concurrent-instances = 32
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: size-range = 2x2-1280x720
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: alignment = 8x8
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 1-983040
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: feature-adaptive-playback = 0
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-176x144
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-128000
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: size-range = 16x16-176x144
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: alignment = 16x16
08-17 06:45:38.295   327   400 I MediaCodecsXmlParser: limit: block-size = 16x16
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: blocks-per-second-range = 12-1485
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-64000
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1280x720
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: size-range = 176x144-1280x720
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: alignment = 2x2
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: bitrate-range = 1-40000000
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: feature-bitrate-modes = VBR,CBR
08-17 06:45:38.296   327   400 D MediaCodecsXmlParser: parsing /vendor/etc/media_codecs_performance.xml...
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 165-165
08-17 06:45:38.296   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 149-149
08-17 06:45:38.297   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 73-73
08-17 06:45:38.297   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 18-18
08-17 06:45:38.297   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 306-306
08-17 06:45:38.297   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 54-54
08-17 06:45:38.297   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 58-58
08-17 06:45:38.297   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 619-619
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 619-619
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 55-55
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 35-35
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 28-28
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 32-32
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 376-376
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 149-149
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 73-73
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 34-34
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 203-240
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 199-207
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 45-45
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 35-35
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 28-28
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 32-32
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 617-617
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 559-559
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 276-276
08-17 06:45:38.300   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 164-164
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-3840x2160-range = 30-30
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 500-500
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 387-387
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 112-112
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 77-77
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 600-600
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 600-600
08-17 06:45:38.301   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 600-600
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 700-700
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 700-700
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 980-980
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 600-600
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 130-130
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-3840x2160-range = 130-130
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 230-230
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 132-132
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-38
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 51-51
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 253-253
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 128-128
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 104-104
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 91-91
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 48-48
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 24-24
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:38.302   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-42
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 94-94
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 500-500
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 387-387
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 310-318
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 150-200
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x240-range = 230-230
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 132-132
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-38
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 51-51
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-352x288-range = 253-253
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 128-128
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-720x480-range = 104-104
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 91-91
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 175-188
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-176x144-range = 201-203
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 48-48
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 24-24
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-320x180-range = 432-432
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-640x360-range = 320-320
08-17 06:45:38.303   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1280x720-range = 38-42
08-17 06:45:38.304   327   400 I MediaCodecsXmlParser: limit: measured-frame-rate-1920x1080-range = 94-94
08-17 06:45:38.304   338   392 V C2Store : in init
08-17 06:45:38.304   338   392 V C2Store : loading dll
08-17 06:45:38.304   810   810 I WebViewZygoteInit: Beginning application preload for com.android.webview
08-17 06:45:38.305   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.0::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:38.307   260   292 D hwc-drm-event-listener: hwc_uevent detect hotplug
08-17 06:45:38.311   327   400 I Codec2InfoBuilder: adding type 'audio/mp4a-latm'
08-17 06:45:38.314   260   292 E hwc-drm-resources: is_hdr_panel_support_st2084:line=1393, blob is null
08-17 06:45:38.314   260   292 W HWC2On1Adapter: hwc1Hotplug: Received disconnect for unconnected display
08-17 06:45:38.315   260   292 W hwc_rk  : BP: baseparamter file cann't be find.
08-17 06:45:38.316   338   392 V C2Store : in init
08-17 06:45:38.316   338   392 V C2Store : loading dll
08-17 06:45:38.316   338   338 V C2Store : in ~ComponentModule
08-17 06:45:38.316   338   338 V C2Store : unloading dll
08-17 06:45:38.321   327   400 I Codec2InfoBuilder: adding type 'audio/mp4a-latm'
08-17 06:45:38.324   429   449 I EthernetTracker: interfaceLinkStateChanged, iface: eth0, up: false
08-17 06:45:38.324   338   892 V C2Store : in init
08-17 06:45:38.324   338   892 V C2Store : loading dll
08-17 06:45:38.325   764   820 D mali_winsys: EGLint new_window_surface(egl_winsys_display *, void *, EGLSurface, EGLConfig, egl_winsys_surface **, egl_color_buffer_format *, EGLBoolean) returns 0x300
0
08-17 06:45:38.327   810   810 I webview_zygote: The ClassLoaderContext is a special shared library.
08-17 06:45:38.329   327   400 I Codec2InfoBuilder: adding type 'audio/3gpp'
08-17 06:45:38.330   338   391 V C2Store : in init
08-17 06:45:38.330   338   391 V C2Store : loading dll
08-17 06:45:38.336   327   400 I Codec2InfoBuilder: adding type 'audio/3gpp'
08-17 06:45:38.338   338   896 V C2Store : in ~ComponentModule
08-17 06:45:38.338   338   896 V C2Store : unloading dll
08-17 06:45:38.338   338   338 V C2Store : in init
08-17 06:45:38.338   338   338 V C2Store : loading dll
08-17 06:45:38.341   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.342   338   392 V C2Store : unloading dll
08-17 06:45:38.343   327   400 I Codec2InfoBuilder: adding type 'audio/amr-wb'
08-17 06:45:38.343   338   391 V C2Store : in init
08-17 06:45:38.344   338   391 V C2Store : loading dll
08-17 06:45:38.345   338   898 V C2Store : in ~ComponentModule
08-17 06:45:38.345   338   898 V C2Store : unloading dll
08-17 06:45:38.347   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:38.347   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:38.347
08-17 06:45:38.347   327   400 I Codec2InfoBuilder: adding type 'audio/amr-wb'
08-17 06:45:38.348   338   896 V C2Store : in init
08-17 06:45:38.348   338   896 V C2Store : loading dll
08-17 06:45:38.350   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.mapper@3.0::IMapper/default in either framework or device manifest.
08-17 06:45:38.350   764   820 W Gralloc3: mapper 3.x is not supported
08-17 06:45:38.353   327   400 I Codec2InfoBuilder: adding type 'video/av01'
08-17 06:45:38.356   338   392 V C2Store : in init
08-17 06:45:38.356   764   820 D GRALLOC-ROCKCHIP: RK_GRAPHICS_VER=commit-id:344c4dd
08-17 06:45:38.356   338   392 V C2Store : loading dll
08-17 06:45:38.360   338   338 V C2Store : in ~ComponentModule
08-17 06:45:38.360   338   338 V C2Store : unloading dll
08-17 06:45:38.361   338   391 V C2Store : in ~ComponentModule
08-17 06:45:38.361   338   391 V C2Store : unloading dll
08-17 06:45:38.362   338   892 V C2Store : in ~ComponentModule
08-17 06:45:38.362   338   892 V C2Store : unloading dll
08-17 06:45:38.364   259   313 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:38.364   259   313 I GRALLOC-ROCKCHIP: dmabuf_name : 313_12582912_06:45:38.364
08-17 06:45:38.367   327   400 I Codec2InfoBuilder: adding type 'video/avc'
08-17 06:45:38.368   595   837 I vol.Events: writeEvent level_changed STREAM_VOICE_CALL 1
08-17 06:45:38.371   338   391 V C2Store : in init
08-17 06:45:38.371   338   391 V C2Store : loading dll
08-17 06:45:38.373   338   391 I /apex/com.android.media.swcodec/bin/mediaswcodec: missing struct descriptor #Param::CoreIndex(--004) for field values of struct #Param::CoreIndex(F-12004)
08-17 06:45:38.375   338   900 V C2Store : in ~ComponentModule
08-17 06:45:38.375   338   900 V C2Store : unloading dll
08-17 06:45:38.377   338   391 I /apex/com.android.media.swcodec/bin/mediaswcodec: missing struct descriptor #Param::CoreIndex(--004) for field values of struct #Param::CoreIndex(F-12004)
08-17 06:45:38.378   849   849 I ExplicitHealthCheckServiceImpl: Network stack module not found
08-17 06:45:38.378   327   400 I Codec2InfoBuilder: adding type 'video/avc'
08-17 06:45:38.382   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.radio@1.4::IRadio/slot1 in either framework or device manifest.
08-17 06:45:38.384   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.radio@1.3::IRadio/slot1 in either framework or device manifest.
08-17 06:45:38.384   338   892 V C2Store : in init
08-17 06:45:38.384   338   892 V C2Store : loading dll
08-17 06:45:38.384   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:38.384   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:38.384
08-17 06:45:38.387   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.radio@1.2::IRadio/slot1 in either framework or device manifest.
08-17 06:45:38.388   338   391 V C2Store : in ~ComponentModule
08-17 06:45:38.388   338   391 V C2Store : unloading dll
08-17 06:45:38.389   595   837 I vol.Events: writeEvent level_changed STREAM_SYSTEM 5
08-17 06:45:38.389   327   400 I Codec2InfoBuilder: adding type 'audio/flac'
08-17 06:45:38.390   338   392 V C2Store : in init
08-17 06:45:38.390   338   392 V C2Store : loading dll
08-17 06:45:38.392   595   837 I vol.Events: writeEvent level_changed STREAM_RING 5
08-17 06:45:38.393   673   673 I android_os_HwBinder: HwBinder: Starting thread pool for getting: android.hardware.radio@1.1::IRadio/slot1
08-17 06:45:38.394   327   400 I Codec2InfoBuilder: adding type 'audio/flac'
08-17 06:45:38.394   338   900 V C2Store : in init
08-17 06:45:38.394   338   900 V C2Store : loading dll
08-17 06:45:38.399   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.400   338   391 V C2Store : in ~ComponentModule
08-17 06:45:38.400   338   391 V C2Store : unloading dll
08-17 06:45:38.400   327   400 I Codec2InfoBuilder: adding type 'audio/g711-alaw'
08-17 06:45:38.400   338   392 V C2Store : unloading dll
08-17 06:45:38.400   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.volume.VolumeUI took to complete: 145ms
08-17 06:45:38.400   338   896 V C2Store : in init
08-17 06:45:38.401   338   896 V C2Store : loading dll
08-17 06:45:38.401   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.401   338   392 V C2Store : unloading dll
08-17 06:45:38.401   595   837 I vol.Events: writeEvent level_changed STREAM_MUSIC 5
08-17 06:45:38.406   327   400 I Codec2InfoBuilder: adding type 'audio/g711-mlaw'
08-17 06:45:38.406   338   338 V C2Store : in init
08-17 06:45:38.406   338   338 V C2Store : loading dll
08-17 06:45:38.407   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.407   338   392 V C2Store : unloading dll
08-17 06:45:38.408   595   837 I vol.Events: writeEvent level_changed STREAM_ALARM 6
08-17 06:45:38.411   595   837 I vol.Events: writeEvent level_changed STREAM_BLUETOOTH_SCO 7
08-17 06:45:38.411   327   400 D Codec2InfoBuilder: codec entry for 'c2.android.gsm.decoder' is disabled
08-17 06:45:38.412   338   338 V C2Store : in ~ComponentModule
08-17 06:45:38.412   338   338 V C2Store : unloading dll
08-17 06:45:38.412   338   904 V C2Store : in init
08-17 06:45:38.413   338   904 V C2Store : loading dll
08-17 06:45:38.422   810   810 I WebViewZygoteInit: Application preload done
08-17 06:45:38.423   327   400 I Codec2InfoBuilder: adding type 'video/3gpp'
08-17 06:45:38.424   338   896 V C2Store : in init
08-17 06:45:38.424   338   896 V C2Store : loading dll
08-17 06:45:38.426   673   673 I android_os_HwBinder: HwBinder: Starting thread pool for getting: android.hardware.radio.deprecated@1.0::IOemHook/slot1
08-17 06:45:38.426   327   400 I Codec2InfoBuilder: adding type 'video/3gpp'
08-17 06:45:38.427   338   904 V C2Store : in ~ComponentModule
08-17 06:45:38.429   338   904 V C2Store : unloading dll
08-17 06:45:38.430   595   837 I vol.Events: writeEvent zen_mode_config_changed [disallowAlarms=false disallowMedia=false disallowSystem=true disallowRinger=false]
08-17 06:45:38.431   338   392 V C2Store : in init
08-17 06:45:38.431   338   392 V C2Store : loading dll
08-17 06:45:38.432   338   904 V C2Store : in ~ComponentModule
08-17 06:45:38.432   338   904 V C2Store : unloading dll
08-17 06:45:38.434   327   400 I Codec2InfoBuilder: adding type 'video/hevc'
08-17 06:45:38.436   338   338 V C2Store : in init
08-17 06:45:38.436   338   338 V C2Store : loading dll
08-17 06:45:38.437   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.437   338   392 V C2Store : unloading dll
08-17 06:45:38.438   338   338 D C2SoftHevcEnc: Given level 6000 does not cover current configuration: adjusting to 6001
08-17 06:45:38.439   243   243 D Zygote  : Forked child process 909
08-17 06:45:38.439   338   338 D C2SoftHevcEnc: Given level 6000 does not cover current configuration: adjusting to 6001
08-17 06:45:38.440   327   400 D Codec2InfoBuilder: codec entry for 'c2.android.hevc.encoder' is disabled
08-17 06:45:38.441   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.441   338   392 V C2Store : unloading dll
08-17 06:45:38.441   338   392 V C2Store : in init
08-17 06:45:38.441   338   392 V C2Store : loading dll
08-17 06:45:38.442   429   459 I ActivityManager: Start proc 909:com.android.inputmethod.latin/u0a88 for service {com.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME}
08-17 06:45:38.444   327   400 I Codec2InfoBuilder: adding type 'audio/mpeg'
08-17 06:45:38.444   338   896 V C2Store : in init
08-17 06:45:38.444   338   896 V C2Store : loading dll
08-17 06:45:38.445   338   338 V C2Store : in ~ComponentModule
08-17 06:45:38.445   338   338 V C2Store : unloading dll
08-17 06:45:38.446   429   452 W KeyguardServiceDelegate: onScreenTurningOn(): no keyguard service!
08-17 06:45:38.447   327   400 D Codec2InfoBuilder: codec entry for 'c2.android.mpeg2.decoder' is disabled
08-17 06:45:38.447   338   896 V C2Store : in ~ComponentModule
08-17 06:45:38.447   338   896 V C2Store : unloading dll
08-17 06:45:38.447   838   838 W ContextImpl: Failed to ensure /data/user/0/com.android.launcher3/cache: mkdir failed: ENOENT (No such file or directory)
08-17 06:45:38.448   338   896 V C2Store : in init
08-17 06:45:38.448   338   896 V C2Store : loading dll
08-17 06:45:38.449   838   838 W ContextImpl: Failed to update user.inode_cache: stat failed: ENOENT (No such file or directory)
08-17 06:45:38.451   327   400 I Codec2InfoBuilder: adding type 'video/mp4v-es'
08-17 06:45:38.452   338   900 V C2Store : in init
08-17 06:45:38.452   338   900 V C2Store : loading dll
08-17 06:45:38.453   338   896 V C2Store : in ~ComponentModule
08-17 06:45:38.453   338   896 V C2Store : unloading dll
08-17 06:45:38.455   327   400 I Codec2InfoBuilder: adding type 'video/mp4v-es'
08-17 06:45:38.455   673   673 D TelephonyProvider: dbh.onOpen: ok, queried table=siminfo
08-17 06:45:38.456   338   392 V C2Store : in init
08-17 06:45:38.456   338   392 V C2Store : loading dll
08-17 06:45:38.456   673   673 D TelephonyProvider: dbh.onOpen: ok, queried table=carriers
08-17 06:45:38.457   338   900 V C2Store : in ~ComponentModule
08-17 06:45:38.457   338   900 V C2Store : unloading dll
08-17 06:45:38.458   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.stackdivider.Divider took to complete: 58ms
08-17 06:45:38.458   327   400 I Codec2InfoBuilder: adding type 'audio/opus'
08-17 06:45:38.459   338   392 V C2Store : in ~ComponentModule
08-17 06:45:38.459   338   392 V C2Store : unloading dll
08-17 06:45:38.462   338   896 V C2Store : in init
08-17 06:45:38.462   338   896 V C2Store : loading dll
08-17 06:45:38.464   327   400 I Codec2InfoBuilder: adding type 'audio/opus'
08-17 06:45:38.465   338   338 V C2Store : in init
08-17 06:45:38.465   338   338 V C2Store : loading dll
08-17 06:45:38.465   338   896 V C2Store : in ~ComponentModule
08-17 06:45:38.465   338   896 V C2Store : unloading dll
08-17 06:45:38.470   327   400 I Codec2InfoBuilder: adding type 'audio/raw'
08-17 06:45:38.471   338   338 V C2Store : in ~ComponentModule
08-17 06:45:38.471   338   338 V C2Store : unloading dll
08-17 06:45:38.471   338   338 V C2Store : in init
08-17 06:45:38.471   338   338 V C2Store : loading dll
08-17 06:45:38.473   327   400 I Codec2InfoBuilder: adding type 'audio/vorbis'
08-17 06:45:38.474   338   900 V C2Store : in ~ComponentModule
08-17 06:45:38.474   338   900 V C2Store : unloading dll
08-17 06:45:38.475   338   338 V C2Store : in init
08-17 06:45:38.475   338   338 V C2Store : loading dll
08-17 06:45:38.478   327   400 I Codec2InfoBuilder: adding type 'video/x-vnd.on2.vp8'
08-17 06:45:38.478   338   900 V C2Store : in ~ComponentModule
08-17 06:45:38.478   338   900 V C2Store : unloading dll
08-17 06:45:38.479   338   900 V C2Store : in init
08-17 06:45:38.479   338   900 V C2Store : loading dll
08-17 06:45:38.480   338   900 I C2SoftVp8Enc: setting temporal layering 0 + 0
08-17 06:45:38.480   338   900 I C2SoftVp8Enc: setting temporal layering 0 + 0
08-17 06:45:38.481   327   400 D Codec2InfoBuilder: codec entry for 'c2.android.vp8.encoder' is disabled
08-17 06:45:38.481   338   900 V C2Store : in ~ComponentModule
08-17 06:45:38.481   338   900 V C2Store : unloading dll
08-17 06:45:38.482   338   900 V C2Store : in init
08-17 06:45:38.482   338   900 V C2Store : loading dll
08-17 06:45:38.485   327   400 I Codec2InfoBuilder: adding type 'video/x-vnd.on2.vp9'
08-17 06:45:38.488   338   896 V C2Store : in init
08-17 06:45:38.488   338   896 V C2Store : loading dll
08-17 06:45:38.488   338   904 V C2Store : in ~ComponentModule
08-17 06:45:38.488   338   904 V C2Store : unloading dll
08-17 06:45:38.488   338   896 I C2SoftVp9Enc: setting temporal layering 0 + 0
08-17 06:45:38.489   338   896 I C2SoftVp9Enc: setting temporal layering 0 + 0
08-17 06:45:38.490   327   400 D Codec2InfoBuilder: codec entry for 'c2.android.vp9.encoder' is disabled
08-17 06:45:38.490   338   896 V C2Store : in ~ComponentModule
08-17 06:45:38.490   338   896 V C2Store : unloading dll
08-17 06:45:38.492   429   457 I ActivityTaskManager: Displayed com.android.settings/.FallbackHome: +852ms
08-17 06:45:38.500   595   595 I FalsingManagerPlugin: xdpi, ydpi: 320.0, 320.0
08-17 06:45:38.500   595   595 I FalsingManagerPlugin: width, height: 1536, 1964
08-17 06:45:38.500   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:38.512   909   909 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:38.512   909   909 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:38.512   909   909 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:38.520   838   838 D TouchInteractionService: Touch service connected
08-17 06:45:38.524   429   451 I chatty  : uid=1000(system) android.io identical 2 lines
08-17 06:45:38.527   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:38.528   429   442 I system_server: NativeAlloc concurrent copying GC freed 5221(691KB) AllocSpace objects, 7(140KB) LOS objects, 42% free, 6564KB/11MB, paused 131us total 269.075ms
08-17 06:45:38.529   429   429 I system_server: WaitForGcToComplete blocked ClassLinker on ClassLinker for 248.595ms
08-17 06:45:38.534   429   429 W Looper  : Slow dispatch took 279ms main h=android.app.ActivityThread$H c=null m=114
08-17 06:45:38.540   321   321 D incidentd: WorkDirectory::getReports
08-17 06:45:38.544   595   595 V WifiManager: registerTrafficStateCallback: callback=com.android.systemui.statusbar.policy.WifiSignalController$WifiTrafficStateCallback@817ec44, handler=null
08-17 06:45:38.549   429   501 D ConnectivityService: requestNetwork for uid/pid:10082/595 NetworkRequest [ TRACK_DEFAULT id=11, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 10082] ]
08-17 06:45:38.550   242   375 I netd    : registerUnsolicitedEventListener() <0.03ms>
08-17 06:45:38.576   909   909 I LatinIME: Hardware accelerated drawing: true
08-17 06:45:38.602   595   833 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:38.606   595   595 D StatusBar: disable<e i a s b h r c s > disable2<q i n >
08-17 06:45:38.606   595   833 I Codec2Client: Available Codec2 services: "software"
08-17 06:45:38.607   595   833 I Codec2Client: Creating a Codec2 client to service "software"
08-17 06:45:38.608   429   910 I StatusBarManagerService: registerStatusBar bar=com.android.internal.statusbar.IStatusBar$Stub$Proxy@d488327
08-17 06:45:38.608   595   833 I Codec2Client: Client to Codec2 service "software" created
08-17 06:45:38.610   338   338 V C2Store : in init
08-17 06:45:38.610   338   338 V C2Store : loading dll
08-17 06:45:38.615   595   833 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:38.615   595   833 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:38.620   595   833 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:38.620   595   833 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:38.620   595   833 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:38.621   595   833 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:38.621   595   833 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:38.621   595   833 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:38.621   595   833 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:38.624   595   833 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:38.624   595   833 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:38.624   595   833 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:38.624   595   833 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:38.624   595   833 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:38.624   595   833 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:38.624   595   833 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:38.624   595   833 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:38.624   595   833 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:38.624   595   833 D CCodecConfig: }
08-17 06:45:38.625   595   833 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:38.625   595   833 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:38.625   595   833 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:38.625   595   833 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:38.626   595   833 D CCodecConfig: c2 config diff is   c2::u32 raw.channel-count.value = 2
08-17 06:45:38.626   595   833 D CCodecConfig:   c2::u32 raw.sample-rate.value = 44100
08-17 06:45:38.627   595   833 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:38.627   595   833 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:38.627   595   833 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.627   595   833 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:38.627   595   833 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:38.627   595   833 D CCodec  :   int32_t sample-rate = 44100
08-17 06:45:38.627   595   833 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:38.627   595   833 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.627   595   833 D CCodec  :   string mime = "audio/raw"
08-17 06:45:38.627   595   833 D CCodec  :   int32_t sample-rate = 44100
08-17 06:45:38.627   595   833 D CCodec  :   int32_t channel-mask = 3
08-17 06:45:38.627   595   833 D CCodec  : }
08-17 06:45:38.628   595   833 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:38.628   595   833 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:38.632   595   833 D CCodecBufferChannel: [c2.android.vorbis.decoder#932] Created input block pool with allocatorID 16 => poolID 17 - OK (0)
08-17 06:45:38.633   595   833 I CCodecBufferChannel: [c2.android.vorbis.decoder#932] Created output block pool with allocatorID 16 => poolID 17 - OK
08-17 06:45:38.633   595   833 D CCodecBufferChannel: [c2.android.vorbis.decoder#932] Configured output block pool ids 17 => OK
08-17 06:45:38.634   595   833 E ion     : ioctl c0044901 failed with code -1: Not a typewriter
08-17 06:45:38.635   338   955 D SimpleC2Component: Using output block pool with poolID 17 => got 17 - 0
08-17 06:45:38.638   338   900 E ion     : ioctl c0044901 failed with code -1: Not a typewriter
08-17 06:45:38.642   909   909 W InputAttributes: No editor info for this field. Bug?
08-17 06:45:38.663   429   623 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:38.664   909   959 I LatinIME:LogUtils: Dictionary info: dictionary = UserHistoryDictionary.en_US ; version = 1597646738 ; date = ?
08-17 06:45:38.665   909   959 I LatinIME:LogUtils: Dictionary info: dictionary = userunigram.en_US ; version = 1597646738 ; date = ?
08-17 06:45:38.666   909   959 E ActivityThread: Failed to find provider info for user_dictionary
08-17 06:45:38.666   429   623 I Codec2Client: Available Codec2 services: "software"
08-17 06:45:38.669   429   623 I Codec2Client: Creating a Codec2 client to service "software"
08-17 06:45:38.669   429   429 I system_server: The ClassLoaderContext is a special shared library.
08-17 06:45:38.671   429   623 I Codec2Client: Client to Codec2 service "software" created
08-17 06:45:38.675   673   673 W TelecomManager: Telecom Service not found.
08-17 06:45:38.678   429   623 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:38.678   429   623 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:38.683   429   623 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:38.684   429   623 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:38.684   429   623 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:38.684   429   623 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:38.684   429   623 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:38.684   429   623 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:38.685   429   623 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:38.686   429   623 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:38.686   429   623 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:38.686   429   623 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:38.686   429   623 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:38.686   429   623 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:38.686   429   623 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:38.686   429   623 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:38.686   429   623 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:38.686   429   623 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:38.686   429   623 D CCodecConfig: }
08-17 06:45:38.686   429   623 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:38.686   429   623 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:38.686   429   623 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:38.686   429   623 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:38.687   429   623 D CCodecConfig: c2 config diff is   c2::u32 raw.channel-count.value = 2
08-17 06:45:38.687   429   623 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:38.687   429   623 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:38.687   429   623 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.687   429   623 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:38.687   429   623 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:38.687   429   623 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.687   429   623 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:38.687   429   623 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.687   429   623 D CCodec  :   string mime = "audio/raw"
08-17 06:45:38.687   429   623 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.687   429   623 D CCodec  :   int32_t channel-mask = 3
08-17 06:45:38.687   429   623 D CCodec  : }
08-17 06:45:38.688   429   429 I system_server: The ClassLoaderContext is a special shared library.
08-17 06:45:38.689   429   623 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:38.689   429   623 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:38.690   429   623 D CCodecBufferChannel: [c2.android.vorbis.decoder#506] Created input block pool with allocatorID 16 => poolID 17 - OK (0)
08-17 06:45:38.691   429   623 I CCodecBufferChannel: [c2.android.vorbis.decoder#506] Created output block pool with allocatorID 16 => poolID 18 - OK
08-17 06:45:38.691   429   623 D CCodecBufferChannel: [c2.android.vorbis.decoder#506] Configured output block pool ids 18 => OK
08-17 06:45:38.692   429   623 E ion     : ioctl c0044901 failed with code -1: Not a typewriter
08-17 06:45:38.693   673   673 E SystemConfig: SystemConfig is being accessed by a process other than system_server.
08-17 06:45:38.693   595   968 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:38.698   595   968 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:38.699   338   964 D SimpleC2Component: Using output block pool with poolID 18 => got 18 - 0
08-17 06:45:38.700   595   968 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:38.702   429   429 W Looper  : Slow dispatch took 150ms main h=android.app.ActivityThread$H c=null m=114
08-17 06:45:38.703   595   968 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:38.704   595   968 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:38.704   595   968 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:38.704   595   968 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:38.705   595   968 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:38.705   595   968 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:38.705   595   968 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:38.707   595   968 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:38.707   595   968 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:38.707   595   968 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:38.707   595   968 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:38.707   595   968 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:38.707   595   968 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:38.707   595   968 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:38.707   595   968 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:38.707   595   968 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:38.707   595   968 D CCodecConfig: }
08-17 06:45:38.708   595   968 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:38.708   595   968 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:38.708   595   968 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:38.708   595   968 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:38.709   595   968 D CCodecConfig: c2 config diff is   c2::u32 raw.channel-count.value = 2
08-17 06:45:38.709   595   968 D CCodecConfig:   c2::u32 raw.sample-rate.value = 44100
08-17 06:45:38.710   595   968 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:38.710   595   968 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:38.710   595   968 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.710   595   968 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:38.710   595   968 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:38.710   595   968 D CCodec  :   int32_t sample-rate = 44100
08-17 06:45:38.710   595   968 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:38.710   595   968 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.710   595   968 D CCodec  :   string mime = "audio/raw"
08-17 06:45:38.710   595   968 D CCodec  :   int32_t sample-rate = 44100
08-17 06:45:38.710   595   968 D CCodec  :   int32_t channel-mask = 3
08-17 06:45:38.710   595   968 D CCodec  : }
08-17 06:45:38.711   595   968 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:38.711   595   968 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:38.713   595   968 D CCodecBufferChannel: [c2.android.vorbis.decoder#858] Created input block pool with allocatorID 16 => poolID 18 - OK (0)
08-17 06:45:38.715   595   968 I CCodecBufferChannel: [c2.android.vorbis.decoder#858] Created output block pool with allocatorID 16 => poolID 19 - OK
08-17 06:45:38.715   595   968 D CCodecBufferChannel: [c2.android.vorbis.decoder#858] Configured output block pool ids 19 => OK
08-17 06:45:38.717   429   970 I DropBoxManagerService: add tag=system_app_wtf isTagEnabled=true flags=0x2
08-17 06:45:38.717   338   969 D SimpleC2Component: Using output block pool with poolID 19 => got 19 - 0
08-17 06:45:38.718   429   429 E WiredAccessoryManager: No state change.
08-17 06:45:38.718   429   429 E WiredAccessoryManager: No state change.
08-17 06:45:38.719   429   429 I WiredAccessoryManager: MSG_NEW_DEVICE_STATE
08-17 06:45:38.732   909   959 I LatinIME:LogUtils: Dictionary info: dictionary = main:en ; version = 54 ; date = 1414726273
08-17 06:45:38.738   429   429 V NotificationListeners: enabling notification listener for 0: ComponentInfo{com.android.launcher3/com.android.launcher3.notification.NotificationListener}
08-17 06:45:38.738   429   429 V NotificationListeners: binding: Intent { act=android.service.notification.NotificationListenerService cmp=com.android.launcher3/.notification.NotificationListener (has
 extras) }
08-17 06:45:38.738   429   429 W ActivityManager: Unable to start service Intent { act=android.service.notification.NotificationListenerService cmp=com.android.launcher3/.notification.NotificationList
ener } U=0: not found
08-17 06:45:38.738   429   429 W NotificationListeners: Unable to bind notification listener service: Intent { act=android.service.notification.NotificationListenerService cmp=com.android.launcher3/.n
otification.NotificationListener (has extras) } in user 0
08-17 06:45:38.739   429   429 V NotificationAssistants: enabling notification assistant for 0: ComponentInfo{android.ext.services/android.ext.services.notification.Assistant}
08-17 06:45:38.739   429   429 V NotificationAssistants: binding: Intent { act=android.service.notification.NotificationAssistantService cmp=android.ext.services/.notification.Assistant (has extras) }

08-17 06:45:38.740   673   673 W SystemConfig: No directory /product/etc/sysconfig, skipping
08-17 06:45:38.748   248   248 W DeviceHAL: Error from HAL Device in function set_mic_mute: Function not implemented
08-17 06:45:38.748   248   312 W DeviceHAL: Error from HAL Device in function set_mic_mute: Function not implemented
08-17 06:45:38.748   429   429 E AudioSystem-JNI: Command failed for android_media_AudioSystem_muteMicrophone: -38
08-17 06:45:38.750   673   673 W SystemConfig: No directory /product_services/etc/sysconfig, skipping
08-17 06:45:38.751   673   673 W SystemConfig: No directory /product_services/etc/permissions, skipping
08-17 06:45:38.758   673   673 D PhoneSwitcherNetworkRequstListener: Registering NetworkFactory
08-17 06:45:38.763   429   540 D ConnectivityService: Got NetworkFactory Messenger for PhoneSwitcherNetworkRequstListener
08-17 06:45:38.770   338   956 V C2Store : in ~ComponentModule
08-17 06:45:38.771   338   956 V C2Store : unloading dll
08-17 06:45:38.780   429   540 D ConnectivityService: Got NetworkFactory Messenger for TelephonyNetworkFactory[0]
08-17 06:45:38.781   595   978 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:38.781   338   956 V C2Store : in init
08-17 06:45:38.781   338   956 V C2Store : loading dll
08-17 06:45:38.788   595   595 I CameraManagerGlobal: Connecting to camera service
08-17 06:45:38.790   673   982 E ActivityThread: Failed to find provider info for com.android.contacts
08-17 06:45:38.790   673   982 W CallerInfoCache: cursor is null
08-17 06:45:38.793   595   978 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:38.793   595   978 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:38.794   429   429 D ConditionProviders.SCP: onSubscribe condition://android/schedule?days=1.2.3.4.5.6.7&start=22.0&end=7.0&exitAtAlarm=true
08-17 06:45:38.794   429   429 D ConditionProviders.SCP: setRegistered true
08-17 06:45:38.795   429   981 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:38.799   595   978 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:38.799   429   981 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:38.800   429   981 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:38.800   673   673 D CarrierConfigLoader: CarrierConfigLoader has started
08-17 06:45:38.800   595   978 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:38.800   595   978 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:38.800   595   978 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:38.800   595   978 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:38.800   595   978 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:38.801   595   978 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:38.803   429   429 D ConditionProviders.SCP: evaluateSubscriptionLocked cal=ScheduleCalendar[mDays={1, 2, 3, 4, 5, 6, 7}, mSchedule=ScheduleInfo{days=[1, 2, 3, 4, 5, 6, 7], startHour=22, s
tartMinute=0, endHour=7, endMinute=0, exitAtAlarm=true, nextAlarm=Thu Jan 01 00:00:00 GMT 1970 (0)}], now=Mon Aug 17 06:45:38 GMT 2020 (1597646738794), nextUserAlarmTime=Thu Jan 01 00:00:00 GMT 1970 (
0)
08-17 06:45:38.803   429   429 D ConditionProviders.SCP: notifyCondition condition://android/schedule?days=1.2.3.4.5.6.7&start=22.0&end=7.0&exitAtAlarm=true STATE_TRUE reason=meetsSchedule
08-17 06:45:38.803   429   548 E ActivityThread: Failed to find provider info for com.android.calendar
08-17 06:45:38.803   595   978 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:38.803   595   978 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:38.803   595   978 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:38.803   595   978 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:38.803   595   978 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:38.803   595   978 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:38.803   595   978 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:38.803   595   978 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:38.803   595   978 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:38.803   595   978 D CCodecConfig: }
08-17 06:45:38.804   595   978 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:38.804   595   978 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:38.804   595   978 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:38.804   595   978 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:38.804   429   548 E ActivityThread: Failed to find provider info for com.android.calendar
08-17 06:45:38.804   595   978 D CCodecConfig: c2 config diff is   c2::u32 raw.channel-count.value = 2
08-17 06:45:38.805   429   981 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:38.805   595   978 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:38.805   595   978 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:38.805   595   978 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.805   595   978 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:38.805   595   978 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:38.805   595   978 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.805   595   978 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:38.805   595   978 D CCodec  :   int32_t channel-count = 2
08-17 06:45:38.805   595   978 D CCodec  :   string mime = "audio/raw"
08-17 06:45:38.805   595   978 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.805   595   978 D CCodec  :   int32_t channel-mask = 3
08-17 06:45:38.805   595   978 D CCodec  : }
08-17 06:45:38.805   429   981 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:38.805   595   978 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:38.805   595   978 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:38.806   429   981 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:38.806   429   981 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:38.806   429   981 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:38.806   429   429 D ConditionProviders.SCP: Scheduling evaluate for Mon Aug 17 07:00:00 GMT 2020 (1597647600000), in +14m21s206ms, now=Mon Aug 17 06:45:38 GMT 2020 (1597646738794)
08-17 06:45:38.806   429   981 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:38.806   595   978 D CCodecBufferChannel: [c2.android.vorbis.decoder#629] Created input block pool with allocatorID 16 => poolID 19 - OK (0)
08-17 06:45:38.806   429   981 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:38.807   595   978 I CCodecBufferChannel: [c2.android.vorbis.decoder#629] Created output block pool with allocatorID 16 => poolID 20 - OK
08-17 06:45:38.807   595   978 D CCodecBufferChannel: [c2.android.vorbis.decoder#629] Configured output block pool ids 20 => OK
08-17 06:45:38.808   338   980 D SimpleC2Component: Using output block pool with poolID 20 => got 20 - 0
08-17 06:45:38.808   429   981 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:38.808   429   429 D BluetoothManagerService: Bluetooth Adapter name changed to rk3399
08-17 06:45:38.808   429   981 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:38.808   429   981 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:38.808   429   981 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:38.808   429   981 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:38.808   429   981 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:38.808   429   981 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:38.808   429   981 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:38.808   429   981 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:38.808   429   981 D CCodecConfig: }
08-17 06:45:38.809   429   954 D BluetoothManagerService: Trying to bind to profile: 1, while Bluetooth was disabled
08-17 06:45:38.811   429   429 D BluetoothManagerService: Stored Bluetooth name: rk3399
08-17 06:45:38.812   429   429 D BluetoothManagerService: BluetoothServiceConnection: com.android.bluetooth.btservice.AdapterService
08-17 06:45:38.812   429   451 D BluetoothManagerService: MESSAGE_BLUETOOTH_SERVICE_CONNECTED: 1
08-17 06:45:38.812   429   451 D BluetoothManagerService: MESSAGE_GET_NAME_AND_ADDRESS
08-17 06:45:38.814   429   981 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:38.814   429   981 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:38.814   429   981 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:38.814   429   981 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:38.814   429   981 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:38.814   429   981 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:38.814   429   981 D CCodec  :   int32_t channel-count = 1
08-17 06:45:38.814   429   981 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:38.814   429   981 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:38.814   429   981 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.814   429   981 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:38.814   429   981 D CCodec  :   int32_t channel-count = 1
08-17 06:45:38.814   429   981 D CCodec  :   string mime = "audio/raw"
08-17 06:45:38.814   429   981 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.814   429   981 D CCodec  :   int32_t channel-mask = 1
08-17 06:45:38.814   429   981 D CCodec  : }
08-17 06:45:38.816   429   981 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:38.816   429   981 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:38.816   429   451 D BluetoothManagerService: Stored Bluetooth name: rk3399
08-17 06:45:38.817   429   451 D BluetoothManagerService: unbindAndFinish(): android.bluetooth.IBluetooth$Stub$Proxy@4f6cd1c mBinding = false mUnbinding = false
08-17 06:45:38.823   429   981 D CCodecBufferChannel: [c2.android.vorbis.decoder#141] Created input block pool with allocatorID 16 => poolID 18 - OK (0)
08-17 06:45:38.824   429   981 I CCodecBufferChannel: [c2.android.vorbis.decoder#141] Created output block pool with allocatorID 16 => poolID 21 - OK
08-17 06:45:38.824   429   981 D CCodecBufferChannel: [c2.android.vorbis.decoder#141] Configured output block pool ids 21 => OK
08-17 06:45:38.825   338   983 D SimpleC2Component: Using output block pool with poolID 21 => got 21 - 0
08-17 06:45:38.835   573   573 D BluetoothAdapterService: onUnbind() - calling cleanup
08-17 06:45:38.835   573   573 D BluetoothAdapterService: cleanup()
08-17 06:45:38.849   429   429 I Telecom : WiredHeadsetManager: ACTION_HEADSET_PLUG event, plugged in: false, : WHC.oADA@AAE
08-17 06:45:38.850   573   573 W BluetoothSdpJni: Cleaning up Bluetooth SDP Interface...
08-17 06:45:38.851   573   573 W BluetoothSdpJni: Cleaning up Bluetooth SDP object
08-17 06:45:38.851   573   573 D BluetoothAdapterService: cleanup() - Cleaning up adapter native
08-17 06:45:38.852   573   770 I bt_stack_manager: event_clean_up_stack is cleaning up the stack
08-17 06:45:38.852   573   770 I bt_btif_core: btif_cleanup_bluetooth entered
08-17 06:45:38.852   429   502 D ActivityTaskManager: Top Process State changed to PROCESS_STATE_TOP_SLEEPING
08-17 06:45:38.853   429   429 D MediaSessionService: Global priority session is changed from null to com.android.server.telecom/HeadsetMediaButton (userId=0)
08-17 06:45:38.853   573   770 E         : [0817/064538.853632:ERROR:message_loop_thread.cc(69)] DoInThreadDelayed: message loop is null for thread bt_main_thread(-1), from pc:0x72c6524038
08-17 06:45:38.853   573   770 E         : [0817/064538.853829:ERROR:btu_task.cc(89)] do_in_main_thread: failed from pc:0x72c6524038
08-17 06:45:38.853   573   770 I bt_btif_queue: btif_queue_release
08-17 06:45:38.854   429   452 W UsageStatsService: Event reported without a package name, eventType:17
08-17 06:45:38.854   573   791 I         : [0817/064538.854390:INFO:message_loop_thread.cc(196)] Run: message loop finished for thread bt_jni_thread
08-17 06:45:38.855   573   770 I bt_core_module: module_clean_up Cleaning up module "stack_config_module"
08-17 06:45:38.855   573   770 I bt_core_module: module_clean_up Cleanup of module "stack_config_module" completed
08-17 06:45:38.855   573   770 I bt_core_module: module_clean_up Cleaning up module "interop_module"
08-17 06:45:38.855   573   770 I bt_core_module: module_clean_up Cleanup of module "interop_module" completed
08-17 06:45:38.855   573   770 I bt_btif_core: btif_cleanup_bluetooth finished
08-17 06:45:38.855   573   770 I bt_core_module: module_clean_up Cleaning up module "btif_config_module"
08-17 06:45:38.864   573   770 I         : [0817/064538.864433:INFO:btif_config.cc(756)] hash_file: Disabled for multi-user
08-17 06:45:38.864   573   770 I         : [0817/064538.864586:INFO:btif_config.cc(798)] write_checksum_file: Disabled for multi-user, since config changed removing checksums.
08-17 06:45:38.864   573   770 I bt_core_module: module_clean_up Cleanup of module "btif_config_module" completed
08-17 06:45:38.865   573   770 I bt_core_module: module_clean_up Cleaning up module "bt_utils_module"
08-17 06:45:38.865   573   770 I bt_core_module: module_clean_up Cleanup of module "bt_utils_module" completed
08-17 06:45:38.865   573   770 I bt_core_module: module_clean_up Cleaning up module "osi_module"
08-17 06:45:38.865   573   788 D bt_osi_alarm: callback_dispatch Callback thread exited
08-17 06:45:38.865   573   788 W bt_osi_thread: run_thread: thread id 788, thread name alarm_dispatcher exited
08-17 06:45:38.866   573   785 W bt_osi_thread: run_thread: thread id 785, thread name alarm_default_ca exited
08-17 06:45:38.867   573   770 I bt_core_module: module_clean_up Cleanup of module "osi_module" completed
08-17 06:45:38.867   573   770 I bt_stack_manager: event_clean_up_stack finished
08-17 06:45:38.867   573   770 I         : [0817/064538.867563:INFO:message_loop_thread.cc(196)] Run: message loop finished for thread bt_stack_manager_thread
08-17 06:45:38.868   573   573 I BluetoothServiceJni: cleanupNative: return from cleanup
08-17 06:45:38.874   573   573 D BluetoothActiveDeviceManager: cleanup()
08-17 06:45:38.876   573   573 D BluetoothAdapterService: onDestroy()
08-17 06:45:38.876   429   429 I ExplicitHealthCheckController: Explicit health check service is connected ComponentInfo{android.ext.services/android.ext.services.watchdog.ExplicitHealthCheckServiceIm
pl}
08-17 06:45:38.877   338   898 V C2Store : in ~ComponentModule
08-17 06:45:38.877   338   898 V C2Store : unloading dll
08-17 06:45:38.878   429   429 I ExplicitHealthCheckController: Service initialized, syncing requests
08-17 06:45:38.878   573   573 I BluetoothAdapterService: Force exit to cleanup internal state in Bluetooth stack
08-17 06:45:38.878   429   429 I NetworkStackClient: Network stack service connected
08-17 06:45:38.880   573   573 I droid.bluetoot: System.exit called, status: 0
08-17 06:45:38.880   573   573 I AndroidRuntime: VM exiting with result code 0, cleanup skipped.
08-17 06:45:38.886   595   595 D StatusBar: mUserSetupObserver - DeviceProvisionedListener called for user 0
08-17 06:45:38.889   595   595 D StatusBar: updateQsExpansionEnabled - QS Expand enabled: true
08-17 06:45:38.892   595   595 D StatusBar: mUserSetupObserver - DeviceProvisionedListener called for user 0
08-17 06:45:38.892   595   907 D OpenGLRenderer: profile bars disabled
08-17 06:45:38.893   595   907 D OpenGLRenderer: ambientRatio = 1.50
08-17 06:45:38.898   429   995 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:38.899   338   898 V C2Store : in init
08-17 06:45:38.899   338   898 V C2Store : loading dll
08-17 06:45:38.903   174   905 E BufferQueueProducer: [com.android.settings/com.android.settings.FallbackHome#0] disconnect: not connected (req=1)
08-17 06:45:38.903   429   995 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:38.903   764   820 W libEGL  : EGLNativeWindowType 0x73b3168f50 disconnect failed
08-17 06:45:38.903   429   995 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:38.906   429   995 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:38.906   429   995 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:38.907   429   995 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:38.907   429   995 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:38.907   429   995 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:38.908   429   995 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:38.908   429   995 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:38.910   242   375 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.28ms>
08-17 06:45:38.910   429   995 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:38.910   429   995 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:38.910   429   995 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:38.910   429   995 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:38.910   429   995 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:38.910   429   995 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:38.910   429   995 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:38.910   429   995 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:38.910   429   995 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:38.910   429   995 D CCodecConfig: }
08-17 06:45:38.910   242   375 I netd    : interfaceClearAddrs("eth1") <0.32ms>
08-17 06:45:38.911   429   995 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:38.911   429   995 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:38.911   429   995 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:38.911   429   995 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:38.912   429   995 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:38.912   429   995 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:38.912   429   995 D CCodec  :   int32_t channel-count = 1
08-17 06:45:38.912   429   995 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:38.912   429   995 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:38.912   429   995 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.912   429   995 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:38.912   429   995 D CCodec  :   int32_t channel-count = 1
08-17 06:45:38.912   429   995 D CCodec  :   string mime = "audio/raw"
08-17 06:45:38.912   429   995 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:38.912   429   995 D CCodec  :   int32_t channel-mask = 1
08-17 06:45:38.912   429   995 D CCodec  : }
08-17 06:45:38.913   429   698 I DefaultPermGrantPolicy: Revoking permissions from disabled data services for user:0
08-17 06:45:38.913   429   995 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:38.913   429   995 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:38.914   429   698 I DefaultPermGrantPolicy: Granting permissions to enabled data services for user:0
08-17 06:45:38.919   248   248 D AudioHardwareTiny: adev_set_parameters: kvpairs = connect=524288
08-17 06:45:38.919   429   429 D AutofillManagerService: Restriction did not change for user 0
08-17 06:45:38.920   271   554 I AudioFlinger: openOutput() this 0x78d8b5f600, module 10 Device 0x80000, SamplingRate 32000, Format 0xd000000, Channels 0x3, flags 0x1
08-17 06:45:38.920   248   312 D AudioHardwareTiny: audio hal adev_open_output_stream devices = 0x80000, flags = 1025, samplerate = 32000,format = 0xd000000
08-17 06:45:38.920   248   312 D AudioHardwareTiny: adev_open_output_stream:out = 0xf6fce600 Spdif Bitstream
08-17 06:45:38.920   248   312 D AudioHardwareTiny: out->config.rate = 32000, out->config.channels = 2 out->config.format = 0
08-17 06:45:38.921   271   554 I AudioFlinger: HAL output buffer size 2048 frames, normal sink buffer size 2048 frames
08-17 06:45:38.921   429   429 V NotificationAssistants: 0 notification assistant service connected: ComponentInfo{android.ext.services/android.ext.services.notification.Assistant}
08-17 06:45:38.922   271   999 I AudioFlinger: AudioFlinger's thread 0x78534d9000 tid=999 ready to run
08-17 06:45:38.923   429   995 D CCodecBufferChannel: [c2.android.vorbis.decoder#48] Created input block pool with allocatorID 16 => poolID 19 - OK (0)
08-17 06:45:38.924   248   312 W StreamHAL: Error from HAL stream in function get_presentation_position: Operation not permitted
08-17 06:45:38.924   248   312 D AudioHardwareTiny: do_out_standby,out = 0xf6fce600,device = 0x80000
08-17 06:45:38.924   429   995 I CCodecBufferChannel: [c2.android.vorbis.decoder#48] Created output block pool with allocatorID 16 => poolID 22 - OK
08-17 06:45:38.925   429   995 D CCodecBufferChannel: [c2.android.vorbis.decoder#48] Configured output block pool ids 22 => OK
08-17 06:45:38.928   248   312 D AudioHardwareTiny: out_set_parameters: kvpairs = closing=true
08-17 06:45:38.929   248   312 D AudioHardwareTiny: out->Device     : 0x80000
08-17 06:45:38.930   248   312 D AudioHardwareTiny: out->SampleRate : 32000
08-17 06:45:38.930   248   312 D AudioHardwareTiny: out->Channels   : 2
08-17 06:45:38.930   248   312 D AudioHardwareTiny: out->Formate    : 0
08-17 06:45:38.930   248   312 D AudioHardwareTiny: out->PreiodSize : 2048
08-17 06:45:38.932   248   312 D AudioHardwareTiny: out_set_parameters: kvpairs = exiting=1
08-17 06:45:38.934   429   567 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth1, up = false
08-17 06:45:38.936   248   312 D AudioHardwareTiny: adev_close_output_stream!
08-17 06:45:38.936   248   312 D AudioHardwareTiny: do_out_standby,out = 0xf6fce600,device = 0x80000
08-17 06:45:38.937   248   248 D AudioHardwareTiny: out_set_parameters: kvpairs = routing=0
08-17 06:45:38.939   429   567 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth1, up = false
08-17 06:45:38.939   429   567 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 0
08-17 06:45:38.940   429   429 D PackageWatchdog: Getting all observed packages pending health checks
08-17 06:45:38.940   429   429 I PackageWatchdog: Syncing health check requests for packages: {}
08-17 06:45:38.940   429   429 D ExplicitHealthCheckController: Getting health check supported packages
08-17 06:45:38.941   338   997 D SimpleC2Component: Using output block pool with poolID 22 => got 22 - 0
08-17 06:45:38.942   429   429 W Looper  : Drained
08-17 06:45:38.943   429   501 I ExplicitHealthCheckController: Explicit health check supported packages []
08-17 06:45:38.943   429   567 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: true, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkDn
Bandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@6e5d1f3,linkProperties: {LinkAddresses: [ ] DnsAddresses: [ ] Domains: null MTU: 0 Routes: [ ]}}
08-17 06:45:38.943   429   501 D PackageWatchdog: Received supported packages []
08-17 06:45:38.943   429   501 D ExplicitHealthCheckController: Getting health check requested packages
08-17 06:45:38.944   429   567 D Ethernet: got request NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial 0
08-17 06:45:38.945   429   567 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 0
08-17 06:45:38.945   429   567 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: true, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkDn
Bandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@6e5d1f3,linkProperties: {LinkAddresses: [ ] DnsAddresses: [ ] Domains: null MTU: 0 Routes: [ ]}}
08-17 06:45:38.945   429   567 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: true, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkDn
Bandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@6e5d1f3,linkProperties: {LinkAddresses: [ ] DnsAddresses: [ ] Domains: null MTU: 0 Routes: [ ]}}
08-17 06:45:38.945   429   698 I ExplicitHealthCheckController: Explicit health check requested packages []
08-17 06:45:38.945   429   567 D Ethernet: got request NetworkRequest [ BACKGROUND_REQUEST id=2, [ Transports: CELLULAR Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial
 0
08-17 06:45:38.945   429   567 D Ethernet: got request NetworkRequest [ TRACK_DEFAULT id=9, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1000] ] with score 0 and serial 0
08-17 06:45:38.945   429   567 D Ethernet: got request NetworkRequest [ TRACK_DEFAULT id=11, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 10082] ] with score 0 and serial 0
08-17 06:45:38.945   849  1003 D ExtAssistant: File doesn't exist or isn't readable yet
08-17 06:45:38.946   429   698 I ExplicitHealthCheckController: No more health check requests, unbinding...
08-17 06:45:38.954   243   243 I Zygote  : Process 573 exited cleanly (0)
08-17 06:45:38.955   429   698 I ExplicitHealthCheckController: Explicit health check service is unbound
08-17 06:45:38.957   429   699 I ActivityManager: Process com.android.bluetooth (pid 573) has died: fore SVC
08-17 06:45:38.958   429   460 I libprocessgroup: Successfully killed process cgroup uid 1002 pid 573 in 0ms
08-17 06:45:38.960   595   595 D LocalBluetoothProfileManager: LocalBluetoothProfileManager construction complete
08-17 06:45:38.960   595   595 D LocalBluetoothProfileManager: supportedList is null
08-17 06:45:38.963   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:38.966   429   429 I Telecom : WiredHeadsetManager: ACTION_HEADSET_PLUG event, plugged in: false, : WHC.oADA@AAI
08-17 06:45:38.971   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:38.978   242   375 I netd    : interfaceSetIPv6PrivacyExtensions("eth1", "true") <0.24ms>
08-17 06:45:38.979   242   375 I netd    : setIPv6AddrGenMode("eth1", 2) <0.35ms>
08-17 06:45:38.980   242   375 I netd    : interfaceSetEnableIPv6("eth1", "true") <0.19ms>
08-17 06:45:38.984   338   900 V C2Store : in ~ComponentModule
08-17 06:45:38.984   338   900 V C2Store : unloading dll
08-17 06:45:38.986   595   595 V WifiManager: registerSoftApCallback: callback=com.android.systemui.statusbar.policy.HotspotControllerImpl@35485af, handler=Handler (android.os.Handler) {126dbc}
08-17 06:45:38.987   242   375 I netd    : setProcSysNet(4, 2, "eth1", "retrans_time_ms", "750") <0.15ms>
08-17 06:45:38.988   242   375 I netd    : setProcSysNet(4, 2, "eth1", "ucast_solicit", "5") <0.08ms>
08-17 06:45:38.989   242   375 I netd    : setProcSysNet(6, 2, "eth1", "retrans_time_ms", "750") <0.14ms>
08-17 06:45:38.996   242   375 I netd    : setProcSysNet(6, 2, "eth1", "ucast_solicit", "5") <0.13ms>
08-17 06:45:39.000   429  1010 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:39.000   338   900 V C2Store : in init
08-17 06:45:39.000   338   900 V C2Store : loading dll
08-17 06:45:39.004   595   951 I SecurityController: failed to get CA certs
08-17 06:45:39.004   595   951 I SecurityController: java.lang.AssertionError: could not bind to KeyChainService
08-17 06:45:39.004   595   951 I SecurityController:    at android.security.KeyChain.bindAsUser(KeyChain.java:814)
08-17 06:45:39.004   595   951 I SecurityController:    at com.android.systemui.statusbar.policy.SecurityControllerImpl$CACertLoader.doInBackground(SecurityControllerImpl.java:415)
08-17 06:45:39.004   595   951 I SecurityController:    at com.android.systemui.statusbar.policy.SecurityControllerImpl$CACertLoader.doInBackground(SecurityControllerImpl.java:411)
08-17 06:45:39.004   595   951 I SecurityController:    at android.os.AsyncTask$3.call(AsyncTask.java:378)
08-17 06:45:39.004   595   951 I SecurityController:    at java.util.concurrent.FutureTask.run(FutureTask.java:266)
08-17 06:45:39.004   595   951 I SecurityController:    at android.os.AsyncTask$SerialExecutor$1.run(AsyncTask.java:289)
08-17 06:45:39.004   595   951 I SecurityController:    at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
08-17 06:45:39.004   595   951 I SecurityController:    at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
08-17 06:45:39.004   595   951 I SecurityController:    at java.lang.Thread.run(Thread.java:919)
08-17 06:45:39.005   429  1010 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:39.005   429  1010 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:39.006   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.SystemBars took to complete: 548ms
08-17 06:45:39.008   429  1010 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:39.008   429  1010 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:39.009   429  1010 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:39.009   429  1010 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:39.009   429  1010 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:39.010   429  1010 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:39.010   429  1010 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:39.011   429  1010 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:39.012   595   595 D StorageNotification: Notifying about private volume: VolumeInfo{private}:
08-17 06:45:39.012   595   595 D StorageNotification:     type=PRIVATE diskId=null partGuid=null mountFlags=0 mountUserId=-10000
08-17 06:45:39.012   595   595 D StorageNotification:     state=MOUNTED
08-17 06:45:39.012   595   595 D StorageNotification:     fsType=null fsUuid=null fsLabel=null
08-17 06:45:39.012   595   595 D StorageNotification:     path=/data internalPath=null
08-17 06:45:39.012   429  1010 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:39.012   429  1010 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:39.012   429  1010 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:39.012   429  1010 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:39.012   429  1010 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:39.012   429  1010 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:39.012   429  1010 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:39.012   429  1010 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:39.012   429  1010 D CCodecConfig: }
08-17 06:45:39.013   429  1010 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:39.013   429  1010 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:39.013   429  1010 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:39.013   429  1010 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:39.014   429  1010 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:39.014   429  1010 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:39.014   429  1010 D CCodec  :   int32_t channel-count = 1
08-17 06:45:39.014   429  1010 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:39.014   429  1010 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:39.014   429  1010 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:39.014   429  1010 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:39.014   429  1010 D CCodec  :   int32_t channel-count = 1
08-17 06:45:39.014   429  1010 D CCodec  :   string mime = "audio/raw"
08-17 06:45:39.014   429  1010 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:39.014   429  1010 D CCodec  :   int32_t channel-mask = 1
08-17 06:45:39.014   429  1010 D CCodec  : }
08-17 06:45:39.015   429  1010 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:39.015   429  1010 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:39.016   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.usb.StorageNotification took to complete: 10ms
08-17 06:45:39.017   429  1010 D CCodecBufferChannel: [c2.android.vorbis.decoder#277] Created input block pool with allocatorID 16 => poolID 20 - OK (0)
08-17 06:45:39.019   429  1010 I CCodecBufferChannel: [c2.android.vorbis.decoder#277] Created output block pool with allocatorID 16 => poolID 23 - OK
08-17 06:45:39.019   595   951 E ActivityThread: Failed to find provider info for com.android.contacts
08-17 06:45:39.019   429  1010 D CCodecBufferChannel: [c2.android.vorbis.decoder#277] Configured output block pool ids 23 => OK
08-17 06:45:39.021   338  1011 D SimpleC2Component: Using output block pool with poolID 23 => got 23 - 0
08-17 06:45:39.026   429   996 D DhcpClient: Broadcasting DHCPDISCOVER
08-17 06:45:39.029   429  1013 D DhcpClient: Receive thread started
08-17 06:45:39.038   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.power.PowerUI took to complete: 22ms
08-17 06:45:39.039   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.media.RingtonePlayer took to complete: 1ms
08-17 06:45:39.041   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.keyboard.KeyboardUI took to complete: 2ms
08-17 06:45:39.042   429   933 D ConnectivityService: requestNetwork for uid/pid:1001/673 NetworkRequest [ TRACK_DEFAULT id=14, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1001] ]
08-17 06:45:39.043   673   673 D PhoneSwitcherNetworkRequstListener: got request NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial -1
08-17 06:45:39.043   429   567 D Ethernet: got request NetworkRequest [ TRACK_DEFAULT id=14, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1001] ] with score 0 and serial 0
08-17 06:45:39.043   673   673 D PhoneSwitcherNetworkRequstListener: got request NetworkRequest [ TRACK_DEFAULT id=9, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1000] ] with score 0 and seri
al -1
08-17 06:45:39.043   673   673 D PhoneSwitcherNetworkRequstListener: got request NetworkRequest [ BACKGROUND_REQUEST id=2, [ Transports: CELLULAR Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN]
 ] with score 0 and serial -1
08-17 06:45:39.044   673   673 D PhoneSwitcherNetworkRequstListener: got request NetworkRequest [ TRACK_DEFAULT id=11, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 10082] ] with score 0 and se
rial -1
08-17 06:45:39.044   673   673 D PhoneSwitcherNetworkRequstListener: got request NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial -1
08-17 06:45:39.045   673   673 D TelephonyDebugService: TelephonyDebugService()
08-17 06:45:39.050   673   673 D CarrierConfigLoader: mHandler: 12 phoneId: 0
08-17 06:45:39.052   338   898 V C2Store : in ~ComponentModule
08-17 06:45:39.052   338   898 V C2Store : unloading dll
08-17 06:45:39.054   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.pip.PipUI took to complete: 13ms
08-17 06:45:39.056   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.shortcut.ShortcutKeyDispatcher took to complete: 1ms
08-17 06:45:39.056   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.VendorServices took to complete: 0ms
08-17 06:45:39.058   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.util.leak.GarbageMonitor$Service took to complete: 1ms
08-17 06:45:39.059   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.LatencyTester took to complete: 1ms
08-17 06:45:39.060   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.globalactions.GlobalActionsComponent took to complete: 1ms
08-17 06:45:39.062   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.ScreenDecorations took to complete: 2ms
08-17 06:45:39.063   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.biometrics.BiometricDialogImpl took to complete: 1ms
08-17 06:45:39.064   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.SliceBroadcastRelayHandler took to complete: 1ms
08-17 06:45:39.065   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.SizeCompatModeActivityController took to complete: 0ms
08-17 06:45:39.065   429  1020 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:39.065   338   956 V C2Store : in init
08-17 06:45:39.065   338   956 V C2Store : loading dll
08-17 06:45:39.067   429  1020 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:39.067   429  1020 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:39.068   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.statusbar.notification.InstantAppNotifier took to complete: 4ms
08-17 06:45:39.069   429  1020 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:39.069   429  1020 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:39.069   429  1020 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:39.069   429  1020 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:39.069   429  1020 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:39.070   429  1020 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:39.070   429  1020 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:39.070   429  1020 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:39.070   429  1020 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:39.070   429  1020 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:39.070   429  1020 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:39.070   429  1020 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:39.070   429  1020 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:39.070   429  1020 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:39.070   429  1020 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:39.070   429  1020 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:39.070   429  1020 D CCodecConfig: }
08-17 06:45:39.071   429  1020 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:39.071   429  1020 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:39.071   429  1020 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:39.071   429  1020 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:39.071   595   595 D SystemUIBootTiming: StartServicescom.android.systemui.theme.ThemeOverlayController took to complete: 3ms
08-17 06:45:39.071   429  1020 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:39.071   429  1020 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:39.071   429  1020 D CCodec  :   int32_t channel-count = 1
08-17 06:45:39.071   429  1020 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:39.071   429  1020 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:39.071   429  1020 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:39.071   429  1020 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:39.071   429  1020 D CCodec  :   int32_t channel-count = 1
08-17 06:45:39.071   429  1020 D CCodec  :   string mime = "audio/raw"
08-17 06:45:39.071   429  1020 D CCodec  :   int32_t sample-rate = 48000
08-17 06:45:39.071   429  1020 D CCodec  :   int32_t channel-mask = 1
08-17 06:45:39.071   429  1020 D CCodec  : }
08-17 06:45:39.073   429  1020 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:39.073   429  1020 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:39.074   429  1020 D CCodecBufferChannel: [c2.android.vorbis.decoder#661] Created input block pool with allocatorID 16 => poolID 21 - OK (0)
08-17 06:45:39.074   595   595 D InterruptionStateProvider: heads up is enabled
08-17 06:45:39.075   429  1020 I CCodecBufferChannel: [c2.android.vorbis.decoder#661] Created output block pool with allocatorID 16 => poolID 24 - OK
08-17 06:45:39.075   429  1020 D CCodecBufferChannel: [c2.android.vorbis.decoder#661] Configured output block pool ids 24 => OK
08-17 06:45:39.075   338  1022 D SimpleC2Component: Using output block pool with poolID 24 => got 24 - 0
08-17 06:45:39.078   673   673 D PhoneSwitcherNetworkRequstListener: got request NetworkRequest [ TRACK_DEFAULT id=14, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1001] ] with score 0 and ser
ial 0
08-17 06:45:39.086   595   595 D StatusBar: disable<e i a s b h r c s > disable2<q i n >
08-17 06:45:39.086   595   595 D SystemUIBootTiming: StartServices took to complete: 983ms
08-17 06:45:39.106   338   898 V C2Store : in ~ComponentModule
08-17 06:45:39.107   338   898 V C2Store : unloading dll
08-17 06:45:39.109   595   595 I Choreographer: Skipped 39 frames!  The application may be doing too much work on its main thread.
08-17 06:45:39.117   429  1027 D CCodec  : allocate(c2.android.vorbis.decoder)
08-17 06:45:39.118   338   898 V C2Store : in init
08-17 06:45:39.118   338   898 V C2Store : loading dll
08-17 06:45:39.121   595   907 I mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 876; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:39.121   595   907 I mali_so : arm_release_ver of this mali_so is 'r18p0-01rel0', rk_so_ver is '17@0'.
08-17 06:45:39.121   429  1027 I CCodec  : Created component [c2.android.vorbis.decoder]
08-17 06:45:39.122   595   907 D mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 881; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:39.122   595   907 D mali_so : current process is NOT sf, to bail out.
08-17 06:45:39.122   429  1027 D CCodecConfig: read media type: audio/vorbis
08-17 06:45:39.124   429  1027 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.max-count.values
08-17 06:45:39.125   429  1027 D ReflectedParamUpdater: extent() != 1 for single value type: output.subscribed-indices.values
08-17 06:45:39.125   429  1027 D ReflectedParamUpdater: extent() != 1 for single value type: input.buffers.allocator-ids.values
08-17 06:45:39.125   429  1027 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.allocator-ids.values
08-17 06:45:39.125   429  1027 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.allocator-ids.values
08-17 06:45:39.126   429  1027 D ReflectedParamUpdater: extent() != 1 for single value type: output.buffers.pool-ids.values
08-17 06:45:39.126   429  1027 D ReflectedParamUpdater: extent() != 1 for single value type: algo.buffers.pool-ids.values
08-17 06:45:39.127   429  1027 I CCodecConfig: query failed after returning 7 values (BAD_INDEX)
08-17 06:45:39.127   429  1027 D CCodecConfig: c2 config diff is Dict {
08-17 06:45:39.127   429  1027 D CCodecConfig:   c2::u32 coded.bitrate.value = 64000
08-17 06:45:39.127   429  1027 D CCodecConfig:   c2::u32 input.buffers.max-size.value = 32768
08-17 06:45:39.127   429  1027 D CCodecConfig:   c2::u32 input.delay.value = 0
08-17 06:45:39.127   429  1027 D CCodecConfig:   string input.media-type.value = "audio/vorbis"
08-17 06:45:39.127   429  1027 D CCodecConfig:   string output.media-type.value = "audio/raw"
08-17 06:45:39.127   429  1027 D CCodecConfig:   c2::u32 raw.channel-count.value = 1
08-17 06:45:39.127   429  1027 D CCodecConfig:   c2::u32 raw.sample-rate.value = 48000
08-17 06:45:39.127   429  1027 D CCodecConfig: }
08-17 06:45:39.128   429  1027 D CCodecConfig: no c2 equivalents for durationUs
08-17 06:45:39.128   429  1027 D CCodecConfig: no c2 equivalents for csd-1
08-17 06:45:39.128   429  1027 D CCodecConfig: no c2 equivalents for track-id
08-17 06:45:39.128   429  1027 D CCodecConfig: no c2 equivalents for channel-mask
08-17 06:45:39.130   429  1027 D CCodecConfig: c2 config diff is   c2::u32 raw.sample-rate.value = 44100
08-17 06:45:39.131   429  1027 W Codec2Client: query -- param skipped: index = 1107298332.
08-17 06:45:39.131   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.0::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:39.131   429  1027 D CCodec  : setup formats input: AMessage(what = 0x00000000) = {
08-17 06:45:39.131   429  1027 D CCodec  :   int32_t channel-count = 1
08-17 06:45:39.131   429  1027 D CCodec  :   int32_t max-input-size = 32768
08-17 06:45:39.131   429  1027 D CCodec  :   string mime = "audio/vorbis"
08-17 06:45:39.131   429  1027 D CCodec  :   int32_t sample-rate = 44100
08-17 06:45:39.131   429  1027 D CCodec  : } and output: AMessage(what = 0x00000000) = {
08-17 06:45:39.131   429  1027 D CCodec  :   int32_t channel-count = 1
08-17 06:45:39.131   429  1027 D CCodec  :   string mime = "audio/raw"
08-17 06:45:39.131   429  1027 D CCodec  :   int32_t sample-rate = 44100
08-17 06:45:39.131   429  1027 D CCodec  :   int32_t channel-mask = 1
08-17 06:45:39.131   429  1027 D CCodec  : }
08-17 06:45:39.133   429  1027 W Codec2Client: query -- param skipped: index = 1342179345.
08-17 06:45:39.133   429  1027 W Codec2Client: query -- param skipped: index = 2415921170.
08-17 06:45:39.135   429  1027 D CCodecBufferChannel: [c2.android.vorbis.decoder#134] Created input block pool with allocatorID 16 => poolID 22 - OK (0)
08-17 06:45:39.137   429  1027 I CCodecBufferChannel: [c2.android.vorbis.decoder#134] Created output block pool with allocatorID 16 => poolID 25 - OK
08-17 06:45:39.138   429  1027 D CCodecBufferChannel: [c2.android.vorbis.decoder#134] Configured output block pool ids 25 => OK
08-17 06:45:39.139   338  1028 D SimpleC2Component: Using output block pool with poolID 25 => got 25 - 0
08-17 06:45:39.144   595   907 D mali_winsys: EGLint new_window_surface(egl_winsys_display *, void *, EGLSurface, EGLConfig, egl_winsys_surface **, egl_color_buffer_format *, EGLBoolean) returns 0x300
0
08-17 06:45:39.145   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.145   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_516096_06:45:39.145
08-17 06:45:39.146   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.146   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_516096_06:45:39.146
08-17 06:45:39.147   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.147   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_516096_06:45:39.147
08-17 06:45:39.148   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.mapper@3.0::IMapper/default in either framework or device manifest.
08-17 06:45:39.150   595   907 W Gralloc3: mapper 3.x is not supported
08-17 06:45:39.153   595   907 D GRALLOC-ROCKCHIP: RK_GRAPHICS_VER=commit-id:344c4dd
08-17 06:45:39.163   595   907 I OpenGLRenderer: Davey! duration=712ms; Flags=1, IntendedVsync=11883583710, Vsync=12533583684, OldestInputEvent=9223372036854775807, NewestInputEvent=0, HandleInputStar
t=12545068213, AnimationStart=12545106130, PerformTraversalsStart=12545258380, DrawStart=12580738755, SyncQueued=12580866213, SyncStart=12583161755, IssueDrawCommandsStart=12583232046, SwapBuffers=125
97269380, FrameCompleted=12598563213, DequeueBufferDuration=207000, QueueBufferDuration=544000,
08-17 06:45:39.163   338   898 V C2Store : in ~ComponentModule
08-17 06:45:39.163   338   898 V C2Store : unloading dll
08-17 06:45:39.168   595   595 D KeyguardClockSwitch: Updating clock: 6:45鈥夾M
08-17 06:45:39.184   595   809 E ActivityThread: Failed to find provider info for com.android.contacts
08-17 06:45:39.199   595   809 E ActivityThread: Failed to find provider info for com.android.contacts
08-17 06:45:39.219   595   907 D mali_winsys: EGLint new_window_surface(egl_winsys_display *, void *, EGLSurface, EGLConfig, egl_winsys_surface **, egl_color_buffer_format *, EGLBoolean) returns 0x300
0
08-17 06:45:39.220   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.220   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_258048_06:45:39.220
08-17 06:45:39.221   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.221   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_258048_06:45:39.221
08-17 06:45:39.222   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.222   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_258048_06:45:39.222
08-17 06:45:39.230   595   907 I OpenGLRenderer: Davey! duration=782ms; Flags=1, IntendedVsync=11883583710, Vsync=12533583684, OldestInputEvent=9223372036854775807, NewestInputEvent=0, HandleInputStar
t=12545068213, AnimationStart=12545106130, PerformTraversalsStart=12545258380, DrawStart=12663972546, SyncQueued=12664129463, SyncStart=12664428421, IssueDrawCommandsStart=12664460213, SwapBuffers=126
65574380, FrameCompleted=12666337088, DequeueBufferDuration=77000, QueueBufferDuration=299000,
08-17 06:45:39.345   595   595 D ImageWallpaperRenderer: loadBitmap: mBitmap=null
08-17 06:45:39.547   595   595 D ImageWallpaperRenderer: loadBitmap done, surface size=Rect(0, 0 - 2880, 2560)
08-17 06:45:39.555   595   595 D ImageWallpaper: wallpaper visibility changes to: true
08-17 06:45:39.555   595   595 D ImageWallpaper: wallpaper visibility changes to: false
08-17 06:45:39.558   595   803 D mali_winsys: EGLint new_window_surface(egl_winsys_display *, void *, EGLSurface, EGLConfig, egl_winsys_surface **, egl_color_buffer_format *, EGLBoolean) returns 0x300
0
08-17 06:45:39.562   595   803 D         : set stream to NULL
08-17 06:45:39.568   595   803 I chatty  : uid=10082(com.android.systemui) ImageWallpaper identical 1 line
08-17 06:45:39.584   595   803 D         : set stream to NULL
08-17 06:45:39.584   595   803 D ImageWallpaperRenderer: loadBitmap: mBitmap=android.graphics.Bitmap@e25c01c
08-17 06:45:39.584   595   803 D ImageWallpaperRenderer: loadBitmap done, surface size=Rect(0, 0 - 2880, 2560)
08-17 06:45:39.584   595   803 W ndroid.systemu: Core platform API violation: Ljava/nio/Buffer;->position:I from Landroid/opengl/GLES20; using JNI
08-17 06:45:39.584   595   803 W ndroid.systemu: Core platform API violation: Ljava/nio/Buffer;->limit:I from Landroid/opengl/GLES20; using JNI
08-17 06:45:39.584   595   803 W ndroid.systemu: Core platform API violation: Ljava/nio/Buffer;->_elementSizeShift:I from Landroid/opengl/GLES20; using JNI
08-17 06:45:39.584   595   803 W ndroid.systemu: Core platform API violation: Ljava/nio/Buffer;->address:J from Landroid/opengl/GLES20; using JNI
08-17 06:45:39.595   673   690 W System  : A resource failed to call end.
08-17 06:45:39.603   595   595 V StatusBar: mStatusBarWindow: com.android.systemui.statusbar.phone.StatusBarWindowView{956052c V.E...... ........ 0,0-1536,42} canPanelBeCollapsed(): false
08-17 06:45:39.603   595   595 D Tonal   : Tonal Palette - index: 10. Main color: ffeb9aa9
08-17 06:45:39.603   595   595 D Tonal   : Colors: ff140409, ff290813, ff3e0c1f, ff58112c, ff771841, ff971e46, ffb72455, ffc8537a, ffe06283, ffe57c95, ffeb9aa9, fff3c5cc, fff9e2e7
08-17 06:45:39.603   595   595 D Tonal   : Gradients:
08-17 06:45:39.603   595   595 D Tonal   :      Normal GradientColors(ffeb9aa9, ffeb9aa9)
08-17 06:45:39.603   595   595 D Tonal   :      Dark GradientColors(ff58112c, ff58112c)
08-17 06:45:39.603   595   595 D Tonal   :      Extra dark: GradientColors(ff3e0c1f, ff3e0c1f)
08-17 06:45:39.604   595   595 D Tonal   : Tonal Palette - index: 10. Main color: ffeb9aa9
08-17 06:45:39.604   595   595 D Tonal   : Colors: ff140409, ff290813, ff3e0c1f, ff58112c, ff771841, ff971e46, ffb72455, ffc8537a, ffe06283, ffe57c95, ffeb9aa9, fff3c5cc, fff9e2e7
08-17 06:45:39.604   595   595 D Tonal   : Gradients:
08-17 06:45:39.604   595   595 D Tonal   :      Normal GradientColors(ffeb9aa9, ffeb9aa9)
08-17 06:45:39.604   595   595 D Tonal   :      Dark GradientColors(ff58112c, ff58112c)
08-17 06:45:39.604   595   595 D Tonal   :      Extra dark: GradientColors(ff3e0c1f, ff3e0c1f)
08-17 06:45:39.605   156   156 E Cryptfs : cryptfs_get_password not valid for file encryption
08-17 06:45:39.615   595   595 D KeyguardClockSwitch: Updating clock: 6:45鈥夾M
08-17 06:45:39.621   595   595 I Choreographer: Skipped 30 frames!  The application may be doing too much work on its main thread.
08-17 06:45:39.655   595   595 D StatusBar: disable<e i a s b H!R!c s > disable2<q i n >
08-17 06:45:39.660   595   595 V StatusBar/NavBarView: PW=1536, PH=2048
08-17 06:45:39.677   595   803 D ImageWallpaper: onSurfaceChanged: w=2880, h=2560
08-17 06:45:39.677   595   803 D ImageWallpaper: onSurfaceRedrawNeeded: mNeedRedraw=true
08-17 06:45:39.677   595   803 D ImageWallpaper: preRender start
08-17 06:45:39.677   595   803 D ImageWallpaper: preRender end
08-17 06:45:39.679   595   907 D         : set stream to NULL
08-17 06:45:39.698   595   907 I chatty  : uid=10082(com.android.systemui) RenderThread identical 5 lines
08-17 06:45:39.699   595   907 D         : set stream to NULL
08-17 06:45:39.713   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.713   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_29491200_06:45:39.713
08-17 06:45:39.720   595   803 D ImageWallpaper: postRender start
08-17 06:45:39.721   595   803 D ImageWallpaper: postRender end
08-17 06:45:39.731   595   803 D ImageWallpaper: onSurfaceRedrawNeeded: mNeedRedraw=false
08-17 06:45:39.737   595   595 V KeyguardUpdateMonitor: onSubscriptionInfoChanged()
08-17 06:45:39.752   595   595 I chatty  : uid=10082(com.android.systemui) identical 5 lines
08-17 06:45:39.755   595   595 V KeyguardUpdateMonitor: onSubscriptionInfoChanged()
08-17 06:45:39.770   595   595 D StatusBar: updateQsExpansionEnabled - QS Expand enabled: true
08-17 06:45:39.776   595   595 D StatusBar: disable<e i a s b H R c s > disable2<q i n >
08-17 06:45:39.777   595   595 I chatty  : uid=10082(com.android.systemui) identical 2 lines
08-17 06:45:39.782   595   595 D StatusBar: disable<e i a s b H R c s > disable2<q i n >
08-17 06:45:39.782   595   595 D KeyguardUpdateMonitor: onKeyguardVisibilityChanged(true)
08-17 06:45:39.783   595   595 D KeyguardClockSwitch: Updating clock: 6:45鈥夾M
08-17 06:45:39.784   595   595 D StatusBar: disable<e i a s b H R c s > disable2<q i n >
08-17 06:45:39.803   174   422 E BufferQueueProducer: [StatusBar#0] disconnect: not connected (req=1)
08-17 06:45:39.804   595   907 W libEGL  : EGLNativeWindowType 0x732241cad0 disconnect failed
08-17 06:45:39.805   595   907 D mali_winsys: EGLint new_window_surface(egl_winsys_display *, void *, EGLSurface, EGLConfig, egl_winsys_surface **, egl_color_buffer_format *, EGLBoolean) returns 0x300
0
08-17 06:45:39.805   595   595 W View    : requestLayout() improperly called by com.android.keyguard.CarrierText{abf7b3 V.ED..... ..S...ID 42,0-1384,105 #7f0a01d6 app:id/keyguard_carrier_text} during
layout: running second layout pass
08-17 06:45:39.822   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.822   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:39.822
08-17 06:45:39.829   595   907 D         : set stream to NULL
08-17 06:45:39.872   595   907 I chatty  : uid=10082(com.android.systemui) RenderThread identical 3 lines
08-17 06:45:39.873   595   907 D         : set stream to NULL
08-17 06:45:39.877   174   905 E BufferQueueProducer: [NavigationBar0#0] disconnect: not connected (req=1)
08-17 06:45:39.877   595   907 W libEGL  : EGLNativeWindowType 0x732241ba90 disconnect failed
08-17 06:45:39.886   265   265 I SensorsHal: set batch: handle = 0, period_ns = 66667000ns, timeout = 100000000ns
08-17 06:45:39.887   265   265 I SensorsHal: MmaSensor update delay: 66ms
08-17 06:45:39.887   265   265 D SensorsHal: update gsensor delay to 66 ms
08-17 06:45:39.887   265   265 I SensorsHal: set active: handle = 0, enable = 1
08-17 06:45:39.975   595   595 D ImageWallpaper: wallpaper visibility changes to: true
08-17 06:45:39.983   595   803 D ImageWallpaper: onSurfaceRedrawNeeded: mNeedRedraw=false
08-17 06:45:39.984   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:39.984   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:39.984
08-17 06:45:40.010   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:40.010   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:40.010
08-17 06:45:40.019   174   184 E BufferQueueProducer: [BootAnimation#0] disconnect: not connected (req=1)
08-17 06:45:40.020   175   405 W libEGL  : EGLNativeWindowType 0x782b86e010 disconnect failed
08-17 06:45:40.021   175   175 D BootAnimation: BootAnimationStopTiming start time: 13456ms
08-17 06:45:40.206   429   452 I WindowManager: ******* TELLING SURFACE FLINGER WE ARE BOOTED!
08-17 06:45:40.206   174   184 I SurfaceFlinger: Boot is finished (9949 ms)
08-17 06:45:40.210   429   452 I ActivityManager: About to commit checkpoint
08-17 06:45:40.211   429   452 I SystemServiceManager: Starting phase 1000
08-17 06:45:40.212   429   466 V DisplayPowerController: Brightness [120] reason changing to: 'manual', previous reason: 'override'.
08-17 06:45:40.213   429   452 D TestHarnessModeService: Completing Test Harness Mode setup.
08-17 06:45:40.213   429   452 D TestHarnessModeService: Getting PersistentDataBlockManagerInternal from LocalServices
08-17 06:45:40.213   429   452 E TestHarnessModeService: Failed to start Test Harness Mode; no implementation of PersistentDataBlockManagerInternal was bound!
08-17 06:45:40.213   429   527 D StorageManagerService: Thinking about init, mBootCompleted=true, mDaemonConnected=true
08-17 06:45:40.213   429   527 D StorageManagerService: Thinking about reset, mBootCompleted=true, mDaemonConnected=true
08-17 06:45:40.214   429   452 D WifiService: Handle boot completed
08-17 06:45:40.216   429   537 I WifiScoreCard: Installing MemoryStore
08-17 06:45:40.216   429   458 I ActivityManager: Force stopping com.android.providers.media appid=10040 user=-1: vold reset
08-17 06:45:40.218   429   698 V StorageManagerService: Found primary storage at VolumeInfo{emulated}:
08-17 06:45:40.218   429   698 V StorageManagerService:     type=EMULATED diskId=null partGuid= mountFlags=0 mountUserId=-10000
08-17 06:45:40.218   429   698 V StorageManagerService:     state=UNMOUNTED
08-17 06:45:40.218   429   698 V StorageManagerService:     fsType=null fsUuid=null fsLabel=null
08-17 06:45:40.218   429   698 V StorageManagerService:     path=null internalPath=null
08-17 06:45:40.222   156   156 D vold    : Waiting for FUSE to spin up...
08-17 06:45:40.222   429   537 D WifiConfigStore: Reading from all stores completed in 6 ms.
08-17 06:45:40.225   429   452 D ActivityManager: Finishing user boot 0
08-17 06:45:40.226   429   452 I ActivityManager: User 0 state changed from BOOTING to RUNNING_LOCKED
08-17 06:45:40.228   429   452 D StorageManagerService: unlockUserKey: 0
08-17 06:45:40.229   156   166 D vold    : fscrypt_unlock_user_key 0 serial=0 token_present=0
08-17 06:45:40.231   156   166 D vold    : Skipping non-key ..
08-17 06:45:40.231   156   166 D vold    : Skipping non-key .
08-17 06:45:40.231   156   166 D vold    : Trying user CE key /data/misc/vold/user_keys/ce/0/current
08-17 06:45:40.239  1047  1047 W sdcard  : Device explicitly enabled sdcardfs
08-17 06:45:40.239   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.keymaster@4.0::IKeymasterDevice/default in either framework or device manifest.
08-17 06:45:40.242   156   166 I vold    : List of Keymaster HALs found:
08-17 06:45:40.242   156   166 I vold    : Keymaster HAL #1: SoftwareWrappedKeymaster2Device from Google SecurityLevel: TRUSTED_ENVIRONMENT HAL: android.hardware.keymaster@3.0::IKeymasterDevice/defaul
t
08-17 06:45:40.242   156   166 I vold    : Using SoftwareWrappedKeymaster2Device from Google for encryption.  Security level: TRUSTED_ENVIRONMENT, HAL: android.hardware.keymaster@3.0::IKeymasterDevice
/default
08-17 06:45:40.244   156   166 D RefBase : RefBase: Explicit destruction, weak count = 0 (in 0x6fe823b0f0)
08-17 06:45:40.244   156   166 W RefBase : CallStack::getCurrentInternal not linked, returning null
08-17 06:45:40.244   156   166 W RefBase : CallStack::logStackInternal not linked
08-17 06:45:40.244   156   166 D vold    : Successfully retrieved key
08-17 06:45:40.249   156   166 D vold    : Added key 624848880 (ext4:9fc85034234bcf24) to keyring 270648699 in process 156
08-17 06:45:40.249   156   166 D vold    : Added key 775737112 (f2fs:9fc85034234bcf24) to keyring 270648699 in process 156
08-17 06:45:40.249   156   166 D vold    : Added key 200035326 (fscrypt:9fc85034234bcf24) to keyring 270648699 in process 156
08-17 06:45:40.249   156   166 D vold    : Installed ce key for user 0
08-17 06:45:40.249   429   452 D ActivityManager: Started unlocking user 0
08-17 06:45:40.249   429   452 D ActivityManager: Unlocking user 0 progress 0
08-17 06:45:40.249   429   452 D ActivityManager: Unlocking user 0 progress 5
08-17 06:45:40.251   156   164 D vold    : fscrypt_prepare_user_storage for volume null, user 0, serial 0, flags 2
08-17 06:45:40.251   156   164 D vold    : Preparing: /data/system_ce/0
08-17 06:45:40.251   156   164 D vold    : Preparing: /data/misc_ce/0
08-17 06:45:40.251   156   164 D vold    : Preparing: /data/vendor_ce/0
08-17 06:45:40.251   156   164 D vold    : Preparing: /data/media/0
08-17 06:45:40.252   156   164 D vold    : Preparing: /data/data
08-17 06:45:40.253   156   164 I vold    : Found policy 9fc85034234bcf24 at /data/system_ce/0 which matches expected value
08-17 06:45:40.254   156   164 I vold    : Found policy 9fc85034234bcf24 at /data/misc_ce/0 which matches expected value
08-17 06:45:40.254   156   164 I vold    : Found policy 9fc85034234bcf24 at /data/vendor_ce/0 which matches expected value
08-17 06:45:40.255   429   452 D ColorDisplayService: setUp: currentUser=0
08-17 06:45:40.255   156   164 I vold    : Found policy 9fc85034234bcf24 at /data/media/0 which matches expected value
08-17 06:45:40.256   156   164 I vold    : Found policy 9fc85034234bcf24 at /data/data which matches expected value
08-17 06:45:40.256   156   164 D vold    : Starting restorecon of /data/system_ce/0
08-17 06:45:40.258   429   537 D WifiNetworkFactory: Registering NetworkFactory
08-17 06:45:40.258   429   537 D UntrustedWifiNetworkFactory: Registering NetworkFactory
08-17 06:45:40.258   429   540 D ConnectivityService: Got NetworkFactory Messenger for WifiNetworkFactory
08-17 06:45:40.258   429   540 D ConnectivityService: Got NetworkFactory Messenger for UntrustedWifiNetworkFactory
08-17 06:45:40.258   429   537 D WifiNetworkFactory: got request NetworkRequest [ BACKGROUND_REQUEST id=2, [ Transports: CELLULAR Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0
and serial -1
08-17 06:45:40.258   429   537 D WifiNetworkFactory: got request NetworkRequest [ TRACK_DEFAULT id=11, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 10082] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D WifiNetworkFactory: got request NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D WifiNetworkFactory: got request NetworkRequest [ TRACK_DEFAULT id=9, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1000] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D WifiNetworkFactory: got request NetworkRequest [ TRACK_DEFAULT id=14, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1001] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D WifiNetworkFactory: got request NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D UntrustedWifiNetworkFactory: got request NetworkRequest [ BACKGROUND_REQUEST id=2, [ Transports: CELLULAR Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with
 score 0 and serial -1
08-17 06:45:40.259   429   537 D UntrustedWifiNetworkFactory: got request NetworkRequest [ TRACK_DEFAULT id=11, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 10082] ] with score 0 and serial -1

08-17 06:45:40.259   429   537 D UntrustedWifiNetworkFactory: got request NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D UntrustedWifiNetworkFactory: got request NetworkRequest [ TRACK_DEFAULT id=9, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1000] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D UntrustedWifiNetworkFactory: got request NetworkRequest [ TRACK_DEFAULT id=14, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1001] ] with score 0 and serial -1
08-17 06:45:40.259   429   537 D UntrustedWifiNetworkFactory: got request NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ] with score 0 and serial -1
08-17 06:45:40.271   156   164 D vold    : Finished restorecon of /data/system_ce/0
08-17 06:45:40.271   156   164 D vold    : Starting restorecon of /data/vendor_ce/0
08-17 06:45:40.273   243   243 D Zygote  : Forked child process 1051
08-17 06:45:40.276   429   459 I ActivityManager: Start proc 1051:com.android.deskclock/u0a86 for broadcast {com.android.deskclock/com.android.deskclock.AlarmInitReceiver}
08-17 06:45:40.280   156   164 D vold    : Finished restorecon of /data/vendor_ce/0
08-17 06:45:40.280   156   164 D vold    : Starting restorecon of /data/misc_ce/0
08-17 06:45:40.306  1058  1058 I bootstat: Service started: /system/bin/bootstat --record_boot_complete --record_boot_reason --record_time_since_factory_reset -l
08-17 06:45:40.307  1058  1058 E bootstat: Failed to read /data/misc/bootstat/post_decrypt_time_elapsed: No such file or directory
08-17 06:45:40.307  1058  1058 E bootstat: Failed to parse boot time record: /data/misc/bootstat/post_decrypt_time_elapsed
08-17 06:45:40.330  1051  1051 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:40.330  1051  1051 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:40.330  1051  1051 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:40.360   156   164 D vold    : Finished restorecon of /data/misc_ce/0
08-17 06:45:40.360   156   164 D vold    : /system/bin/vold_prepare_subdirs
08-17 06:45:40.360   156   164 D vold    :     prepare
08-17 06:45:40.360   156   164 D vold    :
08-17 06:45:40.360   156   164 D vold    :     0
08-17 06:45:40.360   156   164 D vold    :     2
08-17 06:45:40.389  1075  1075 D vold_prepare_subdirs: Setting up mode 700 uid 0 gid 0 context u:object_r:vold_data_file:s0 on path: /data/misc_ce/0/vold
08-17 06:45:40.390  1075  1075 D vold_prepare_subdirs: Setting up mode 700 uid 0 gid 0 context u:object_r:storaged_data_file:s0 on path: /data/misc_ce/0/storaged
08-17 06:45:40.400   248   312 D AudioHardwareTiny: adev_set_parameters: kvpairs = A2dpSuspended=false
08-17 06:45:40.401   248   312 D AudioHardwareTiny: adev_set_parameters: kvpairs = BT_SCO=off
08-17 06:45:40.418   595   595 D InterruptionStateProvider: No heads up: unimportant notification: -1|android|26|null|1000
08-17 06:45:40.478  1075  1075 D vold_prepare_subdirs: Setting up mode 700 uid 0 gid 0 context u:object_r:rollback_data_file:s0 on path: /data/misc_ce/0/rollback
08-17 06:45:40.482  1075  1075 D vold_prepare_subdirs: Setting up mode 700 uid 1000 gid 1000 context u:object_r:backup_data_file:s0 on path: /data/system_ce/0/backup
08-17 06:45:40.485  1075  1075 D vold_prepare_subdirs: Setting up mode 700 uid 1000 gid 1000 context u:object_r:backup_data_file:s0 on path: /data/system_ce/0/backup_stage
08-17 06:45:40.485  1075  1075 D vold_prepare_subdirs: Setting up mode 700 uid 1000 gid 1000 context u:object_r:face_vendor_data_file:s0 on path: /data/vendor_ce/0/facedata
08-17 06:45:40.488   429   449 V UserDataPreparer: Found /data/user/0 with serial number 0
08-17 06:45:40.488   429   449 V UserDataPreparer: Found /data/system_ce/0 with serial number 0
08-17 06:45:40.488   429   449 D UserDataPreparer: Setting property: sys.user.0.ce_available=true
08-17 06:45:40.489   429   449 V PackageManager: reconcileAppsData for null u0 0x2 migrateAppData=false
08-17 06:45:40.513   429   546 D NotificationSQLiteLog: Pruned event entries: 0
08-17 06:45:40.555  1051  1051 I AlarmClock: AlarmInitReceiver android.intent.action.LOCKED_BOOT_COMPLETED
08-17 06:45:40.564  1051  1080 I AlarmClock: Fixing alarm instances
08-17 06:45:40.606   595   595 W View    : requestLayout() improperly called by android.widget.FrameLayout{927b58e I.E...... ......I. 0,0-0,0 #7f0a00a6 app:id/big_clock_container} during layout: runni
ng second layout pass
08-17 06:45:40.636   595   907 D         : set stream to NULL
08-17 06:45:40.637   595   907 I chatty  : uid=10082(com.android.systemui) RenderThread identical 1 line
08-17 06:45:40.640   595   907 D         : set stream to NULL
08-17 06:45:40.640  1051  1080 V AlarmClock: AlarmInitReceiver finished
08-17 06:45:40.669   429   457 I system_server: Using smaps_rollup for pss collection
08-17 06:45:40.681   263   263 W memtrack@1.0-se: type=1400 audit(0.0:43): avc: denied { read } for name="mem_profile" dev="debugfs" ino=188 scontext=u:r:hal_memtrack_default:s0 tcontext=u:object_r:de
bugfs:s0 tclass=file permissive=0
08-17 06:45:40.694   595   907 D         : set stream to NULL
08-17 06:45:40.720   429   449 V PackageManager: reconcileAppsData finished 123 packages
08-17 06:45:40.720   429   449 I ActivityManager: User 0 state changed from RUNNING_LOCKED to RUNNING_UNLOCKING
08-17 06:45:40.720   429   449 D ActivityManager: Unlocking user 0 progress 20
08-17 06:45:40.720   429   449 W Looper  : Slow dispatch took 470ms android.fg h=android.os.Handler c=com.android.server.am.-$$Lambda$UserController$stQk1028ON105v_u-VMykVjcxLk@536928 m=0
08-17 06:45:40.720   429   449 W Looper  : Slow delivery took 471ms android.fg h=android.os.Handler c=com.android.server.am.-$$Lambda$UserController$G0WJmqt4X_QG30fRlvXobn18mrE@a7e2641 m=0
08-17 06:45:40.721   429   458 I SystemServiceManager: Calling onUnlockUser u0
08-17 06:45:40.721   595   803 D ImageWallpaper: finishRendering, preserve=true
08-17 06:45:40.722   322   322 D installd: Found quota mount /dev/block/by-name/userdata at /data
08-17 06:45:40.722   429   449 W Looper  : Drained
08-17 06:45:40.722   322   322 D installd: Found storage mount /data/media at /mnt/runtime/default/emulated
08-17 06:45:40.723   174   422 E BufferQueueProducer: [com.android.systemui.ImageWallpaper#0] disconnect: not connected (req=1)
08-17 06:45:40.723   595   803 W libEGL  : EGLNativeWindowType 0x72ad868010 disconnect failed
08-17 06:45:40.726   429   458 D BluetoothManagerService: User 0 unlocked
08-17 06:45:40.727   429   451 D BluetoothManagerService: MESSAGE_USER_UNLOCKED
08-17 06:45:40.727   429   458 D StorageManagerService: onUnlockUser 0
08-17 06:45:40.727   156   164 D vold    : Linking /storage/emulated/0 to /mnt/user/0/primary
08-17 06:45:40.755   429   458 D WifiService: Handle user unlock 0
08-17 06:45:40.759   429   458 W VoiceInteractionManagerService: no available voice interaction services found for user 0
08-17 06:45:40.759   429   458 W VoiceInteractionManagerService: no available voice recognition services found for user 0
08-17 06:45:40.760   429   537 D WakeupConfigStoreData: WifiWake user data has been read
08-17 06:45:40.761   429   537 D WifiConfigStore: Reading from user stores completed in 4 ms.
08-17 06:45:40.763   909   909 I InputAttributes: InputType.TYPE_NULL is specified
08-17 06:45:40.763   429   450 D AutofillUI: destroySaveUiUiThread(): already destroyed
08-17 06:45:40.764   429   458 D AutofillManagerServiceImpl: Reset component for user 0:
08-17 06:45:40.764   429   458 D FieldClassificationStrategy: reset(): service is not bound. Do nothing.
08-17 06:45:40.764   429   458 W AppBindingService: [Default SMS app] u0 Target package not found
08-17 06:45:40.766   429   449 I ActivityTaskManager: Loading recents for user 0 into memory.
08-17 06:45:40.766   429   458 I ActivityManager: User 0 state changed from RUNNING_UNLOCKING to RUNNING_UNLOCKED
08-17 06:45:40.767   429   458 D SystemServerTiming: SystemUserUnlock took to complete: 517ms
08-17 06:45:40.773   429   557 I BackupManagerService: Starting service for user: 0
08-17 06:45:40.774   429   458 V ActivityManager: Installing ContentProviderInfo{name=com.android.launcher3 className=com.android.quickstep.LauncherSearchIndexablesProvider}
08-17 06:45:40.775   429   458 V ActivityManager: Installing ContentProviderInfo{name=com.android.launcher3.settings className=com.android.launcher3.LauncherProvider}
08-17 06:45:40.776   429   458 I ActivityManager: Posting BOOT_COMPLETED user #0
08-17 06:45:40.781   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:40.787   429   537 D WifiConfigStore: Writing to stores completed in 22 ms.
08-17 06:45:40.794   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:40.796   429   557 V BackupManagerService: Starting with transport com.android.localtransport/.LocalTransport
08-17 06:45:40.797   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:40.807   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:40.807   673   673 D CarrierSvcBindHelper: Received android.intent.action.USER_UNLOCKED
08-17 06:45:40.807   429   429 V NotificationAssistants: disabling notification assistant for user 0: ComponentInfo{android.ext.services/android.ext.services.notification.Assistant}
08-17 06:45:40.808   429   429 D NotificationListeners: Removing active service ComponentInfo{android.ext.services/android.ext.services.notification.Assistant}
08-17 06:45:40.808   673   673 E PhoneInterfaceManager: [PhoneIntfMgr] getCarrierPackageNamesForIntent: No UICC
08-17 06:45:40.808   673   673 D CarrierSvcBindHelper: No carrier app for: 0
08-17 06:45:40.808   429   557 D BackupManagerService: Started thread backup-0 for user 0
08-17 06:45:40.808   764   764 D FallbackHome: User unlocked and real home found; let's go!
08-17 06:45:40.809   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:40.814   243   243 D Zygote  : Forked child process 1091
08-17 06:45:40.818   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:40.825   429   429 V NotificationAssistants: enabling notification assistant for 0: ComponentInfo{android.ext.services/android.ext.services.notification.Assistant}
08-17 06:45:40.825   429   429 V NotificationAssistants: binding: Intent { act=android.service.notification.NotificationAssistantService cmp=android.ext.services/.notification.Assistant (has extras) }

08-17 06:45:40.828   429   459 W ActivityManager: Slow operation: 56ms so far, now at startProcess: returned from zygote!
08-17 06:45:40.836   429   459 W ActivityManager: Slow operation: 63ms so far, now at startProcess: done updating battery stats
08-17 06:45:40.836   429   459 W ActivityManager: Slow operation: 64ms so far, now at startProcess: building log message
08-17 06:45:40.836   429   459 I ActivityManager: Start proc 1091:com.android.se/1068 for added application com.android.se
08-17 06:45:40.836   429   459 W ActivityManager: Slow operation: 64ms so far, now at startProcess: starting to update pids map
08-17 06:45:40.838   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:40.839   429   459 W ActivityManager: Slow operation: 66ms so far, now at startProcess: done updating pids map
08-17 06:45:40.839   429   459 W ActivityManager: Slow operation: 65ms so far, now at startProcess: asking zygote to start proc
08-17 06:45:40.841   429   429 V NotificationListeners: enabling notification listener for 0: ComponentInfo{com.android.launcher3/com.android.launcher3.notification.NotificationListener}
08-17 06:45:40.842   429   429 V NotificationListeners: binding: Intent { act=android.service.notification.NotificationListenerService cmp=com.android.launcher3/.notification.NotificationListener (has
 extras) }
08-17 06:45:40.865   243   243 D Zygote  : Forked child process 1107
08-17 06:45:40.870   429   459 W ActivityManager: Slow operation: 97ms so far, now at startProcess: returned from zygote!
08-17 06:45:40.870   429   459 W ActivityManager: Slow operation: 97ms so far, now at startProcess: done updating battery stats
08-17 06:45:40.870   429   459 W ActivityManager: Slow operation: 97ms so far, now at startProcess: building log message
08-17 06:45:40.870   429   459 I ActivityManager: Start proc 1107:com.cghs.stresstest/1000 for added application com.cghs.stresstest
08-17 06:45:40.871   429   459 W ActivityManager: Slow operation: 97ms so far, now at startProcess: starting to update pids map
08-17 06:45:40.872   429   447 I ActivityTaskManager: START u0 {act=android.intent.action.MAIN cat=[android.intent.category.HOME] flg=0x10000100 cmp=com.android.launcher3/.Launcher} from uid 0
08-17 06:45:40.872   429   429 I AccountManagerService: User 0 is unlocked - opening CE database
08-17 06:45:40.896   429   572 I SyncManager: Loaded persisted syncs: 0 periodic syncs, 0 oneshot syncs, 12 total system server jobs, JobStats: FirstLoad: 2/2/0 LastSave: -1/-1/-1
08-17 06:45:40.902   429   459 W ActivityManager: Slow operation: 129ms so far, now at startProcess: done updating pids map
08-17 06:45:40.902   429   452 I ActivityTaskManager: getPackageFerformanceMode--ComponentInfo{com.android.launcher3/com.android.launcher3.Launcher}----com.android.launcher3
08-17 06:45:40.902   429   459 W ActivityManager: Slow operation: 77ms so far, now at startProcess: asking zygote to start proc
08-17 06:45:40.912   429   429 V NotificationAssistants: 0 notification assistant service connected: ComponentInfo{android.ext.services/android.ext.services.notification.Assistant}
08-17 06:45:40.917   849  1003 D ExtAssistant: File doesn't exist or isn't readable yet
08-17 06:45:40.919   429   557 I SELinux : SELinux: Loaded file_contexts
08-17 06:45:40.926   429   557 E BackupPasswordManager: Unable to read backup pw version
08-17 06:45:40.927   429   557 E BackupPasswordManager: Unable to read saved backup pw hash
08-17 06:45:40.938   243   243 D Zygote  : Forked child process 1139
08-17 06:45:40.946   263   263 W memtrack@1.0-se: type=1400 audit(0.0:44): avc: denied { read } for name="mem_profile" dev="debugfs" ino=22264 scontext=u:r:hal_memtrack_default:s0 tcontext=u:object_r:
debugfs:s0 tclass=file permissive=0
08-17 06:45:40.955   429   459 W ActivityManager: Slow operation: 130ms so far, now at startProcess: returned from zygote!
08-17 06:45:40.956   429   459 W ActivityManager: Slow operation: 130ms so far, now at startProcess: done updating battery stats
08-17 06:45:40.960  1107  1107 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:40.960  1107  1107 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:40.960  1107  1107 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:40.963   429   459 W ActivityManager: Slow operation: 138ms so far, now at startProcess: building log message
08-17 06:45:40.963   429   459 I ActivityManager: Start proc 1139:com.android.smspush/u0a71 for service {com.android.smspush/com.android.smspush.WapPushManager}
08-17 06:45:40.963   429   459 W ActivityManager: Slow operation: 138ms so far, now at startProcess: starting to update pids map
08-17 06:45:40.963   429   459 W ActivityManager: Slow operation: 138ms so far, now at startProcess: done updating pids map
08-17 06:45:40.963  1107  1107 I cghs.stresstes: The ClassLoaderContext is a special shared library.
08-17 06:45:40.964   429   429 V NotificationListeners: 0 notification listener service connected: ComponentInfo{com.android.launcher3/com.android.launcher3.notification.NotificationListener}
08-17 06:45:40.976   838   838 D TouchInteractionService: Touch service connected
08-17 06:45:40.978   429   557 V BackupManagerService: No ancestral data
08-17 06:45:41.000   429  1090 V BackupManagerConstants: getKeyValueBackupIntervalMilliseconds(...) returns 14400000
08-17 06:45:41.007   429  1090 V BackupManagerConstants: getKeyValueBackupFuzzMilliseconds(...) returns 600000
08-17 06:45:41.007   429  1090 V BackupManagerConstants: getKeyValueBackupRequiredNetworkType(...) returns 1
08-17 06:45:41.007   429  1090 V BackupManagerConstants: getKeyValueBackupRequireCharging(...) returns true
08-17 06:45:41.007   429  1090 V KeyValueBackupJob: Scheduling k/v pass in 242 minutes
08-17 06:45:41.020  1091  1091 I SecureElementService: main onCreate
08-17 06:45:41.021   429   449 I AppWidgetServiceImpl: Processing of handleUserUnlocked u0 took 245 ms
08-17 06:45:41.021   429   449 W Looper  : Slow dispatch took 246ms android.fg h=android.os.Handler c=com.android.server.am.-$$Lambda$UserController$Injector$MYTLl7MOQKjyMJknWdxPeBLoPCc@82b0d66 m=0
08-17 06:45:41.025   429   449 W Looper  : Slow delivery took 245ms android.fg h=android.os.Handler c=com.android.server.am.-$$Lambda$UserController$I0p0bKjuvsSPLZB71mKQFfdUjZ4@b4df8a7 m=0
08-17 06:45:41.028   429   449 W Looper  : Drained
08-17 06:45:41.029   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.secure_element@1.1::ISecureElement/eSE1 in either framework or device manifest.
08-17 06:45:41.030  1091  1091 D SecureElement-Terminal-eSE1: SE Hal V1.1 is not supported
08-17 06:45:41.032   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.secure_element@1.0::ISecureElement/eSE1 in either framework or device manifest.
08-17 06:45:41.033  1091  1091 I SecureElementService: No HAL implementation for eSE1
08-17 06:45:41.034   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.secure_element@1.1::ISecureElement/SIM1 in either framework or device manifest.
08-17 06:45:41.036  1091  1091 D SecureElement-Terminal-SIM1: SE Hal V1.1 is not supported
08-17 06:45:41.037   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.secure_element@1.0::ISecureElement/SIM1 in either framework or device manifest.
08-17 06:45:41.038  1091  1091 I SecureElementService: No HAL implementation for SIM1
08-17 06:45:41.039   595   907 D         : set stream to NULL
08-17 06:45:41.046   243   243 D Zygote  : Forked child process 1169
08-17 06:45:41.047   429   557 I BackupManagerService: Backup enabled => false
08-17 06:45:41.054  1163  1163 I migrate_legacy_obb_data: No legacy obb data to migrate.
08-17 06:45:41.058   429   527 D StorageManagerService: Volume emulated broadcasting mounted to UserHandle{0}
08-17 06:45:41.060   429   459 I ActivityManager: Start proc 1169:com.android.quicksearchbox/u0a89 for broadcast {com.android.quicksearchbox/com.android.quicksearchbox.SearchWidgetProvider}
08-17 06:45:41.073   429  1090 V BackupManagerConstants: getKeyValueBackupIntervalMilliseconds(...) returns 14400000
08-17 06:45:41.073   429  1090 V BackupManagerConstants: getKeyValueBackupFuzzMilliseconds(...) returns 600000
08-17 06:45:41.073   429  1090 V BackupManagerConstants: getKeyValueBackupRequiredNetworkType(...) returns 1
08-17 06:45:41.073   429  1090 V BackupManagerConstants: getKeyValueBackupRequireCharging(...) returns true
08-17 06:45:41.073   429  1090 V KeyValueBackupJob: Scheduling k/v pass in 240 minutes
08-17 06:45:41.084   838   838 D Tonal   : Tonal Palette - index: 10. Main color: ffeb9aa9
08-17 06:45:41.084   838   838 D Tonal   : Colors: ff140409, ff290813, ff3e0c1f, ff58112c, ff771841, ff971e46, ffb72455, ffc8537a, ffe06283, ffe57c95, ffeb9aa9, fff3c5cc, fff9e2e7
08-17 06:45:41.085   838   838 D Tonal   : Gradients:
08-17 06:45:41.085   838   838 D Tonal   :      Normal GradientColors(ffeb9aa9, ffeb9aa9)
08-17 06:45:41.085   838   838 D Tonal   :      Dark GradientColors(ff58112c, ff58112c)
08-17 06:45:41.085   838   838 D Tonal   :      Extra dark: GradientColors(ff3e0c1f, ff3e0c1f)
08-17 06:45:41.085   838   838 V Launcher: LauncherAppState initiated
08-17 06:45:41.089   595   907 D         : set stream to NULL
08-17 06:45:41.106   595   907 D         : set stream to NULL
08-17 06:45:41.136  1169  1169 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.136  1169  1169 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:41.136  1169  1169 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.140  1169  1169 I .quicksearchbo: The ClassLoaderContext is a special shared library.
08-17 06:45:41.141   243   243 D Zygote  : Forked child process 1192
08-17 06:45:41.143   429   459 I ActivityManager: Start proc 1192:com.android.printspooler/u0a69 for service {com.android.printspooler/com.android.printspooler.model.PrintSpoolerService}
08-17 06:45:41.280   429  1220 I RecoverySystem: No recovery log file
08-17 06:45:41.285  1107  1107 D StressTest: =========onReceive===rebootFlag:0
08-17 06:45:41.287   222   229 E apexd   : Can't open /product/apex for reading : No such file or directory
08-17 06:45:41.287   243   243 D Zygote  : Forked child process 1222
08-17 06:45:41.289   429   429 I Telecom : DefaultDialerCache: Refreshing default dialer for user 0: now null: DDC.oR@AAY
08-17 06:45:41.289   429  1220 I DropBoxManagerService: add tag=SYSTEM_BOOT isTagEnabled=true flags=0x2
08-17 06:45:41.289   429   429 I Telecom : MissedCallNotifierImpl: reloadAfterBootComplete: user=0: TSBCR.oR@AAc
08-17 06:45:41.290   429   459 I ActivityManager: Start proc 1222:com.android.keychain/1000 for service {com.android.keychain/com.android.keychain.KeyChainService}
08-17 06:45:41.298   673   673 D CarrierConfigLoader: mHandler: 13 phoneId: 0
08-17 06:45:41.307   429  1220 I BootReceiver: Copying /sys/fs/pstore/console-ramoops-0 to DropBox (SYSTEM_LAST_KMSG)
08-17 06:45:41.311   429  1220 I DropBoxManagerService: add tag=SYSTEM_LAST_KMSG isTagEnabled=true flags=0x2
08-17 06:45:41.313   243   243 D Zygote  : Forked child process 1239
08-17 06:45:41.317   429   459 I ActivityManager: Start proc 1239:android.process.acore/u0a35 for content provider {com.android.providers.contacts/com.android.providers.contacts.CallLogProvider}
08-17 06:45:41.331   429  1220 I BootReceiver: Copying audit failures to DropBox
08-17 06:45:41.333   243   243 D Zygote  : Forked child process 1255
08-17 06:45:41.337   429   459 I ActivityManager: Start proc 1255:android.rockchip.update.service/1000 for broadcast {android.rockchip.update.service/android.rockchip.update.service.RKUpdateReceiver}
08-17 06:45:41.345   429  1220 I BootReceiver: Copied 2325 worth of audits to DropBox
08-17 06:45:41.346   429  1220 I DropBoxManagerService: add tag=SYSTEM_AUDIT isTagEnabled=true flags=0x2
08-17 06:45:41.359  1222  1222 I ndroid.keychai: The ClassLoaderContext is a special shared library.
08-17 06:45:41.365   429  1220 I BootReceiver: Checking for fsck errors
08-17 06:45:41.367   429  1220 I BootReceiver: fs_stat, partition:cache stat:0xb
08-17 06:45:41.368   429  1220 I BootReceiver: fs_stat, partition:userdata stat:0xb
08-17 06:45:41.395   243   243 D Zygote  : Forked child process 1287
08-17 06:45:41.398   429   459 I ActivityManager: Start proc 1287:android.process.media/u0a40 for content provider {com.android.providers.downloads/com.android.providers.downloads.DownloadProvider}
08-17 06:45:41.406   429   452 W ActivityTaskManager: Activity top resumed state loss timeout for ActivityRecord{86d3118 u0 com.android.launcher3/.Launcher t16}
08-17 06:45:41.406   429   452 W ActivityTaskManager: Activity pause timeout for ActivityRecord{86d3118 u0 com.android.launcher3/.Launcher t16}
08-17 06:45:41.409  1255  1255 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.409  1255  1255 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:41.409  1255  1255 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.413  1255  1255 I .update.servic: The ClassLoaderContext is a special shared library.
08-17 06:45:41.439   838   937 D LoaderTask: loadWorkspace: loading default favorites
08-17 06:45:41.441   242   375 I netd    : bandwidthAddNiceApp(10040) <0.06ms>
08-17 06:45:41.456  1255  1255 D RKUpdateReceiver: action = android.intent.action.BOOT_COMPLETED
08-17 06:45:41.456  1255  1255 D RKUpdateReceiver: RKUpdateReceiver recv ACTION_BOOT_COMPLETED.
08-17 06:45:41.458  1255  1255 W ContextImpl: Calling a method in the system process without a qualified user: android.app.ContextImpl.startService:1570 android.content.ContextWrapper.startService:669
 android.content.ContextWrapper.startService:669 android.rockchip.update.service.RKUpdateReceiver.onReceive:59 android.app.ActivityThread.handleReceiver:3788
08-17 06:45:41.458  1239  1239 I ContactsPerf: VoicemailContentProvider.onCreate start
08-17 06:45:41.464  1255  1255 W ContextImpl: Calling a method in the system process without a qualified user: android.app.ContextImpl.startService:1570 android.content.ContextWrapper.startService:669
 android.content.ContextWrapper.startService:669 android.rockchip.update.service.RKUpdateReceiver.onReceive:65 android.app.ActivityThread.handleReceiver:3788
08-17 06:45:41.470  1239  1239 I ContactsPerf: VoicemailContentProvider.onCreate finish
08-17 06:45:41.478  1255  1255 I android_rockchip_update_UpdateService.cpp: JNI_OnLoad
08-17 06:45:41.482  1255  1255 D RKUpdateService: starting RKUpdateService, version is 1.8.2
08-17 06:45:41.483  1255  1255 W .update.service: type=1400 audit(0.0:45): avc: denied { read } for name="u:object_r:serialno_prop:s0" dev="tmpfs" ino=11677 scontext=u:r:system_app:s0 tcontext=u:objec
t_r:serialno_prop:s0 tclass=file permissive=0
08-17 06:45:41.484  1255  1255 E libc    : Access denied finding property "ro.serialno"
08-17 06:45:41.485  1255  1255 W .update.service: type=1400 audit(0.0:46): avc: denied { read } for name="u:object_r:serialno_prop:s0" dev="tmpfs" ino=11677 scontext=u:r:system_app:s0 tcontext=u:objec
t_r:serialno_prop:s0 tclass=file permissive=0
08-17 06:45:41.485  1255  1255 E libc    : Access denied finding property "ro.serialno"
08-17 06:45:41.486  1255  1255 D RKUpdateService: remote uri is http://192.168.1.143:2300/OtaUpdater/android?product=rk3399-Android10&version=1.0.0&sn=unknown&country=US&language=en
08-17 06:45:41.486  1255  1255 D RKUpdateService: remote uri backup is http://192.168.1.143:2300/OtaUpdater/android?product=rk3399-Android10&version=1.0.0&sn=unknown&country=US&language=en
08-17 06:45:41.489  1255  1255 D RKUpdateService: first startup!!!
08-17 06:45:41.507   243   243 D Zygote  : Forked child process 1316
08-17 06:45:41.510   429   459 I ActivityManager: Start proc 1316:com.android.calendar/u0a93 for broadcast {com.android.calendar/com.android.calendar.alerts.AlertReceiver}
08-17 06:45:41.517   429   832 D CountryDetector: The first listener is added
08-17 06:45:41.518  1239  1239 I ContactsDatabaseHelper: updateUseStrictPhoneNumberComparison: US
08-17 06:45:41.521   838  1165 I mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 876; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:41.521   838  1165 I mali_so : arm_release_ver of this mali_so is 'r18p0-01rel0', rk_so_ver is '17@0'.
08-17 06:45:41.521   838  1165 D mali_so : [File] : hardware/rockchip/mali_so/driver/product/base/src/mali_base_kbase.c; [Line] : 881; [Func] : base_context_deal_with_version_affairs_rk_ext;
08-17 06:45:41.521   838  1165 D mali_so : current process is NOT sf, to bail out.
08-17 06:45:41.526   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:41.532   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:41.535  1239  1239 D ActivityThread: Loading provider contacts;com.android.contacts: com.android.providers.contacts.ContactsProvider2
08-17 06:45:41.539   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:41.544  1255  1255 D RKUpdateService: onStartCommand.......
08-17 06:45:41.544  1255  1255 D RKUpdateService: command = 1 delaytime = 20000
08-17 06:45:41.547   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.configstore@1.0::ISurfaceFlingerConfigs/default in either framework or device manifest.
08-17 06:45:41.547  1255  1255 D RKUpdateService: onStartCommand.......
08-17 06:45:41.547  1255  1255 D RKUpdateService: command = 2 delaytime = 25000
08-17 06:45:41.548   429   451 I DropBoxManagerService: add tag=system_app_strictmode isTagEnabled=true flags=0x2
08-17 06:45:41.555   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.mapper@3.0::IMapper/default in either framework or device manifest.
08-17 06:45:41.559   838   937 W Gralloc3: mapper 3.x is not supported
08-17 06:45:41.566   151   151 I hwservicemanager: getTransport: Cannot find entry android.hardware.graphics.allocator@3.0::IAllocator/default in either framework or device manifest.
08-17 06:45:41.566   838   937 W Gralloc3: allocator 3.x is not supported
08-17 06:45:41.574   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.574   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_43456_06:45:41.574
08-17 06:45:41.575   838   937 D GRALLOC-ROCKCHIP: RK_GRAPHICS_VER=commit-id:344c4dd
08-17 06:45:41.580   429   442 I system_server: Background concurrent copying GC freed 28167(2398KB) AllocSpace objects, 44(3324KB) LOS objects, 42% free, 7298KB/12MB, paused 280us total 241.332ms
08-17 06:45:41.586   838  1165 D mali_winsys: EGLint new_window_surface(egl_winsys_display *, void *, EGLSurface, EGLConfig, egl_winsys_surface **, egl_color_buffer_format *, EGLBoolean) returns 0x300
0
08-17 06:45:41.588  1316  1316 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.589  1316  1316 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:41.589  1316  1316 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.593   429   451 I DropBoxManagerService: add tag=system_server_strictmode isTagEnabled=true flags=0x2
08-17 06:45:41.607   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.607   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:41.607
08-17 06:45:41.626   838  1165 D         : set stream to NULL
08-17 06:45:41.627   259   313 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.627   259   313 I GRALLOC-ROCKCHIP: dmabuf_name : 313_12582912_06:45:41.627
08-17 06:45:41.628  1239  1348 D ContactsDatabaseHelper: WAL enabled for contacts2.db: true
08-17 06:45:41.630   259   296 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.630   259   296 I GRALLOC-ROCKCHIP: dmabuf_name : 296_43456_06:45:41.630
08-17 06:45:41.644  1316  1316 D AlertReceiver: onReceive: a=android.intent.action.BOOT_COMPLETED Intent { act=android.intent.action.BOOT_COMPLETED flg=0x89000010 cmp=com.android.calendar/.alerts.Aler
tReceiver (has extras) }
08-17 06:45:41.645   429   449 D AutofillManagerService: Close system dialogs
08-17 06:45:41.653   259   259 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.653   259   259 I GRALLOC-ROCKCHIP: dmabuf_name : 259_12582912_06:45:41.653
08-17 06:45:41.653   259  1355 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.653   259  1355 I GRALLOC-ROCKCHIP: dmabuf_name : 1355_43456_06:45:41.653
08-17 06:45:41.662   174   184 E BufferQueueProducer: [com.android.launcher3/com.android.launcher3.Launcher#0] disconnect: not connected (req=1)
08-17 06:45:41.662   838  1165 W libEGL  : EGLNativeWindowType 0x73b31696d0 disconnect failed
08-17 06:45:41.667   259  1355 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.667   259  1355 I GRALLOC-ROCKCHIP: dmabuf_name : 1355_43456_06:45:41.667
08-17 06:45:41.670   243   243 D Zygote  : Forked child process 1357
08-17 06:45:41.673   429   459 I ActivityManager: Start proc 1357:com.android.contacts/u0a77 for broadcast {com.android.contacts/com.android.contacts.interactions.OnBootOrUpgradeReceiver}
08-17 06:45:41.676   259  1355 I GRALLOC-ROCKCHIP: [File] : hardware/rockchip/libgralloc/midgard/gralloc_drm_rockchip.cpp; [Line] : 2197; [Func] : drm_gem_rockchip_alloc;
08-17 06:45:41.676   259  1355 I GRALLOC-ROCKCHIP: dmabuf_name : 1355_43456_06:45:41.676
08-17 06:45:41.691   838   838 E libprocessgroup: set_timerslack_ns write failed: Operation not permitted
08-17 06:45:41.728  1357  1357 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.728  1357  1357 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.manager-V1.0-java.jar
08-17 06:45:41.728  1357  1357 D ApplicationLoaders: Returning zygote-cached class loader: /system/framework/android.hidl.base-V1.0-java.jar
08-17 06:45:41.741  1239  1350 I ContactLocale: AddressBook Labels [[en_US]]: [鈥? A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z, 螒, 螔, 螕, 螖, 螘, 螙, 螚, 螛, 螜, 螝,
 螞, 螠, 螡, 螢, 螣, 螤, 巍, 危, 韦, 违, 桅, 围, 唯, 惟, 鈥? 袗, 袘, 袙, 袚, 袛, 袀, 袝, 袆, 袞, 袟, 袠, 袉, 袡, 袌, 袣, 袥, 袎, 袦, 袧, 袏, 袨, 袩, 袪, 小, 孝, 袐, 校, 肖, 啸, 笑, 效, 袕, 楔, 些, 挟,
 携, 鈥? 讗, 讘, 讙, 讚, 讛, 讜, 讝, 讞, 讟, 讬, 讻, 诇, 诪, 谞, 住, 注, 驻, 爪, 拽, 专, 砖, 转, 鈥? 丕, 亘, 鬲, 孬, 噩, 丨, 禺, 丿, 匕, 乇, 夭, 爻, 卮, 氐, 囟, 胤, 馗, 毓, 睾, 賮, 賯, 賰, 賱, 賲, 賳,
 賴, 賵, 賷, 鈥? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔? 喔?
 鈥? 銊? 銊? 銊? 銊? 銋? 銋? 銋? 銋? 銋? 銋? 銋? 銋? 銋? 銋? 鈥? 銇? 銇? 銇? 銇? 銇? 銇? 銇? 銈? 銈? 銈? #, 鈥
08-17 06:45:41.764  1239  1348 D ContactsDatabaseHelper: WAL enabled for profile.db: false
08-17 06:45:41.798  1051  1051 I AlarmClock: AlarmInitReceiver android.intent.action.BOOT_COMPLETED
08-17 06:45:41.805   429   502 W Binder  : Outgoing transactions from this process must be FLAG_ONEWAY
08-17 06:45:41.805   429   502 W Binder  : java.lang.Throwable
08-17 06:45:41.805   429   502 W Binder  :      at android.os.BinderProxy.transact(BinderProxy.java:481)
08-17 06:45:41.805   429   502 W Binder  :      at android.content.ContentProviderProxy.getType(ContentProviderNative.java:456)
08-17 06:45:41.805   429   502 W Binder  :      at com.android.server.am.ActivityManagerService.getProviderMimeType(ActivityManagerService.java:7793)
08-17 06:45:41.805   429   502 W Binder  :      at android.app.IActivityManager$Stub.onTransact(IActivityManager.java:3207)
08-17 06:45:41.805   429   502 W Binder  :      at com.android.server.am.ActivityManagerService.onTransact(ActivityManagerService.java:2832)
08-17 06:45:41.805   429   502 W Binder  :      at android.os.Binder.execTransactInternal(Binder.java:1021)
08-17 06:45:41.805   429   502 W Binder  :      at android.os.Binder.execTransact(Binder.java:994)
08-17 06:45:41.809  1051  1080 I AlarmClock: Fixing alarm instances
08-17 06:45:41.866  1051  1080 V AlarmClock: AlarmInitReceiver finished
08-17 06:45:41.881   243   243 D Zygote  : Forked child process 1381
08-17 06:45:41.884   429   459 I ActivityManager: Start proc 1381:com.android.dynsystem/1000 for broadcast {com.android.dynsystem/com.android.dynsystem.BootCompletedReceiver}
08-17 06:45:41.940   429  1007 D DynamicSystemService: GsiService is not ready, wait for 64ms
08-17 06:45:42.008   429   502 W DynamicSystemService: gsiservice died; reconnecting
08-17 06:45:42.008   150   150 I ServiceManager: service 'gsiservice' died
08-17 06:45:42.015   909   909 I SystemBroadcastReceiver: Boot has been completed
08-17 06:45:42.015   909   909 I SystemBroadcastReceiver: toggleAppIcon() : FLAG_SYSTEM = true
08-17 06:45:42.037   243   243 D Zygote  : Forked child process 1404
08-17 06:45:42.040   429   459 I ActivityManager: Start proc 1404:com.android.managedprovisioning/u0a46 for broadcast {com.android.managedprovisioning/com.android.managedprovisioning.preprovisioning.B
ootReminder}
08-17 06:45:42.152   243   243 D Zygote  : Forked child process 1424
08-17 06:45:42.156   429   459 I ActivityManager: Start proc 1424:com.android.onetimeinitializer/u0a76 for broadcast {com.android.onetimeinitializer/com.android.onetimeinitializer.OneTimeInitializerRe
ceiver}
08-17 06:45:42.212  1424  1424 V OneTimeInitializerReceiver: OneTimeInitializerReceiver.onReceive
08-17 06:45:42.231   243   243 D Zygote  : Forked child process 1450
08-17 06:45:42.234   429   459 I ActivityManager: Start proc 1450:com.android.packageinstaller/u0a42 for broadcast {com.android.packageinstaller/com.android.packageinstaller.TemporaryFileManager}
08-17 06:45:42.329   243   243 D Zygote  : Forked child process 1470
08-17 06:45:42.333   429   459 I ActivityManager: Start proc 1470:com.android.permissioncontroller/u0a45 for broadcast {com.android.permissioncontroller/com.android.packageinstaller.permission.service
.LocationAccessCheck$SetupPeriodicBackgroundLocationAccessCheck}
08-17 06:45:42.428  1470  1470 W ExclusiveDefaultHolderMixin: Cannot get ApplicationInfo for default holder, config: config_defaultSms, package: com.android.messaging
08-17 06:45:42.445   673   673 I VvmSimStateTracker: android.intent.action.BOOT_COMPLETED
08-17 06:45:42.459   243   243 D Zygote  : Forked child process 1491
08-17 06:45:42.463   429   459 I ActivityManager: Start proc 1491:com.android.providers.calendar/u0a43 for broadcast {com.android.providers.calendar/com.android.providers.calendar.CalendarReceiver}
08-17 06:45:42.550  1491  1491 I CalendarProvider2: Created com.android.providers.calendar.CalendarAlarmManager@508f07c(com.android.providers.calendar.CalendarProvider2@9fc5d05)
08-17 06:45:42.624   243   243 D Zygote  : Forked child process 1516
08-17 06:45:42.628   429   459 I ActivityManager: Start proc 1516:com.android.traceur/u0a58 for broadcast {com.android.traceur/com.android.traceur.Receiver}
08-17 06:45:42.754   429   501 I ActivityManager: Finished processing BOOT_COMPLETED for u0
08-17 06:45:42.756  1107  1107 E VRMountReceiver: ---------------- action = android.intent.action.MEDIA_MOUNTED
08-17 06:45:42.756  1107  1107 E VRMountReceiver: ------------- mount path = /storage/emulated/0
08-17 06:45:42.756  1107  1107 E VRMountReceiver: ---------------- pathUri is null
08-17 06:45:42.808   909   909 I LatinIME: Timeout waiting for dictionary load
08-17 06:45:43.431   429   449 I EthernetTracker: interfaceLinkStateChanged, iface: eth1, up: true
08-17 06:45:43.436   429   567 D EthernetNetworkFactory: updateInterfaceLinkState, iface: eth1, up: true
08-17 06:45:43.437   429   996 D DhcpClient: doQuit
08-17 06:45:43.446   429   996 D DhcpClient: onQuitting
08-17 06:45:43.447   242   375 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.29ms>
08-17 06:45:43.450   242   375 I netd    : interfaceClearAddrs("eth1") <0.30ms>
08-17 06:45:43.453   429   567 D EthernetNetworkFactory: starting IpClient(eth1): mNetworkInfo=[type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, avail
able: false, roaming: false]
08-17 06:45:43.454   429  1013 D DhcpClient: Receive thread stopped
08-17 06:45:43.456   242   375 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.18ms>
08-17 06:45:43.456   242   375 I netd    : interfaceClearAddrs("eth1") <0.33ms>
08-17 06:45:43.461   242   375 I netd    : interfaceSetIPv6PrivacyExtensions("eth1", "true") <0.16ms>
08-17 06:45:43.461   242   375 I netd    : setIPv6AddrGenMode("eth1", 2) <0.15ms>
08-17 06:45:43.462   242   375 I netd    : interfaceSetEnableIPv6("eth1", "true") <0.28ms>
08-17 06:45:43.464   242   375 I netd    : setProcSysNet(4, 2, "eth1", "retrans_time_ms", "750") <0.08ms>
08-17 06:45:43.465   242   375 I netd    : setProcSysNet(4, 2, "eth1", "ucast_solicit", "5") <0.03ms>
08-17 06:45:43.465   242   375 I netd    : setProcSysNet(6, 2, "eth1", "retrans_time_ms", "750") <0.05ms>
08-17 06:45:43.465   242   375 I netd    : setProcSysNet(6, 2, "eth1", "ucast_solicit", "5") <0.03ms>
08-17 06:45:43.478   429  1541 D DhcpClient: Receive thread started
08-17 06:45:43.480   429  1540 D DhcpClient: Broadcasting DHCPDISCOVER
08-17 06:45:43.557   909   944 I putmethod.lati: Waiting for a blocking GC ProfileSaver
08-17 06:45:43.564   909   944 I putmethod.lati: WaitForGcToComplete blocked ProfileSaver on AddRemoveAppImageSpace for 7.358ms
08-17 06:45:43.992   243   243 D Zygote  : Forked child process 1543
08-17 06:45:43.996   429   459 I ActivityManager: Start proc 1543:com.android.localtransport/1000 for service {com.android.localtransport/com.android.localtransport.LocalTransportService}
08-17 06:45:44.044   429   540 D ConnectivityService: releasing NetworkRequest [ TRACK_DEFAULT id=14, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED Uid: 1001] ] (release request)
08-17 06:45:44.049   595   595 V KeyguardUpdateMonitor: onSubscriptionInfoChanged()
08-17 06:45:44.064   429   429 I TransportClient: LocalTransportService#0: Notifying [TransportManager.registerTransport()] transport = IBackupTransport
08-17 06:45:44.066   429  1090 W Binder  : Outgoing transactions from this process must be FLAG_ONEWAY
08-17 06:45:44.066   429  1090 W Binder  : java.lang.Throwable
08-17 06:45:44.066   429  1090 W Binder  :      at android.os.BinderProxy.transact(BinderProxy.java:481)
08-17 06:45:44.066   429  1090 W Binder  :      at com.android.internal.backup.IBackupTransport$Stub$Proxy.name(IBackupTransport.java:869)
08-17 06:45:44.066   429  1090 W Binder  :      at com.android.server.backup.TransportManager.registerTransport(TransportManager.java:653)
08-17 06:45:44.066   429  1090 W Binder  :      at com.android.server.backup.TransportManager.registerTransportsForIntent(TransportManager.java:588)
08-17 06:45:44.066   429  1090 W Binder  :      at com.android.server.backup.TransportManager.registerTransports(TransportManager.java:558)
08-17 06:45:44.066   429  1090 W Binder  :      at com.android.server.backup.-$$Lambda$pM_c5tVAGDtxjxLF_ONtACWWq6Q.run(Unknown Source:2)
08-17 06:45:44.066   429  1090 W Binder  :      at android.os.Handler.handleCallback(Handler.java:883)
08-17 06:45:44.066   429  1090 W Binder  :      at android.os.Handler.dispatchMessage(Handler.java:100)
08-17 06:45:44.066   429  1090 W Binder  :      at android.os.Looper.loop(Looper.java:214)
08-17 06:45:44.066   429  1090 W Binder  :      at android.os.HandlerThread.run(HandlerThread.java:67)
08-17 06:45:44.068   429  1090 D BackupTransportManager: Transport com.android.localtransport/.LocalTransportService registered
08-17 06:45:44.068   429  1090 D BackupManagerService: Transport com.android.localtransport/.LocalTransport registered 3091ms after first request (delay = 3000ms)
08-17 06:45:44.081   429  1090 I BackupManagerService: Found stale backup journal, scheduling
08-17 06:45:44.263  1107  1107 D RecoveryReceiver: RECOVERY_STATE_FILE_TF:/mnt/external_sd/Recovery_state
08-17 06:45:44.266  1255  1255 D RKUpdateReceiver: action = android.intent.action.MEDIA_MOUNTED
08-17 06:45:44.138   429  1090 I chatty  : uid=1000(system) backup-0 identical 394 lines
08-17 06:45:44.138   429  1090 I BackupManagerService: Found stale backup journal, scheduling
08-17 06:45:44.268  1255  1255 W ContextImpl: Calling a method in the system process without a qualified user: android.app.ContextImpl.startService:1570 android.content.ContextWrapper.startService:669
 android.content.ContextWrapper.startService:669 android.rockchip.update.service.RKUpdateReceiver.onReceive:74 android.app.ActivityThread.handleReceiver:3788
08-17 06:45:44.271  1255  1255 D RKUpdateReceiver: media is mounted to '/storage/emulated/0'. To check local update.
08-17 06:45:44.272  1255  1255 D RKUpdateService: onStartCommand.......
08-17 06:45:44.272  1255  1255 D RKUpdateService: command = 1 delaytime = 5000
08-17 06:45:44.342  1287  1569 I MediaProvider: Begin Intent { act=android.intent.action.MEDIA_MOUNTED dat=file:///storage/emulated/0 flg=0x5000010 cmp=com.android.providers.media/.MediaService (has e
xtras) }
08-17 06:45:44.361  1287  1569 W ModernMediaScanner: Failed to visit /system/media: java.nio.file.NoSuchFileException: /system/media
08-17 06:45:44.381  1287  1569 W ModernMediaScanner: Failed to visit /oem/media: java.nio.file.NoSuchFileException: /oem/media
08-17 06:45:45.674  1287  1569 E SQLiteLog: (1) no such table: audio_genres
08-17 06:45:45.692  1287  1569 I chatty  : uid=10040(com.android.providers.media) IntentService[M identical 1 line
08-17 06:45:45.719  1287  1569 E SQLiteLog: (1) no such table: audio_genres
08-17 06:45:45.961  1287  1569 I MediaProvider: End Intent { act=android.intent.action.MEDIA_MOUNTED dat=file:///storage/emulated/0 flg=0x5000010 cmp=com.android.providers.media/.MediaService (has ext
ras) }
08-17 06:45:46.276   150   150 I ServiceManager: service 'idmap' died
08-17 06:45:46.276   429  1007 W OverlayManager: service 'idmap' died
08-17 06:45:46.485  1255  1308 I .update.servic: Waiting for a blocking GC ProfileSaver
08-17 06:45:47.221  1424  1446 I timeinitialize: Waiting for a blocking GC ProfileSaver
08-17 06:45:47.246  1424  1446 I timeinitialize: WaitForGcToComplete blocked ProfileSaver on AddRemoveAppImageSpace for 25.338ms
08-17 06:45:47.405  1470  1489 I ssioncontrolle: Waiting for a blocking GC ProfileSaver
^C
c:\adb>adb shell
rk3399_Android10:/ $ su
su
rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          UP BROADCAST MULTICAST  MTU:1500  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 TX bytes:0

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 TX bytes:0

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet6 addr: fe80::32e8:50db:5a16:20ab/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:43 errors:0 dropped:0 overruns:0 frame:0
          TX packets:11 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:4377 TX bytes:1418
          Interrupt:27

rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          UP BROADCAST MULTICAST  MTU:1500  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 TX bytes:0

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 TX bytes:0

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet6 addr: fe80::32e8:50db:5a16:20ab/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:54 errors:0 dropped:0 overruns:0 frame:0
          TX packets:13 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:6100 TX bytes:1816
          Interrupt:27

rk3399_Android10:/ #

rk3399_Android10:/ # logcat -c
logcat -c
rk3399_Android10:/ # logcat
logcat
--------- beginning of main
08-17 06:46:11.710  1255  1315 D RKUpdateService: request remote server error...
08-17 06:46:16.290   429  1540 D DhcpClient: Broadcasting DHCPDISCOVER
08-17 06:46:26.331   429   449 I EthernetTracker: interfaceLinkStateChanged, iface: eth0, up: true
08-17 06:46:26.337   429   567 D EthernetNetworkFactory: updateInterfaceLinkState, iface: eth1, up: false
08-17 06:46:26.341   429  1540 D DhcpClient: doQuit
08-17 06:46:26.359   429  1540 D DhcpClient: onQuitting
08-17 06:46:26.363   242   375 I netd    : interfaceSetEnableIPv6("eth1", "false") <1.07ms>
08-17 06:46:26.372   242   375 I netd    : interfaceClearAddrs("eth1") <1.26ms>
08-17 06:46:26.372   429  1541 D DhcpClient: Receive thread stopped
08-17 06:46:28.338   429   567 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth1, up = true
08-17 06:46:28.342   429   567 D EthernetNetworkFactory: updateInterfaceLinkState, iface: eth0, up: true
08-17 06:46:28.343   429   567 D EthernetNetworkFactory: starting IpClient(eth0): mNetworkInfo=[type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, avail
able: false, roaming: false]
--------- beginning of system
08-17 06:46:28.344   429   449 W Looper  : Slow dispatch took 2016ms android.fg h=android.os.Handler c=com.android.server.-$$Lambda$NetworkManagementService$NetdUnsolicitedEventListener$pOV71EYm5PphEV
G1PGQnV_c6XiA@7fe9655 m=0
08-17 06:46:28.345   429   449 W Looper  : Slow delivery took 2012ms android.fg h=android.os.Handler c=com.android.server.-$$Lambda$NetworkManagementService$NetdUnsolicitedEventListener$praKgcnQG9FTHN
MGfCVPTVY8mK8@3f2186a m=0
08-17 06:46:28.349   242   375 I netd    : interfaceSetEnableIPv6("eth0", "false") <0.98ms>
08-17 06:46:28.351   429   449 W Looper  : Drained
08-17 06:46:28.358   242   375 I netd    : interfaceClearAddrs("eth0") <0.86ms>
08-17 06:46:28.371   429   567 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth0, up = true
08-17 06:46:28.381   242   375 I netd    : interfaceSetIPv6PrivacyExtensions("eth0", "true") <0.61ms>
08-17 06:46:28.385   242   375 I netd    : setIPv6AddrGenMode("eth0", 2) <0.68ms>
08-17 06:46:28.393   242   375 I netd    : interfaceSetEnableIPv6("eth0", "true") <6.68ms>
08-17 06:46:28.398   242   375 I netd    : setProcSysNet(4, 2, "eth0", "retrans_time_ms", "750") <0.52ms>
08-17 06:46:28.400   242   375 I netd    : setProcSysNet(4, 2, "eth0", "ucast_solicit", "5") <0.45ms>
08-17 06:46:28.402   242   375 I netd    : setProcSysNet(6, 2, "eth0", "retrans_time_ms", "750") <0.52ms>
08-17 06:46:28.403   242   375 I netd    : setProcSysNet(6, 2, "eth0", "ucast_solicit", "5") <0.33ms>
08-17 06:46:28.426   429  1724 D DhcpClient: Receive thread started
08-17 06:46:28.432   429  1722 D DhcpClient: Broadcasting DHCPDISCOVER
08-17 06:46:29.343   429  1727 D EthernetNetworkFactoryExt: setStaticIpAddress:IP address 192.168.1.119/24 Gateway  DNS servers: [ ] Domains
08-17 06:46:29.343   429  1727 D EthernetNetworkFactoryExt: IpClient.startProvisioning
08-17 06:46:29.350   242   375 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.34ms>
08-17 06:46:29.352   242   375 I netd    : interfaceClearAddrs("eth1") <0.81ms>
08-17 06:46:29.366   242   375 I netd    : interfaceSetIPv6PrivacyExtensions("eth1", "true") <0.32ms>
08-17 06:46:29.368   242   375 I netd    : setIPv6AddrGenMode("eth1", 2) <0.43ms>
08-17 06:46:29.376   242   375 I netd    : interfaceSetEnableIPv6("eth1", "true") <5.77ms>
08-17 06:46:29.381   242   375 I netd    : interfaceSetCfg() <1.42ms>
08-17 06:46:29.393   429  1728 D EthernetNetworkFactoryExt: addToLocalNetwork: iface = eth1
08-17 06:46:29.397   242   375 E Netd    : getIfIndex: cannot find interface eth1
08-17 06:46:29.398   242   375 E Netd    : inconceivable! added interface eth1 with no index
08-17 06:46:29.398   242   375 I netd    : networkAddInterface(99, "eth1") <3.93ms>
08-17 06:46:29.402   242   375 I netd    : networkAddRoute(99, "eth1", "fe80::/64", "") <0.68ms>
08-17 06:46:29.404   242   375 I netd    : networkAddRoute(99, "eth1", "192.168.1.0/24", "") <0.48ms>
08-17 06:46:29.406   242   375 E Netd    : Error adding route fe80::/64 -> (null) eth1 to table 97: File exists
08-17 06:46:29.406   242   375 I netd    : networkAddRoute(99, "eth1", "fe80::/64", "") <0.82ms>
08-17 06:46:29.408   242   375 I netd    : setProcSysNet(4, 2, "eth1", "retrans_time_ms", "750") <0.23ms>
08-17 06:46:29.410   242   375 I netd    : setProcSysNet(4, 2, "eth1", "ucast_solicit", "5") <0.42ms>
08-17 06:46:29.412   242   375 I netd    : setProcSysNet(6, 2, "eth1", "retrans_time_ms", "750") <0.33ms>
08-17 06:46:29.413   242   375 I netd    : setProcSysNet(6, 2, "eth1", "ucast_solicit", "5") <0.11ms>
08-17 06:46:30.410   429  1722 D DhcpClient: Broadcasting DHCPDISCOVER
08-17 06:46:35.415   429  1722 D DhcpClient: Broadcasting DHCPDISCOVER
08-17 06:46:35.421   429  1724 D DhcpClient: Received packet: 00:e0:4c:78:37:02 OFFER, ip /192.168.50.4, mask /255.255.255.0, DNS servers: /192.168.50.254 , gateways [/192.168.50.254] lease time 120,
domain null
08-17 06:46:35.428   429  1722 D DhcpClient: Got pending lease: android.net.networkstack.DhcpResults@2f1a296 DHCP server /192.168.50.254 Vendor info null lease 120 seconds Servername
08-17 06:46:35.433   429  1722 D DhcpClient: Broadcasting DHCPREQUEST ciaddr=0.0.0.0 request=192.168.50.4 serverid=192.168.50.254
08-17 06:46:35.438   429  1724 D DhcpClient: Received packet: 00:e0:4c:78:37:02 ACK: your new IP /192.168.50.4, netmask /255.255.255.0, gateways [/192.168.50.254] DNS servers: /192.168.50.254 , lease
time 120
08-17 06:46:35.444   429  1722 D DhcpClient: Confirmed lease: android.net.networkstack.DhcpResults@3b20204 DHCP server /192.168.50.254 Vendor info null lease 120 seconds Servername
08-17 06:46:35.457   242   375 I netd    : interfaceSetCfg() <1.65ms>
08-17 06:46:35.469   429   567 E EthernetNetworkFactory: chunqiao carrier=1
08-17 06:46:35.470   429   567 E EthernetNetworkFactory: eth0 carrier = 1
08-17 06:46:35.473   429  1722 D DhcpClient: Scheduling renewal in 59s
08-17 06:46:35.473   429  1722 D DhcpClient: Scheduling rebind in 104s
08-17 06:46:35.473   429  1722 D DhcpClient: Scheduling expiry in 119s
08-17 06:46:35.474   429   567 D ConnectivityService: registerNetworkAgent NetworkAgentInfo{ ni{[type: Ethernet[], state: CONNECTED/CONNECTED, reason: (unspecified), extra: 00:e0:4c:78:37:02, failover
: false, available: true, roaming: false]}  network{100}  nethandle{432902426637}  lp{{InterfaceName: eth0 LinkAddresses: [ fe80::e66d:f037:bfe8:6328/64,192.168.50.4/24 ] DnsAddresses: [ /192.168.50.2
54 ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth0,192.168.50.0/24 -> 0.0.0.0 eth0,0.0.0.0/0 -> 192.168.50.254 eth0 ]}}  nc{[ Transp
orts: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&FOREGROUND&NOT_CONGESTED&NOT_SUSPENDED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbps]}  Score{30}
  everValidated{false}  lastValidated{false}  created{false} lingering{false} explicitlySelected{false} acceptUnvalidated{false} everCaptivePortalDetected{false} lastCaptivePortalDetected{false} capti
vePortalValidationPending{false} partialConnectivity{false} acceptPartialConnectivity{false} clat{mBaseIface: null, mIface: null, mState: IDLE} }
08-17 06:46:35.505   429   567 E ConnectivityService: huchunqiao eth0
08-17 06:46:35.507   429   540 D ConnectivityService: NetworkAgentInfo [Ethernet () - 100] EVENT_NETWORK_INFO_CHANGED, going from null to CONNECTED
08-17 06:46:35.508   242   375 D TcpSocketMonitor: resuming tcpinfo polling (interval=30000ms)
08-17 06:46:35.508   242   375 I netd    : networkCreatePhysical(100, 0) <0.25ms>
08-17 06:46:35.511   242   375 I netd    : createNetworkCache(100) <0.73ms>
08-17 06:46:35.517   429   540 W DnsManager: updatePrivateDns(100, PrivateDnsConfig{true:/[]})
08-17 06:46:35.518   429   540 D ConnectivityService: Setting DNS servers for network 100 to [/192.168.50.254]
08-17 06:46:35.520   429   540 D DnsManager: setDnsConfigurationForNetwork(100, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, , [192.168.50.254])
08-17 06:46:35.522   242   375 I netd    : DnsResolverService::setResolverConfiguration(100, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, [192.168.50.254], []) -> (0) (1ms)
08-17 06:46:35.523   242   375 I netd    : setResolverConfiguration() <1.73ms>
08-17 06:46:35.526   429   540 D ConnectivityService: Adding iface eth0 to network 100
08-17 06:46:35.533   242   375 I netd    : networkAddInterface(100, "eth0") <6.24ms>
08-17 06:46:35.535   242   375 I netd    : networkAddRoute(100, "eth0", "fe80::/64", "") <0.57ms>
08-17 06:46:35.537   242   375 I netd    : networkAddRoute(100, "eth0", "192.168.50.0/24", "") <0.51ms>
08-17 06:46:35.539   242   375 I netd    : networkAddRoute(100, "eth0", "0.0.0.0/0", "192.168.50.254") <0.46ms>
08-17 06:46:35.539   429   540 D ConnectivityService: Setting DNS servers for network 100 to [/192.168.50.254]
08-17 06:46:35.540   429   540 D DnsManager: setDnsConfigurationForNetwork(100, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, , [192.168.50.254])
08-17 06:46:35.542   242   375 I netd    : DnsResolverService::setResolverConfiguration(100, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, [192.168.50.254], []) -> (0) (1ms)
08-17 06:46:35.542   242   375 I netd    : setResolverConfiguration() <1.29ms>
08-17 06:46:35.544   242  1749 W DnsTlsSocket: SSL_connect error 5, errno=111
08-17 06:46:35.553   429   540 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.565   242   375 I netd    : trafficSwapActiveStatsMap() <11.89ms>
08-17 06:46:35.571   242   375 I netd    : tetherGetStats() <2.46ms>
08-17 06:46:35.579   429   540 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.582   429   530 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.586   429   567 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 30
08-17 06:46:35.586   429   567 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, available: false, roaming
: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbp
s], networkAgent: null, score: 0, ipClient: null,linkProperties: {InterfaceName: eth1 LinkAddresses: [ ] DnsAddresses: [ ] Domains: null MTU: 0 Routes: [ ]}}
08-17 06:46:35.586   429   567 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 30
08-17 06:46:35.587   429   540 D ConnectivityService: Switching to new default network: NetworkAgentInfo{ ni{[type: Ethernet[], state: CONNECTED/CONNECTED, reason: (unspecified), extra: 00:e0:4c:78:37
:02, failover: false, available: true, roaming: false]}  network{100}  nethandle{432902426637}  lp{{InterfaceName: eth0 LinkAddresses: [ fe80::e66d:f037:bfe8:6328/64,192.168.50.4/24 ] DnsAddresses: [
/192.168.50.254 ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth0,192.168.50.0/24 -> 0.0.0.0 eth0,0.0.0.0/0 -> 192.168.50.254 eth0 ]}}
  nc{[ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&FOREGROUND&NOT_CONGESTED&NOT_SUSPENDED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbps
]}  Score{30}  everValidated{false}  lastValidated{false}  created{true} lingering{false} explicitlySelected{false} acceptUnvalidated{false} everCaptivePortalDetected{false} lastCaptivePortalDetected{
false} captivePortalValidationPending{false} partialConnectivity{false} acceptPartialConnectivity{false} clat{mBaseIface: null, mIface: null, mState: IDLE} }
08-17 06:46:35.587   429   567 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, available: false, roaming
: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbp
s], networkAgent: null, score: 0, ipClient: null,linkProperties: {InterfaceName: eth1 LinkAddresses: [ ] DnsAddresses: [ ] Domains: null MTU: 0 Routes: [ ]}}
08-17 06:46:35.588   242   375 I netd    : networkSetDefault(100) <0.82ms>
08-17 06:46:35.590   429  1750 D NetworkMonitor/100: Validation disabled.
08-17 06:46:35.590   242   375 I netd    : setTcpRWmemorySize("524288 1048576 3145728", "524288 1048576 2097152") <0.53ms>
08-17 06:46:35.599   429   540 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.611   242   375 I netd    : trafficSwapActiveStatsMap() <11.61ms>
08-17 06:46:35.615   242   375 I netd    : tetherGetStats() <2.07ms>
08-17 06:46:35.623   429   540 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.626   429   530 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.631   429   530 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.633   242   375 I netd    : bandwidthSetGlobalAlert(2097152) <0.66ms>
08-17 06:46:35.637   429   635 D NetworkTimeUpdateService: New default network 100; checking time.
08-17 06:46:35.644   429   540 D ConnectivityService: Sending CONNECTED broadcast for type 9 NetworkAgentInfo [Ethernet () - 100] isDefaultNetwork=true
08-17 06:46:35.648   429   540 D ConnectivityService: NetworkAgentInfo [Ethernet () - 100] validation passed
08-17 06:46:35.650   242  1751 E ResolverController: No valid NAT64 prefix (100, <unspecified>/0)
08-17 06:46:35.651   429   530 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.652  1255  1255 D RKUpdateReceiver: action = android.net.conn.CONNECTIVITY_CHANGE
08-17 06:46:35.653   429   530 W BestClock: java.time.DateTimeException: Missing NTP fix
08-17 06:46:35.655  1255  1255 W ContextImpl: Calling a method in the system process without a qualified user: android.app.ContextImpl.startService:1570 android.content.ContextWrapper.startService:669
 android.content.ContextWrapper.startService:669 android.rockchip.update.service.RKUpdateReceiver.onReceive:101 android.app.ActivityThread.handleReceiver:3788
08-17 06:46:35.655   242   375 I netd    : bandwidthSetGlobalAlert(2097152) <0.31ms>
08-17 06:46:35.657   429   567 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 70
08-17 06:46:35.657   429   567 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, available: false, roaming
: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbp
s], networkAgent: null, score: 0, ipClient: null,linkProperties: {InterfaceName: eth1 LinkAddresses: [ ] DnsAddresses: [ ] Domains: null MTU: 0 Routes: [ ]}}
08-17 06:46:35.658   429   567 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 70
08-17 06:46:35.659   429   567 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=6, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, available: false, roaming
: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbp
s], networkAgent: null, score: 0, ipClient: null,linkProperties: {InterfaceName: eth1 LinkAddresses: [ ] DnsAddresses: [ ] Domains: null MTU: 0 Routes: [ ]}}
08-17 06:46:35.659   429   540 D ConnectivityService: Setting DNS servers for network 100 to [/192.168.50.254]
08-17 06:46:35.660   429   540 D DnsManager: setDnsConfigurationForNetwork(100, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, , [192.168.50.254])
08-17 06:46:35.661   242   375 I netd    : DnsResolverService::setResolverConfiguration(100, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, [192.168.50.254], []) -> (0) (0.6ms)
08-17 06:46:35.662   242   375 I netd    : setResolverConfiguration() <0.86ms>
08-17 06:46:35.670   242  1752 W DnsTlsSocket: SSL_connect error 5, errno=111
08-17 06:46:35.671  1255  1255 D RKUpdateService: onStartCommand.......
08-17 06:46:35.675  1255  1255 D RKUpdateService: command = 2 delaytime = 5000
08-17 06:46:35.709   263   263 W memtrack@1.0-se: type=1400 audit(0.0:47): avc: denied { read } for name="mem_profile" dev="debugfs" ino=22495 scontext=u:r:hal_memtrack_default:s0 tcontext=u:object_r:
debugfs:s0 tclass=file permissive=0
08-17 06:46:35.723   263   263 W memtrack@1.0-se: type=1400 audit(0.0:48): avc: denied { read } for name="mem_profile" dev="debugfs" ino=22264 scontext=u:r:hal_memtrack_default:s0 tcontext=u:object_r:
debugfs:s0 tclass=file permissive=0
^C
c:\adb>adb shell
rk3399_Android10:/ $ su
su
rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          inet addr:192.168.50.4  Bcast:192.168.50.255  Mask:255.255.255.0
          inet6 addr: fe80::e66d:f037:bfe8:6328/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:8 errors:0 dropped:0 overruns:0 frame:0
          TX packets:23 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:1012 TX bytes:2872

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:0 errors:0 dropped:0 overruns:0 frame:0
          TX packets:0 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:0 TX bytes:0

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.119  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::32e8:50db:5a16:20ab/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:85 errors:0 dropped:0 overruns:0 frame:0
          TX packets:24 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:9829 TX bytes:3170
          Interrupt:27

rk3399_Android10:/ # ping 192.168.1.100
ping 192.168.1.100
PING 192.168.1.100 (192.168.1.100) 56(84) bytes of data.
64 bytes from 192.168.1.100: icmp_seq=1 ttl=128 time=1.40 ms
^C
c:\adb>adb shell
rk3399_Android10:/ $ su
su
rk3399_Android10:/ # ping www.baidu.com
ping www.baidu.com
PING www.a.shifen.com (14.215.177.38) 56(84) bytes of data.
64 bytes from 14.215.177.38: icmp_seq=1 ttl=53 time=6.07 ms
^C
c:\adb>