
eth0 eth1都插入

rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          inet addr:192.168.50.6  Bcast:192.168.50.255  Mask:255.255.255.0
          inet6 addr: fe80::45a2:83ec:9f60:f57c/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:93 errors:0 dropped:0 overruns:0 frame:0
          TX packets:29 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:7235 TX bytes:3014

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:4 errors:0 dropped:0 overruns:0 frame:0
          TX packets:4 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:352 TX bytes:352

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.100  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::9df3:d19f:2567:e362/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:79 errors:0 dropped:0 overruns:0 frame:0
          TX packets:31 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:8991 TX bytes:3038
          Interrupt:27



拔掉eth1
--------- beginning of main
08-25 11:48:22.069   431   450 I EthernetTracker: interfaceLinkStateChanged, iface: eth1, up: false
08-25 11:48:22.070   431   568 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth1, up = false
08-25 11:48:22.070   431   568 D EthernetNetworkFactoryExt: mLinkUp= true
08-25 11:48:22.081   243   376 I netd    : interfaceClearAddrs("eth1") <7.37ms>
08-25 11:48:22.082   431  1612 D EthernetNetworkFactoryExt: removeToLocalNetwork: iface = eth1
08-25 11:48:22.087   431   974 D DhcpClient: doQuit
08-25 11:48:22.087   243   376 I netd    : networkRemoveInterface(99, "eth1") <4.91ms>
08-25 11:48:22.093   243   376 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.58ms>
08-25 11:48:22.102   431   974 D DhcpClient: onQuitting
08-25 11:48:22.103   243   376 I netd    : interfaceClearAddrs("eth1") <0.47ms>
08-25 11:48:22.107   243   376 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.36ms>
08-25 11:48:22.110   243   376 I netd    : interfaceClearAddrs("eth1") <1.12ms>
08-25 11:48:22.114   431   985 D DhcpClient: Receive thread stopped
08-25 11:48:22.125   431   568 D EthernetNetworkFactory: starting IpClient(eth1): mNetworkInfo=[type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, avail
able: false, roaming: false]
08-25 11:48:22.131   243   376 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.19ms>
08-25 11:48:22.132   243   376 I netd    : interfaceClearAddrs("eth1") <0.40ms>
08-25 11:48:22.145   243   376 I netd    : interfaceSetIPv6PrivacyExtensions("eth1", "true") <0.16ms>
08-25 11:48:22.145   243   376 I netd    : setIPv6AddrGenMode("eth1", 2) <0.13ms>
08-25 11:48:22.146   243   376 I netd    : interfaceSetEnableIPv6("eth1", "true") <0.12ms>
08-25 11:48:22.148   243   376 I netd    : setProcSysNet(4, 2, "eth1", "retrans_time_ms", "750") <0.23ms>
08-25 11:48:22.149   243   376 I netd    : setProcSysNet(4, 2, "eth1", "ucast_solicit", "5") <0.15ms>
08-25 11:48:22.150   243   376 I netd    : setProcSysNet(6, 2, "eth1", "retrans_time_ms", "750") <0.17ms>
08-25 11:48:22.150   243   376 I netd    : setProcSysNet(6, 2, "eth1", "ucast_solicit", "5") <0.08ms>
08-25 11:48:22.165   431  1614 D DhcpClient: Receive thread started
08-25 11:48:22.169   431  1613 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:48:27.178   431   535 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:48:27.184   431  1613 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:48:27.190   595   595 D KeyguardClockSwitch: Updating clock: 11:48鈥夾M
08-25 11:48:27.194   243   376 I netd    : trafficSwapActiveStatsMap() <15.08ms>
08-25 11:48:27.203   243   376 I netd    : tetherGetStats() <4.03ms>
08-25 11:48:27.219   431   535 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:48:27.225   243   376 I netd    : bandwidthSetGlobalAlert(2097152) <0.46ms>
08-25 11:48:27.225   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:48:27.238   243  1615 E ResolverController: No valid NAT64 prefix (100, <unspecified>/0)
08-25 11:48:27.314   263   263 W memtrack@1.0-se: type=1400 audit(0.0:53): avc: denied { read } for name="mem_profile" dev="debugfs" ino=27910 scontext=u:r:hal_memtrack_default:s0 tcontext=u:object_r:
debugfs:s0 tclass=file permissive=0
08-25 11:48:32.188   431  1613 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:48:32.252   431   665 D SntpClient: request time failed: java.net.SocketTimeoutException: Poll timed out






插入eth1

08-25 11:48:40.301   431  1613 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:48:47.669   431   450 I EthernetTracker: interfaceLinkStateChanged, iface: eth1, up: true
08-25 11:48:47.670   431   568 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth1, up = true
08-25 11:48:47.670   431   568 D EthernetNetworkFactoryExt: mLinkUp= false
08-25 11:48:48.675   431  1616 D EthernetNetworkFactoryExt: setStaticIpAddress:IP address 192.168.1.100/24 Gateway  DNS servers: [ ] Domains
08-25 11:48:48.675   431  1616 D EthernetNetworkFactoryExt: IpClient.startProvisioning
08-25 11:48:48.685   243   376 I netd    : interfaceSetEnableIPv6("eth1", "false") <1.02ms>
08-25 11:48:48.698   243   376 I netd    : interfaceClearAddrs("eth1") <0.91ms>
08-25 11:48:48.709   243   376 I netd    : interfaceSetIPv6PrivacyExtensions("eth1", "true") <0.32ms>
08-25 11:48:48.711   243   376 I netd    : setIPv6AddrGenMode("eth1", 2) <0.30ms>
08-25 11:48:48.718   243   376 I netd    : interfaceSetEnableIPv6("eth1", "true") <5.67ms>
08-25 11:48:48.723   243   376 I netd    : interfaceSetCfg() <2.91ms>
08-25 11:48:48.727   431  1613 E EthernetNetworkFactory: chunqiao skip eth1 registerNetworkAgent
08-25 11:48:48.729   431  1617 D EthernetNetworkFactoryExt: addToLocalNetwork: iface = eth1
08-25 11:48:48.733   243   376 E Netd    : getIfIndex: cannot find interface eth1
08-25 11:48:48.733   243   376 E Netd    : inconceivable! added interface eth1 with no index
08-25 11:48:48.734   243   376 I netd    : networkAddInterface(99, "eth1") <3.34ms>
08-25 11:48:48.736   243   376 I netd    : networkAddRoute(99, "eth1", "fe80::/64", "") <0.87ms>
08-25 11:48:48.737   243   376 I netd    : networkAddRoute(99, "eth1", "192.168.1.0/24", "") <0.33ms>
08-25 11:48:48.738   243   376 E Netd    : Error adding route fe80::/64 -> (null) eth1 to table 97: File exists
08-25 11:48:48.738   243   376 I netd    : networkAddRoute(99, "eth1", "fe80::/64", "") <0.37ms>
08-25 11:48:48.740   243   376 I netd    : setProcSysNet(4, 2, "eth1", "retrans_time_ms", "750") <0.25ms>
08-25 11:48:48.741   243   376 I netd    : setProcSysNet(4, 2, "eth1", "ucast_solicit", "5") <0.12ms>
08-25 11:48:48.742   243   376 I netd    : setProcSysNet(6, 2, "eth1", "retrans_time_ms", "750") <0.17ms>
08-25 11:48:48.742   243   376 I netd    : setProcSysNet(6, 2, "eth1", "ucast_solicit", "5") <0.12ms>
08-25 11:48:49.628   431   992 D DhcpClient: Unicasting DHCPREQUEST ciaddr=192.168.50.6 request=0.0.0.0 serverid=null to /192.168.50.254:67
08-25 11:48:49.634   431   997 D DhcpClient: Received packet: 00:e0:4c:78:37:02 ACK: your new IP /192.168.50.6, netmask /255.255.255.0, gateways [/192.168.50.254] DNS servers: /192.168.50.254 , lease
time 120
08-25 11:48:49.641   431   992 D DhcpClient: Renewed lease: android.net.networkstack.DhcpResults@66a3fd1 DHCP server /192.168.50.254 Vendor info null lease 120 seconds Servername
08-25 11:48:49.648   431   992 D DhcpClient: Scheduling renewal in 59s
08-25 11:48:49.648   431   992 D DhcpClient: Scheduling rebind in 104s
08-25 11:48:49.648   431   992 D DhcpClient: Scheduling expiry in 119s

rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          inet addr:192.168.50.6  Bcast:192.168.50.255  Mask:255.255.255.0
          inet6 addr: fe80::45a2:83ec:9f60:f57c/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:180 errors:0 dropped:0 overruns:0 frame:0
          TX packets:34 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:13268 TX bytes:3586

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:4 errors:0 dropped:0 overruns:0 frame:0
          TX packets:4 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:352 TX bytes:352

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.100  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::9df3:d19f:2567:e362/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:138 errors:0 dropped:0 overruns:0 frame:0
          TX packets:43 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:15037 TX bytes:4288
          Interrupt:27

rk3399_Android10:/ # ping 192.168.1.50
ping 192.168.1.50
PING 192.168.1.50 (192.168.1.50) 56(84) bytes of data.
64 bytes from 192.168.1.50: icmp_seq=1 ttl=128 time=2.65 ms
64 bytes from 192.168.1.50: icmp_seq=2 ttl=128 time=1.43 ms
64 bytes from 192.168.1.50: icmp_seq=3 ttl=128 time=1.16 ms
^C
C:\adb>adb shell
rk3399_Android10:/ $ s^C
C:\adb>adb root
restarting adbd as root

C:\adb>adb shell
rk3399_Android10:/ # ping www.baidu.com
ping www.baidu.com
PING www.a.shifen.com (14.215.177.39) 56(84) bytes of data.
64 bytes from 14.215.177.39: icmp_seq=1 ttl=53 time=6.43 ms
64 bytes from 14.215.177.39: icmp_seq=2 ttl=53 time=6.45 ms
^C


拔掉eth0

--------- beginning of main
08-25 11:49:35.105   431   450 I EthernetTracker: interfaceLinkStateChanged, iface: eth0, up: false
08-25 11:49:35.106   431   568 D EthernetNetworkFactory: updateInterfaceLinkState, iface: eth0, up: false
08-25 11:49:35.109   431   992 D DhcpClient: doQuit
08-25 11:49:35.126   431   992 D DhcpClient: onQuitting
08-25 11:49:35.134   431   997 D DhcpClient: Receive thread stopped
08-25 11:49:35.136   243   376 I netd    : interfaceSetCfg() <8.29ms>
08-25 11:49:35.148   243   376 I netd    : interfaceSetEnableIPv6("eth0", "false") <7.59ms>
08-25 11:49:35.155   243   376 I netd    : interfaceClearAddrs("eth0") <0.94ms>
08-25 11:49:35.162   431   568 I EthernetNetworkFactory: Updating mNetworkAgent with: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED
 LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbps], [type: Ethernet[], state: DISCONNECTED/DISCONNECTED, reason: (unspecified), extra: 00:e0:4c:78:37:02, failover: false, available: true, roami
ng: false], {InterfaceName: eth0 LinkAddresses: [ fe80::45a2:83ec:9f60:f57c/64,192.168.50.6/24 ] DnsAddresses: [ /192.168.50.254 ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,10
48576,2097152 Routes: [ fe80::/64 -> :: eth0,192.168.50.0/24 -> 0.0.0.0 eth0,0.0.0.0/0 -> 192.168.50.254 eth0 ]}
--------- beginning of system
08-25 11:49:35.163   431   542 D ConnectivityService: NetworkAgentInfo [Ethernet () - 100] EVENT_NETWORK_INFO_CHANGED, going from CONNECTED to DISCONNECTED
08-25 11:49:35.164   431   542 D ConnectivityService: NetworkAgentInfo [Ethernet () - 100] got DISCONNECTED, was satisfying 8
08-25 11:49:35.164   431   568 D Ethernet: NetworkAgent: NetworkAgent channel lost
08-25 11:49:35.168   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:35.177   243   376 I netd    : trafficSwapActiveStatsMap() <8.06ms>
08-25 11:49:35.184   243   376 I netd    : tetherGetStats() <3.23ms>
08-25 11:49:35.196   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:35.199   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:35.207   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 0
08-25 11:49:35.208   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:49:35.210   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 0
08-25 11:49:35.210   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:49:35.225   431   542 D ConnectivityService: Sending DISCONNECTED broadcast for type 9 NetworkAgentInfo [Ethernet () - 100] isDefaultNetwork=true
08-25 11:49:35.232   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:35.235   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:35.236   243   376 I netd    : bandwidthSetGlobalAlert(2097152) <0.27ms>
08-25 11:49:35.237  1239  1239 D RKUpdateReceiver: action = android.net.conn.CONNECTIVITY_CHANGE
08-25 11:49:35.246   243   243 D TcpSocketMonitor: suspending tcpinfo polling
08-25 11:49:35.246   243   243 I netd    : networkDestroy(100) <9.60ms>
08-25 11:49:35.248   243   243 I netd    : destroyNetworkCache(100) <0.12ms>
^C
C:\adb>adb shell
rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          UP BROADCAST MULTICAST  MTU:1500  Metric:1
          RX packets:189 errors:0 dropped:0 overruns:0 frame:0
          TX packets:41 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:14349 TX bytes:4179

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:4 errors:0 dropped:0 overruns:0 frame:0
          TX packets:4 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:352 TX bytes:352

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.100  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::9df3:d19f:2567:e362/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:164 errors:0 dropped:0 overruns:0 frame:0
          TX packets:54 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:18683 TX bytes:5428
          Interrupt:27



插入eth0
--------- beginning of main
08-25 11:49:53.893   431   450 I EthernetTracker: interfaceLinkStateChanged, iface: eth0, up: true
08-25 11:49:53.894   431   568 D EthernetNetworkFactory: updateInterfaceLinkState, iface: eth0, up: true
08-25 11:49:53.894   431   568 D EthernetNetworkFactory: starting IpClient(eth0): mNetworkInfo=[type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, avail
able: false, roaming: false]
08-25 11:49:53.901   243   243 I netd    : interfaceSetEnableIPv6("eth0", "false") <0.30ms>
08-25 11:49:53.902   243   243 I netd    : interfaceClearAddrs("eth0") <0.72ms>
08-25 11:49:53.916   243   243 I netd    : interfaceSetIPv6PrivacyExtensions("eth0", "true") <0.22ms>
08-25 11:49:53.917   243   243 I netd    : setIPv6AddrGenMode("eth0", 2) <0.25ms>
08-25 11:49:53.918   243   243 I netd    : interfaceSetEnableIPv6("eth0", "true") <0.43ms>
08-25 11:49:53.922   243   243 I netd    : setProcSysNet(4, 2, "eth0", "retrans_time_ms", "750") <0.22ms>
08-25 11:49:53.923   243   243 I netd    : setProcSysNet(4, 2, "eth0", "ucast_solicit", "5") <0.18ms>
08-25 11:49:53.924   243   243 I netd    : setProcSysNet(6, 2, "eth0", "retrans_time_ms", "750") <0.23ms>
08-25 11:49:53.925   243   243 I netd    : setProcSysNet(6, 2, "eth0", "ucast_solicit", "5") <0.17ms>
08-25 11:49:53.948   431  1653 D DhcpClient: Receive thread started
08-25 11:49:53.953   431  1652 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:49:58.957   431  1652 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:49:58.962   431  1653 D DhcpClient: Received packet: 00:e0:4c:78:37:02 OFFER, ip /192.168.50.6, mask /255.255.255.0, DNS servers: /192.168.50.254 , gateways [/192.168.50.254] lease time 120,
domain null
08-25 11:49:58.975   431  1652 D DhcpClient: Got pending lease: android.net.networkstack.DhcpResults@285db96 DHCP server /192.168.50.254 Vendor info null lease 120 seconds Servername
08-25 11:49:58.982   431  1652 D DhcpClient: Broadcasting DHCPREQUEST ciaddr=0.0.0.0 request=192.168.50.6 serverid=192.168.50.254
08-25 11:49:58.985   431  1653 D DhcpClient: Received packet: 00:e0:4c:78:37:02 ACK: your new IP /192.168.50.6, netmask /255.255.255.0, gateways [/192.168.50.254] DNS servers: /192.168.50.254 , lease
time 120
08-25 11:49:58.995   431  1652 D DhcpClient: Confirmed lease: android.net.networkstack.DhcpResults@3c76304 DHCP server /192.168.50.254 Vendor info null lease 120 seconds Servername
08-25 11:49:59.006   243   243 I netd    : interfaceSetCfg() <1.32ms>
08-25 11:49:59.019   431   568 E EthernetNetworkFactory: chunqiao carrier=1
08-25 11:49:59.020   431   568 E EthernetNetworkFactory: eth0 carrier = 1
--------- beginning of system
08-25 11:49:59.021   431   568 D ConnectivityService: registerNetworkAgent NetworkAgentInfo{ ni{[type: Ethernet[], state: CONNECTED/CONNECTED, reason: (unspecified), extra: 00:e0:4c:78:37:02, failover
: false, available: true, roaming: false]}  network{101}  nethandle{437197393933}  lp{{InterfaceName: eth0 LinkAddresses: [ fe80::45a2:83ec:9f60:f57c/64,192.168.50.6/24 ] DnsAddresses: [ /192.168.50.2
54 ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth0,192.168.50.0/24 -> 0.0.0.0 eth0,0.0.0.0/0 -> 192.168.50.254 eth0 ]}}  nc{[ Transp
orts: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&FOREGROUND&NOT_CONGESTED&NOT_SUSPENDED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbps]}  Score{30}
  everValidated{false}  lastValidated{false}  created{false} lingering{false} explicitlySelected{false} acceptUnvalidated{false} everCaptivePortalDetected{false} lastCaptivePortalDetected{false} capti
vePortalValidationPending{false} partialConnectivity{false} acceptPartialConnectivity{false} clat{mBaseIface: null, mIface: null, mState: IDLE} }
08-25 11:49:59.023   431  1652 D DhcpClient: Scheduling renewal in 59s
08-25 11:49:59.023   431  1652 D DhcpClient: Scheduling rebind in 104s
08-25 11:49:59.023   431  1652 D DhcpClient: Scheduling expiry in 119s
08-25 11:49:59.029   431   568 E ConnectivityService: huchunqiao eth0
08-25 11:49:59.029   431   542 D ConnectivityService: NetworkAgentInfo [Ethernet () - 101] EVENT_NETWORK_INFO_CHANGED, going from null to CONNECTED
08-25 11:49:59.030   243   243 D TcpSocketMonitor: resuming tcpinfo polling (interval=30000ms)
08-25 11:49:59.030   243   243 I netd    : networkCreatePhysical(101, 0) <0.15ms>
08-25 11:49:59.032   243   243 I netd    : createNetworkCache(101) <0.38ms>
08-25 11:49:59.033   431   542 W DnsManager: updatePrivateDns(101, PrivateDnsConfig{true:/[]})
08-25 11:49:59.034   431   542 D ConnectivityService: Setting DNS servers for network 101 to [/192.168.50.254]
08-25 11:49:59.034   431   542 D DnsManager: setDnsConfigurationForNetwork(101, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, , [192.168.50.254])
08-25 11:49:59.036   243   243 I netd    : DnsResolverService::setResolverConfiguration(101, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, [192.168.50.254], []) -> (0) (0.8ms)
08-25 11:49:59.036   243   243 I netd    : setResolverConfiguration() <1.15ms>
08-25 11:49:59.039   431   542 D ConnectivityService: Adding iface eth0 to network 101
08-25 11:49:59.046   243   243 I netd    : networkAddInterface(101, "eth0") <5.60ms>
08-25 11:49:59.049   243   243 I netd    : networkAddRoute(101, "eth0", "fe80::/64", "") <1.03ms>
08-25 11:49:59.050   243   376 I netd    : networkAddRoute(101, "eth0", "192.168.50.0/24", "") <0.47ms>
08-25 11:49:59.052   243   376 I netd    : networkAddRoute(101, "eth0", "0.0.0.0/0", "192.168.50.254") <0.54ms>
08-25 11:49:59.053   431   542 D ConnectivityService: Setting DNS servers for network 101 to [/192.168.50.254]
08-25 11:49:59.054   431   542 D DnsManager: setDnsConfigurationForNetwork(101, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, , [192.168.50.254])
08-25 11:49:59.055   243   376 I netd    : DnsResolverService::setResolverConfiguration(101, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, [192.168.50.254], []) -> (0) (0.8ms)
08-25 11:49:59.055   243   376 I netd    : setResolverConfiguration() <1.10ms>
08-25 11:49:59.059   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.061   243  1656 W DnsTlsSocket: SSL_connect error 5, errno=111
08-25 11:49:59.068   243   243 I netd    : trafficSwapActiveStatsMap() <7.67ms>
08-25 11:49:59.072   243   243 I netd    : tetherGetStats() <2.03ms>
08-25 11:49:59.080   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.083   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.088   431  1657 D NetworkMonitor/101: Validation disabled.
08-25 11:49:59.089   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 30
08-25 11:49:59.089   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:49:59.092   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 30
08-25 11:49:59.092   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:49:59.093   431   542 D ConnectivityService: Switching to new default network: NetworkAgentInfo{ ni{[type: Ethernet[], state: CONNECTED/CONNECTED, reason: (unspecified), extra: 00:e0:4c:78:37
:02, failover: false, available: true, roaming: false]}  network{101}  nethandle{437197393933}  lp{{InterfaceName: eth0 LinkAddresses: [ fe80::45a2:83ec:9f60:f57c/64,192.168.50.6/24 ] DnsAddresses: [
/192.168.50.254 ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth0,192.168.50.0/24 -> 0.0.0.0 eth0,0.0.0.0/0 -> 192.168.50.254 eth0 ]}}
  nc{[ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&FOREGROUND&NOT_CONGESTED&NOT_SUSPENDED LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbps
]}  Score{30}  everValidated{false}  lastValidated{false}  created{true} lingering{false} explicitlySelected{false} acceptUnvalidated{false} everCaptivePortalDetected{false} lastCaptivePortalDetected{
false} captivePortalValidationPending{false} partialConnectivity{false} acceptPartialConnectivity{false} clat{mBaseIface: null, mIface: null, mState: IDLE} }
08-25 11:49:59.094   243   243 I netd    : networkSetDefault(101) <0.64ms>
08-25 11:49:59.098   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.110   243   243 I netd    : trafficSwapActiveStatsMap() <10.79ms>
08-25 11:49:59.114   243   243 I netd    : tetherGetStats() <2.04ms>
08-25 11:49:59.123   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.126   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.130   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.132   243   243 I netd    : bandwidthSetGlobalAlert(2097152) <0.26ms>
08-25 11:49:59.137   431   665 D NetworkTimeUpdateService: New default network 101; checking time.
08-25 11:49:59.137   431   542 D ConnectivityService: Sending CONNECTED broadcast for type 9 NetworkAgentInfo [Ethernet () - 101] isDefaultNetwork=true
08-25 11:49:59.142   431   542 D ConnectivityService: NetworkAgentInfo [Ethernet () - 101] validation passed
08-25 11:49:59.145   243  1658 E ResolverController: No valid NAT64 prefix (101, <unspecified>/0)
08-25 11:49:59.146   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.148   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:49:59.149   243   243 I netd    : bandwidthSetGlobalAlert(2097152) <0.25ms>
08-25 11:49:59.149   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 70
08-25 11:49:59.150   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:49:59.153  1239  1239 D RKUpdateReceiver: action = android.net.conn.CONNECTIVITY_CHANGE
08-25 11:49:59.154   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 70
08-25 11:49:59.155   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:49:59.158   431   542 D ConnectivityService: Setting DNS servers for network 101 to [/192.168.50.254]
08-25 11:49:59.161   431   542 D DnsManager: setDnsConfigurationForNetwork(101, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, , [192.168.50.254])
08-25 11:49:59.162   243   243 I netd    : DnsResolverService::setResolverConfiguration(101, [192.168.50.254], [], 1800, 25, 8, 64, 0, 0, [192.168.50.254], []) -> (0) (0.6ms)
08-25 11:49:59.162   243   243 I netd    : setResolverConfiguration() <0.90ms>
08-25 11:49:59.162  1239  1239 W ContextImpl: Calling a method in the system process without a qualified user: android.app.ContextImpl.startService:1570 android.content.ContextWrapper.startService:669
 android.content.ContextWrapper.startService:669 android.rockchip.update.service.RKUpdateReceiver.onReceive:101 android.app.ActivityThread.handleReceiver:3788
08-25 11:49:59.164   243  1659 W DnsTlsSocket: SSL_connect error 5, errno=111
08-25 11:49:59.169  1239  1239 D RKUpdateService: onStartCommand.......
08-25 11:49:59.169  1239  1239 D RKUpdateService: command = 2 delaytime = 5000
^C
C:\adb>adb shell
rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          inet addr:192.168.50.6  Bcast:192.168.50.255  Mask:255.255.255.0
          inet6 addr: fe80::45a2:83ec:9f60:f57c/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:197 errors:0 dropped:0 overruns:0 frame:0
          TX packets:57 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:15361 TX bytes:6167

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:4 errors:0 dropped:0 overruns:0 frame:0
          TX packets:4 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:352 TX bytes:352

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.100  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::9df3:d19f:2567:e362/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:164 errors:0 dropped:0 overruns:0 frame:0
          TX packets:58 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:18683 TX bytes:5624
          Interrupt:27



拔掉eth0
--------- beginning of main
08-25 11:50:13.255  1239  1298 D RKUpdateService: request remote server error...
08-25 11:50:23.200   431   450 I EthernetTracker: interfaceLinkStateChanged, iface: eth0, up: false
08-25 11:50:23.201   431   568 D EthernetNetworkFactory: updateInterfaceLinkState, iface: eth0, up: false
08-25 11:50:23.204   431  1652 D DhcpClient: doQuit
08-25 11:50:23.226   431  1652 D DhcpClient: onQuitting
08-25 11:50:23.235   431  1653 D DhcpClient: Receive thread stopped
08-25 11:50:23.244   243   243 I netd    : interfaceSetCfg() <16.24ms>
08-25 11:50:23.260   243   243 I netd    : interfaceSetEnableIPv6("eth0", "false") <11.77ms>
08-25 11:50:23.264   243   243 I netd    : interfaceClearAddrs("eth0") <1.08ms>
08-25 11:50:23.268   431   568 I EthernetNetworkFactory: Updating mNetworkAgent with: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED
 LinkUpBandwidth>=100000Kbps LinkDnBandwidth>=100000Kbps], [type: Ethernet[], state: DISCONNECTED/DISCONNECTED, reason: (unspecified), extra: 00:e0:4c:78:37:02, failover: false, available: true, roami
ng: false], {InterfaceName: eth0 LinkAddresses: [ fe80::45a2:83ec:9f60:f57c/64,192.168.50.6/24 ] DnsAddresses: [ /192.168.50.254 ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,10
48576,2097152 Routes: [ fe80::/64 -> :: eth0,192.168.50.0/24 -> 0.0.0.0 eth0,0.0.0.0/0 -> 192.168.50.254 eth0 ]}
--------- beginning of system
08-25 11:50:23.269   431   542 D ConnectivityService: NetworkAgentInfo [Ethernet () - 101] EVENT_NETWORK_INFO_CHANGED, going from CONNECTED to DISCONNECTED
08-25 11:50:23.269   431   542 D ConnectivityService: NetworkAgentInfo [Ethernet () - 101] got DISCONNECTED, was satisfying 8
08-25 11:50:23.270   431   568 D Ethernet: NetworkAgent: NetworkAgent channel lost
08-25 11:50:23.274   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:50:23.284   243   243 I netd    : trafficSwapActiveStatsMap() <9.24ms>
08-25 11:50:23.289   243   243 I netd    : tetherGetStats() <2.56ms>
08-25 11:50:23.299   431   542 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:50:23.304   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:50:23.306   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 0
08-25 11:50:23.308   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=1, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:50:23.309   431   568 D EthernetNetworkFactory: acceptRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], score: 0
08-25 11:50:23.310   431   568 I EthernetNetworkFactory: networkForRequest, request: NetworkRequest [ REQUEST id=7, [ Capabilities: INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN] ], network: NetworkInterfac
eState{ iface: eth1, up: false, hwAddress: ae:9a:d5:82:2a:70, networkInfo: [type: Ethernet[], state: CONNECTING/OBTAINING_IPADDR, reason: (unspecified), extra: ae:9a:d5:82:2a:70, failover: false, avai
lable: false, roaming: false], networkCapabilities: [ Transports: ETHERNET Capabilities: NOT_METERED&INTERNET&NOT_RESTRICTED&TRUSTED&NOT_VPN&NOT_ROAMING&NOT_CONGESTED LinkUpBandwidth>=100000Kbps LinkD
nBandwidth>=100000Kbps], networkAgent: null, score: 0, ipClient: android.net.ip.IIpClient$Stub$Proxy@602080d,linkProperties: {InterfaceName: eth1 LinkAddresses: [ fe80::9df3:d19f:2567:e362/64 ] DnsAdd
resses: [ ] Domains: null MTU: 0 TcpBufferSizes: 524288,1048576,3145728,524288,1048576,2097152 Routes: [ fe80::/64 -> :: eth1 ]}}
08-25 11:50:23.317   431   542 D ConnectivityService: Sending DISCONNECTED broadcast for type 9 NetworkAgentInfo [Ethernet () - 101] isDefaultNetwork=true
08-25 11:50:23.324   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:50:23.326   431   536 W BestClock: java.time.DateTimeException: Missing NTP fix
08-25 11:50:23.328   243   243 I netd    : bandwidthSetGlobalAlert(2097152) <0.24ms>
08-25 11:50:23.329  1239  1239 D RKUpdateReceiver: action = android.net.conn.CONNECTIVITY_CHANGE
08-25 11:50:23.336   243   376 D TcpSocketMonitor: suspending tcpinfo polling
08-25 11:50:23.337   243   376 I netd    : networkDestroy(101) <8.92ms>
08-25 11:50:23.338   243   376 I netd    : destroyNetworkCache(101) <0.12ms>


^C
C:\adb>adb shell
rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          UP BROADCAST MULTICAST  MTU:1500  Metric:1
          RX packets:198 errors:0 dropped:0 overruns:0 frame:0
          TX packets:58 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:15407 TX bytes:6237

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:6 errors:0 dropped:0 overruns:0 frame:0
          TX packets:6 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:528 TX bytes:528

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.100  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::9df3:d19f:2567:e362/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:165 errors:0 dropped:0 overruns:0 frame:0
          TX packets:61 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:18940 TX bytes:5750
          Interrupt:27


拔掉eth1
--------- beginning of main
08-25 11:50:34.938   431  1613 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:50:34.946   595   595 D KeyguardClockSwitch: Updating clock: 11:50鈥夾M
08-25 11:50:40.309   431   450 I EthernetTracker: interfaceLinkStateChanged, iface: eth1, up: false
08-25 11:50:40.310   431   568 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth1, up = false
08-25 11:50:40.310   431   568 D EthernetNetworkFactoryExt: mLinkUp= true
08-25 11:50:40.325   243   376 I netd    : interfaceClearAddrs("eth1") <11.63ms>
08-25 11:50:40.326   431  1672 D EthernetNetworkFactoryExt: removeToLocalNetwork: iface = eth1
08-25 11:50:40.331   431  1613 D DhcpClient: doQuit
08-25 11:50:40.334   243   376 I netd    : networkRemoveInterface(99, "eth1") <6.91ms>
08-25 11:50:40.345   431  1613 D DhcpClient: onQuitting
08-25 11:50:40.345   431  1614 D DhcpClient: Receive thread stopped
08-25 11:50:40.351   243   243 I netd    : interfaceSetEnableIPv6("eth1", "false") <2.54ms>
08-25 11:50:40.352   243   376 I netd    : interfaceSetEnableIPv6("eth1", "false") <7.62ms>
08-25 11:50:40.354   243   243 I netd    : interfaceClearAddrs("eth1") <0.99ms>
08-25 11:50:40.355   243   370 I netd    : interfaceClearAddrs("eth1") <0.91ms>
08-25 11:50:40.368   431   568 D EthernetNetworkFactory: starting IpClient(eth1): mNetworkInfo=[type: Ethernet[], state: DISCONNECTED/IDLE, reason: (unspecified), extra: (none), failover: false, avail
able: false, roaming: false]
08-25 11:50:40.374   243   376 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.30ms>
08-25 11:50:40.375   243   376 I netd    : interfaceClearAddrs("eth1") <0.72ms>
08-25 11:50:40.388   243   376 I netd    : interfaceSetIPv6PrivacyExtensions("eth1", "true") <0.28ms>
08-25 11:50:40.389   243   376 I netd    : setIPv6AddrGenMode("eth1", 2) <0.28ms>
08-25 11:50:40.391   243   376 I netd    : interfaceSetEnableIPv6("eth1", "true") <0.43ms>
08-25 11:50:40.394   243   376 I netd    : setProcSysNet(4, 2, "eth1", "retrans_time_ms", "750") <0.28ms>
08-25 11:50:40.396   243   376 I netd    : setProcSysNet(4, 2, "eth1", "ucast_solicit", "5") <0.24ms>
08-25 11:50:40.398   243   376 I netd    : setProcSysNet(6, 2, "eth1", "retrans_time_ms", "750") <0.35ms>
08-25 11:50:40.399   243   376 I netd    : setProcSysNet(6, 2, "eth1", "ucast_solicit", "5") <0.22ms>
08-25 11:50:40.415   431  1675 D DhcpClient: Receive thread started
08-25 11:50:40.419   431  1674 D DhcpClient: Broadcasting DHCPDISCOVER





插入eth1
08-25 11:50:50.426   431  1674 I chatty  : uid=1000(system) IpClient.eth1 identical 2 lines
08-25 11:50:58.904   431  1674 D DhcpClient: Broadcasting DHCPDISCOVER
08-25 11:51:00.789   431   450 I EthernetTracker: interfaceLinkStateChanged, iface: eth1, up: true
08-25 11:51:00.790   431   568 D EthernetNetworkFactoryExt: interfaceLinkStateChanged: iface = eth1, up = true
08-25 11:51:00.790   431   568 D EthernetNetworkFactoryExt: mLinkUp= false
08-25 11:51:01.794   431  1676 D EthernetNetworkFactoryExt: setStaticIpAddress:IP address 192.168.1.100/24 Gateway  DNS servers: [ ] Domains
08-25 11:51:01.795   431  1676 D EthernetNetworkFactoryExt: IpClient.startProvisioning
08-25 11:51:01.806   243   376 I netd    : interfaceSetEnableIPv6("eth1", "false") <0.66ms>
08-25 11:51:01.815   243   376 I netd    : interfaceClearAddrs("eth1") <0.46ms>
08-25 11:51:01.825   243   376 I netd    : interfaceSetIPv6PrivacyExtensions("eth1", "true") <0.27ms>
08-25 11:51:01.826   243   376 I netd    : setIPv6AddrGenMode("eth1", 2) <0.21ms>
08-25 11:51:01.827   243   376 I netd    : interfaceSetEnableIPv6("eth1", "true") <0.37ms>
08-25 11:51:01.831   243   376 I netd    : interfaceSetCfg() <0.82ms>
08-25 11:51:01.835   243   376 I netd    : setProcSysNet(4, 2, "eth1", "retrans_time_ms", "750") <0.21ms>
08-25 11:51:01.836   243   376 I netd    : setProcSysNet(4, 2, "eth1", "ucast_solicit", "5") <0.10ms>
08-25 11:51:01.836   243   376 I netd    : setProcSysNet(6, 2, "eth1", "retrans_time_ms", "750") <0.14ms>
08-25 11:51:01.837   431  1674 E EthernetNetworkFactory: chunqiao skip eth1 registerNetworkAgent
08-25 11:51:01.837   243   376 I netd    : setProcSysNet(6, 2, "eth1", "ucast_solicit", "5") <0.08ms>
08-25 11:51:01.843   431  1677 D EthernetNetworkFactoryExt: addToLocalNetwork: iface = eth1
08-25 11:51:01.847   243   376 E Netd    : getIfIndex: cannot find interface eth1
08-25 11:51:01.847   243   376 E Netd    : inconceivable! added interface eth1 with no index
08-25 11:51:01.847   243   376 I netd    : networkAddInterface(99, "eth1") <3.25ms>
08-25 11:51:01.849   243   376 I netd    : networkAddRoute(99, "eth1", "fe80::/64", "") <0.41ms>
08-25 11:51:01.850   243   376 I netd    : networkAddRoute(99, "eth1", "192.168.1.0/24", "") <0.34ms>
08-25 11:51:01.852   243   376 E Netd    : Error adding route fe80::/64 -> (null) eth1 to table 97: File exists
08-25 11:51:01.852   243   376 I netd    : networkAddRoute(99, "eth1", "fe80::/64", "") <0.59ms>
^C
C:\adb>adb shell
rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          UP BROADCAST MULTICAST  MTU:1500  Metric:1
          RX packets:198 errors:0 dropped:0 overruns:0 frame:0
          TX packets:58 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:15407 TX bytes:6237

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:6 errors:0 dropped:0 overruns:0 frame:0
          TX packets:6 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:528 TX bytes:528

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.100  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::9df3:d19f:2567:e362/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:216 errors:0 dropped:0 overruns:0 frame:0
          TX packets:74 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:23424 TX bytes:7090
          Interrupt:27

rk3399_Android10:/ # ping 192.168.1.50
ping 192.168.1.50
PING 192.168.1.50 (192.168.1.50) 56(84) bytes of data.
64 bytes from 192.168.1.50: icmp_seq=1 ttl=128 time=2.17 ms
64 bytes from 192.168.1.50: icmp_seq=2 ttl=128 time=1.59 ms


第一次重启也验证过，eth1静态IP存在

rk3399_Android10:/ # ifconfig
ifconfig
eth0      Link encap:Ethernet  HWaddr 00:e0:4c:78:37:02  Driver r8152
          UP BROADCAST MULTICAST  MTU:1500  Metric:1
          RX packets:198 errors:0 dropped:0 overruns:0 frame:0
          TX packets:58 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:15407 TX bytes:6237

lo        Link encap:Local Loopback
          inet addr:127.0.0.1  Mask:255.0.0.0
          inet6 addr: ::1/128 Scope: Host
          UP LOOPBACK RUNNING  MTU:65536  Metric:1
          RX packets:6 errors:0 dropped:0 overruns:0 frame:0
          TX packets:6 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:528 TX bytes:528

eth1      Link encap:Ethernet  HWaddr ae:9a:d5:82:2a:70  Driver rk_gmac-dwmac
          inet addr:192.168.1.100  Bcast:192.168.1.255  Mask:255.255.255.0
          inet6 addr: fe80::9df3:d19f:2567:e362/64 Scope: Link
          UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
          RX packets:216 errors:0 dropped:0 overruns:0 frame:0
          TX packets:74 errors:0 dropped:0 overruns:0 carrier:0
          collisions:0 txqueuelen:1000
          RX bytes:23424 TX bytes:7090
          Interrupt:27
